#include "Shape.h"

Shape::Shape()
{

}

Shape::Shape(int x, int y)
{
    position.x = x;
    position.y = y;
}
