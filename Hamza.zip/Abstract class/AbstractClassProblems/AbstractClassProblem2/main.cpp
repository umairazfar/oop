#include <iostream>
#include "Derived3.h"

using namespace std;

int main()
{
    Derived3 obj;
    obj.PrintDerived3();

    return 0;
}
