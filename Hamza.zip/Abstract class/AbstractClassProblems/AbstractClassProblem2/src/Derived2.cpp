#include "Derived2.h"

Derived2::Derived2()
{
    //ctor
}

Derived2::~Derived2()
{
    //dtor
}
