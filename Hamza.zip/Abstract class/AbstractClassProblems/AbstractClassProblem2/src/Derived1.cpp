#include "Derived1.h"

Derived1::Derived1()
{
    //ctor
}

Derived1::~Derived1()
{
    //dtor
}
