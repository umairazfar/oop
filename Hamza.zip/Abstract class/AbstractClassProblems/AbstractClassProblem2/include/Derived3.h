#ifndef DERIVED3_H
#define DERIVED3_H
#include "Derived2.h"

class Derived3
{
    public:
        Derived3();
        void PrintDerived3();
        void PrintDerived2();
        void PrintDerived1();
        void PrintBase();

};

#endif // DERIVED3_H
