#pragma once

struct Point
{
	float x;
	float y;

	Point()                 // Default constructor
	{

	}

	Point(float x, float y)     // Overloaded constructor
	{
	    this->x = x;
	    this->y = y;
	}
};

