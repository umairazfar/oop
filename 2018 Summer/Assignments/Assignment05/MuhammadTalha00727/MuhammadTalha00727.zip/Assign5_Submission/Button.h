#ifndef BUTTON_H
#define BUTTON_H

#include <SDL.h>
#include <SDL_image.h>
#include <iostream>
#include "LTexture.h"
#include "string"
#include "Point.h"
#include "Character.h"
#include "Word.h"
#include "Button.h"

using namespace std;

class Button: public Word
{
private:
    int word_len;
    Point position;
    Word* word_object;
    int width;
    int height;
    SDL_Rect LeftButton;
    SDL_Rect RightButton;
    SDL_Rect CenterButton;
    SDL_Rect Button_Whole;

    LTexture* left_button;
    LTexture* right_button;
    LTexture* center_button;
    LTexture* spriteSheetTexture;

public:
    Button();
    ~Button();
    Button(LTexture* image, float x, float y, string word_pass);
    void Render(SDL_Renderer* gRenderer, bool debug);
    GetFrameHeight();
    GetFrameWidth();
};

#endif // BUTTON_H
