#include "Button.h"
#include <iostream>
#include<string.h>

using namespace std;

Button::Button()
{
    width = height = 64;
}

Button::Button(LTexture* image, float x, float y, string st)
{
    spriteSheetTexture = image;
    word = new Word(image,x,y,st);
    //Frame 0
    spriteClips[0].x = 0;
    spriteClips[0].y = 432;
    spriteClips[0].w = 64;
    spriteClips[0].h = 64;

    //Frame 1
    spriteClips[1].x = 30;
    spriteClips[1].y = 432;
    spriteClips[1].w = 64;
    spriteClips[1].h = 64;

    //Frame 2
    spriteClips[2].x = 89 ;
    spriteClips[2].y = 432;
    spriteClips[2].w = 64;
    spriteClips[2].h = 64;

    position.x = x;
    position.y = y;

    this->width = spriteClips[0].w;
    this->height = spriteClips[0].h;

}

void Button::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    int string_length = word->Getword_length();

    spriteSheetTexture->Render( (position.x-width/2)-(44*(string_length))+44, position.y - height/2, &spriteClips[0], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { (position.x-width/2)-(44*(string_length)), position.y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
    float dec = string_length/2;
    for (int i=0; i < string_length; i++)
    {
        spriteSheetTexture->Render( (position.x-width/2)-(dec*44), position.y - height/2, &spriteClips[1], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
        if(debug == true)
        {
            SDL_Rect rect = { (position.x-width/2), position.y - height/2, width, height };
            SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
            SDL_RenderDrawRect( gRenderer, &rect );
        }
        dec--;
    }

    spriteSheetTexture->Render((position.x-width/2)+(44*string_length)-44, position.y - height/2, &spriteClips[2], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { (position.x-width/2 )+(44*string_length)-44, position.y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
    word->Render(frame,gRenderer,false);
}

Button::~Button()
{
    //dtor
}
