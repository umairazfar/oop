#include "Word.h"

Word::Word()
{
    //ctor
}

Word::~Word()
{
    //dtor
}

Word::Word(LTexture* image, float x, float y, char Array[])
{
    spriteSheetTexture = image;
    character = Array;
    while(Array[word_length]!='\0')
    {
        word_length++;
    }
    //Frame 0
    spriteClips.x = 0;
    spriteClips.y = 0;
    spriteClips.w = 44;
    spriteClips.h = 48;
    if (int(c_)>=66 && int(c_)<=75)
    {
        int diff = int(c_) - 65;
        for (int i=0; i<diff; i++)
        {
            spriteClips.x = diff*spriteClips.w;

        }
    }

    //Frame 0
    /*spriteClips.x = 0;
    spriteClips.y = 0;
    spriteClips.w = 44;
    spriteClips.h = 48;*/


    position.x = x;
    position.y = y;

    this->width = spriteClips.w;
    this->height = spriteClips.h;
}

void Word::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{


    spriteSheetTexture->Render( position.x - width/2, position.y - height/2, &spriteClips, 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { position.x - width/2, position.y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}

