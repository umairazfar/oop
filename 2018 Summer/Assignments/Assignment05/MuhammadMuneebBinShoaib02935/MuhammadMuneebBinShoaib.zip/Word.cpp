#include"Word.h"
#include<iostream>
#include"Character.h"
#include<string.h>

using namespace std;

Word::Word()
{
    word_length = 0;
}

Word::Word(LTexture* image, float x, float y, string Str)
{

    word_length = Str.size();
    character =  new Character[word_length];
    int dec = word_length/2;
    for (int i=0; i<word_length; i++)
    {
        character[i] = Character(image, x-(dec*44),y,Str[i]);
        dec--;
    }
}

Word::~Word()
{
    delete [] character;
}

void Word::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    for (int i=0; i<word_length; i++)
    {
        character[i].Render(frame, gRenderer, false);
    }
}

int Word::Getword_length()
{
    return word_length;
}

