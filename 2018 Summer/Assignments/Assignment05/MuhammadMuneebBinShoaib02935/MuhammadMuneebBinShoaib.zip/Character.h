#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include"LTexture.h"
#include"Point.h"

class Character                //class character is declared.
{
private:
    Point position;               // object of point is declared.
    int character_value;
    int width;
    int height;
    SDL_Rect spriteClips;
    LTexture* spriteSheetTexture;
public:
    Character();                                      // constructor is declared. It initially sets the width and height.
    Character(LTexture* image, float x, float y, char);               // overloaded constructor is declared. It takes the character, convert it
    // into its ascii code and then clip it from image.
    ~Character();
    virtual void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);  //It renders the character on scree.
    void SetPosition(Point&);
    void SetPosition(int, int);
    int GetFrameWidth();
    int GetFrameHeight();
};

