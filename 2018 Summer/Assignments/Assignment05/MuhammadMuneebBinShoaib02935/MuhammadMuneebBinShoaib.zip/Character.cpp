#include"Character.h"
#include<iostream>

using namespace std;

Character::Character()
{
    width = 44;
    height = 48;
    character_value = 0;
}

Character::Character(LTexture* image, float x, float y, char c_)
{
    spriteSheetTexture = image;
    int diff;
    //Frame 0
    spriteClips.x = 0;
    spriteClips.y = 0;
    spriteClips.w = 44;
    spriteClips.h = 48;
    if (int(c_)>=65 && int(c_)<=75)
    {
        diff = int(c_) - 65;
        spriteClips.y = 0;
        for (int i=0; i<diff; i++)
        {
            spriteClips.x = diff*spriteClips.w;

        }
    }
    if (int(c_)>=76 && int(c_)<=86)
    {
        diff = int(c_) - 76;
        spriteClips.y = 48;
        for (int i=0; i<diff; i++)
        {
            spriteClips.x = diff*spriteClips.w;
        }

    }
    if (int(c_)>=87 && int(c_)<=90)
    {
        diff = int(c_) - 87;
        spriteClips.y = 96;
        for (int i=0; i<diff; i++)
        {
            spriteClips.x = diff*spriteClips.w;
        }

    }

    if (int(c_)>=97 && int(c_)<=103)
    {
        diff = int(c_) - 97;
        spriteClips.y = 96;
        spriteClips.x = 176 + diff*spriteClips.w;
    }
    if (int(c_)>=104 && int(c_)<=114)
    {
        diff = int(c_) - 104;
        spriteClips.y = 144;
        for (int i=0; i<diff; i++)
        {
            spriteClips.x = diff*spriteClips.w;
        }
    }
    if (int(c_)>=115 && int(c_)<=122)
    {
        diff = int(c_) - 115;
        spriteClips.y = 192;
        for (int i=0; i<diff; i++)
        {
            spriteClips.x = diff*spriteClips.w;
        }
    }
    if (int(c_)>=48 && int(c_)<=50)
    {
        diff = int(c_) - 48;
        spriteClips.y = 192;
        spriteClips.x = 352 + diff*spriteClips.w;
    }
    if (int(c_)>=51 && int(c_)<=57)
    {
        diff = int(c_) - 51;
        spriteClips.y = 240;
        for (int i=0; i<diff; i++)
        {
            spriteClips.x = diff*spriteClips.w;
        }
    }
    if (int(c_)==32)
    {
        spriteClips.x = 220;
        spriteClips.y =  384;
    }

    position.x = x;
    position.y = y;

    this->width = spriteClips.w;
    this->height = spriteClips.h;
}

Character::~Character()
{
    char n = character_value + 97;
    std::cout<<"\nCharacter "<<n<<" Destroyed";
}

void Character::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{

    spriteSheetTexture->Render( position.x - width/2, position.y - height/2, &spriteClips, 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { position.x - width/2, position.y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}

void Character::SetPosition(Point& position)
{
    this->position.x = position.x - width/2;
    this->position.y = position.y - height/2;
}

void Character::SetPosition(int x, int y)
{
    this->position.x = x - width/2;
    this->position.y = y - height/2;
}

int Character::GetFrameWidth()
{
    return width;
}
int Character::GetFrameHeight()
{
    return height;
}

