#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include"LTexture.h"
#include"Word.h"
#include <string.h>
#include"Point.h"

using namespace std;

class Button
{
private:
    Word* word;                                          // Word type pointer is declared.
    Point position;
    SDL_Rect spriteClips[3];                            //spriteclips array is declared.
    LTexture* spriteSheetTexture;
    int width;
    int height;
public:
    Button();                                               // default constructor is declared.
    Button(LTexture* image, float x, float y, string);                     // It clips the button into three frames.
    ~Button();
    virtual void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);       // It renders the button and the word on screen.
};

