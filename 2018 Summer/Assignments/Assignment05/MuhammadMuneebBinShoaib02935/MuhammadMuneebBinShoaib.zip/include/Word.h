#ifndef WORD_H
#define WORD_H


class Word
{
    public:
        Word();
        virtual ~Word();

    protected:

    private:
};

#endif // WORD_H
