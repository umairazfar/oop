#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include"LTexture.h"
#include"Character.h"
#include <string.h>

using namespace std;

class Word
{
private:
    Character* character;                  // Character type pointer is declared.
    int word_length;
public:
    Word();                                  // default constructor is declared.
    Word(LTexture* image, float x, float y, string Str);        // It takes string uses the character class to make the word.
    int Getword_length();                                                 // It gives the word length.
    ~Word();
    virtual void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);    // It calls the character render function in it.
};

