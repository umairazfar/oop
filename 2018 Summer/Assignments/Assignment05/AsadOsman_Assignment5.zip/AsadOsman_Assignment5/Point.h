#pragma once

struct Point
{
	int x;
	int y;

	Point()
	{

	}

	Point(int x, int y)
	{
	    this->x = x;
	    this->y = y;
	}
};

