#pragma once
#include "Character.h"
#include <string>
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include"LTexture.h"
#include"Point.h"

class Word:public Character
{
public:
    Word();                                                         //Constructor
    Word(std::string String, LTexture* image, float, float);        //Overloaded constructor
    ~Word();                                                        //Destructor for dynamic Character Array
    int getLength();                                                //function for getting string length
    Character* getArray();                                          //Function to access array outside class
    void Render(SDL_Renderer* gRenderer, bool debug);
private:
    std::string word;                                               //String word
    int stringLength;                                               //length of word
    Character* characterArray;                                      //Dynamic character array
};

