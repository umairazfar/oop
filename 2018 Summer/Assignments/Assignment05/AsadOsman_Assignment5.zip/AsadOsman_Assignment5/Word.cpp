#include <iostream>
#include "Word.h"
#include"LTexture.h"

Word::Word()
{

}

Word::Word(std::string String, LTexture* image, float x, float y)       //Word class overloaded constructor which contains the
{                                                                       //string being displayed, image, and the x y coordinates
    word = String;                                                      //string is stored in word attribute
    characterArray = new Character[word.length()];                      //a dynamic array is declared of size of the word
    for (int i = 0;(unsigned) i < word.length(); i++)                   //a loop is set to load all char as character types
    {                                                                   //within the array
        characterArray[i] = Character(image,(x + (i * 30)), y, word[i]);        //we also create spacing so that letters dont
    }                                                                           //coincide

}

Word::~Word()       //Destructor
{
    delete characterArray;              //deallocating memory
}

void Word::Render(SDL_Renderer* gRenderer, bool debug)              //Render function for word type
{
    for (int i = 0; (unsigned) i < word.length(); i++)              //at each itteration 1 character is rendered
    {
        characterArray[i].Render(gRenderer, debug);
    }
}


int Word::getLength()                           //Get length of string word
{
    return word.length();
}


Character* Word::getArray()                     //to access character outside class
{
    return characterArray;
}


