#include"Word.h"
#include<iostream>

Word::Word()
{
    width = 44;
    height = 48;
    character_value = 0;
}

Word::Word(LTexture* image, float x, float y, string str)
{
    spriteSheetTexture = image;
    character_value = 0;
    position.x = x;
    position.y = y;
    int strLength = str.length();//length of string
    charPoint = new Character[strLength];//pointer of type character points to dynamic array
    for (int i = 0; i < strLength; i++)
    {
        int ascii = (int) str[i];//ascii_code found
        charPoint[i] = Character (spriteSheetTexture, x-(strLength/2)*44 + i*44, y);//overload constructor called for every character of string
        charPoint[i].getSpriteClips(ascii);//function called
    }

    this->width = spriteClips.w;//width set according to sprite clips
    this->height = spriteClips.h;//height set according to sprite clips
}

Word::~Word()
{
    //char n = character_value + 97;
    std::cout<<"\nWord Destroyed";
    charPoint = NULL;
}

void Word::Render(long int& frame, SDL_Renderer* gRenderer, bool debug, string str)//the function that draws in SDL window
{
    int length = str.length();
    for(int i = 0; i < length; i++)
    {
        charPoint[i].Render(frame, gRenderer, false);//function called for every character of string
        if(debug == true)
        {
            SDL_Rect rect = { position.x - width/2, position.y - height/2, width, height };
            SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
            SDL_RenderDrawRect( gRenderer, &rect );
        }
    }
}

void Word::SetPosition(Point& position)
{
    this->position.x = position.x - width/2;
    this->position.y = position.y - height/2;
}

void Word::SetPosition(int x, int y)
{
    this->position.x = x - width/2;
    this->position.y = y - height/2;
}

int Word::GetFrameWidth()
{
    return width;
}
int Word::GetFrameHeight()
{
    return height;
}
