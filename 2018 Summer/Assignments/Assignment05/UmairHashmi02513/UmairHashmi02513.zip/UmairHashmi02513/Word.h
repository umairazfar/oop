#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include"LTexture.h"
#include"Point.h"
#include"Character.h"

using namespace std;
class Word
{
private:
    Point position;
    int character_value;
    int width;
    int height;
    SDL_Rect spriteClips;//object of SDL_Rect type
    LTexture* spriteSheetTexture;//pointer of type LTexture
    Character* charPoint;//pointer of type Character
public:
    Word();
    ~Word();//destructor
    Word(LTexture* image, float x, float y, string);//overload constructor
    virtual void Render(long int& frame, SDL_Renderer* gRenderer, bool debug, string);//virtual used as other classes have render function as well, to differentiate
    void SetPosition(Point&);//takes argument reference of type Point
    void SetPosition(int, int);
    int GetFrameWidth();
    int GetFrameHeight();
};

