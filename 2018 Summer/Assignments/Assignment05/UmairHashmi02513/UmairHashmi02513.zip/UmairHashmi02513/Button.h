#include"Point.h"
#include"Word.h"

using namespace std;
class Button
{
private:
    Point position;
    int character_value;
    int width;
    int height;
    SDL_Rect spriteClips[3];//array of type SDL_Rect
    LTexture* spriteSheetTexture;
    Word* wordPoint;//pointer of type Word
public:
    Button();
    ~Button();//destructor
    Button(LTexture* image, float x, float y, string );//overload constructor
    virtual void Render(long int& frame, SDL_Renderer* gRenderer, bool debug, string);
    void SetPosition(Point&);
    void SetPosition(int, int);
    int GetFrameWidth();
    int GetFrameHeight();
};
