#include"Button.h"
#include<iostream>

Button::Button()
{
    width = 44;
    height = 48;
    character_value = 0;
}

Button::Button(LTexture* image, float x, float y, string str )
{//here image is captured using sprite clips
    spriteSheetTexture = image;
    character_value = 0;
    width = 64;
    height = 64;
    spriteClips[0].x = 0;
    spriteClips[0].y = 448;
    spriteClips[0].w = width;
    spriteClips[0].h = height;

    spriteClips[1].x = 64;
    spriteClips[1].y = 448;
    spriteClips[1].w = 64;
    spriteClips[1].h = 64;

    spriteClips[2].x = 128;
    spriteClips[2].y = 448;
    spriteClips[2].w = 40;
    spriteClips[2].h = 64;
    wordPoint = new Word(image, x, y, str);//dynamic object created pointed by pointer type Word
    position.x = x;
    position.y = y;
    this->width = spriteClips[0].w;
    this->height = spriteClips[0].h;

}

Button::~Button()
{
    std::cout<<"\nButton Destroyed";
    wordPoint = NULL;
}

void Button::Render(long int& frame, SDL_Renderer* gRenderer, bool debug, string str)
{
    int length = str.length();
    int i = 0;                              //for left side of button
    spriteSheetTexture->Render( position.x-(length/2)*54 + i*54, position.y - height/2, &spriteClips[0], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)                                  //for adjusting button over word
    {
        SDL_Rect rect = { position.x-(length/2)*54 + i*54, position.y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
    for( i = 1; i < length; i++)
    {                                            //for middle side of button
        spriteSheetTexture->Render( position.x-(length/2)*54 + i*54, position.y - height/2, &spriteClips[1], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
        if(debug == true)
        {
            SDL_Rect rect = { position.x-(length/2)*54 + i*54, position.y - height/2, width, height };
            SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
            SDL_RenderDrawRect( gRenderer, &rect );
        }
    }
                                                 //for right side of button
    spriteSheetTexture->Render( position.x-(length/2)*54 + i*54, position.y - height/2, &spriteClips[2], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { position.x-(length/2)*54 + i*54, position.y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}

void Button::SetPosition(Point& position)
{
    this->position.x = position.x - width/2;
    this->position.y = position.y - height/2;
}

void Button::SetPosition(int x, int y)
{
    this->position.x = x - width/2;
    this->position.y = y - height/2;
}

int Button::GetFrameWidth()
{
    return width;
}
int Button::GetFrameHeight()
{
    return height;
}
