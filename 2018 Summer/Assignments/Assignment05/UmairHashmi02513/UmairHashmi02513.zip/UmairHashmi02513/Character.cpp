#include"Character.h"
#include<iostream>

Character::Character()
{
    width = 44;
    height = 48;
    character_value = 0;
}

Character::Character(LTexture* image, float x, float y)
{
    spriteSheetTexture = image;
    character_value = 0;
    position.x = x;
    position.y = y;

    this->width = spriteClips.w;
    this->height = spriteClips.h;
}

Character::~Character()
{
    std::cout<<"\nCharacter Destroyed";
}

void Character::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
                                            //character set to be in middle of SDL window
    spriteSheetTexture->Render( position.x - width/2, position.y - height/2, &spriteClips, 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { position.x - width/2, position.y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}

void Character::SetPosition(Point& position)
{
    this->position.x = position.x - width/2;
    this->position.y = position.y - height/2;
}

void Character::SetPosition(int x, int y)
{
    this->position.x = x - width/2;
    this->position.y = y - height/2;
}

int Character::GetFrameWidth()
{
    return width;
}
int Character::GetFrameHeight()
{
    return height;
}


void Character::getSpriteClips(int asc_code)//sprite clips found for every character
{
    width = 44;
    height = 48;
    if (asc_code >= 65 && asc_code <= 75)
    {
        int difference = asc_code - 65;
        spriteClips.x = difference * width;
        spriteClips.y = 0 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }

    if (asc_code >= 76 && asc_code <= 86)
    {
        int difference = asc_code - 76;
        spriteClips.x = difference * width;
        spriteClips.y = 1 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }

    if (asc_code >= 87 && asc_code <= 90)
    {
        int difference = asc_code - 87;
        spriteClips.x = difference * width;
        spriteClips.y = 2 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }

    if (asc_code >= 97 && asc_code <= 103)
    {
        int difference = asc_code - 97 + 4;
        spriteClips.x = difference * width;
        spriteClips.y = 2 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }

    if (asc_code >= 104 && asc_code <= 114)
    {
        int difference = asc_code - 104;
        spriteClips.x = difference * width;
        spriteClips.y = 3 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }

    if (asc_code >= 115 && asc_code <= 122)
    {
        int difference = asc_code - 115;
        spriteClips.x = difference * width;
        spriteClips.y = 4 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }

    if (asc_code >= 48 && asc_code <= 50)
    {
        int difference = asc_code - 48 + 8;
        spriteClips.x = difference * width;
        spriteClips.y = 4 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }

    if (asc_code >= 51 && asc_code <= 57)
    {
        int difference = asc_code - 51;
        spriteClips.x = difference * width;
        spriteClips.y = 5 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }

    if (asc_code == 46)
    {
        spriteClips.x = 7 * width;
        spriteClips.y = 5 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 44)
    {
        spriteClips.x = 8 * width;
        spriteClips.y = 5 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 59)
    {
        spriteClips.x = 9 * width;
        spriteClips.y = 5 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 58)
    {
        spriteClips.x = 10 * width;
        spriteClips.y = 5 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 63)
    {
        spriteClips.x = 0 * width;
        spriteClips.y = 6 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 33)
    {
        spriteClips.x = 1 * width;
        spriteClips.y = 6 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 45)
    {
        spriteClips.x = 2 * width;
        spriteClips.y = 6 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 95)
    {
        spriteClips.x = 3 * width;
        spriteClips.y = 6 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }

    if (asc_code == 46)
    {
        spriteClips.x = 7 * width;
        spriteClips.y = 5 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 44)
    {
        spriteClips.x = 8 * width;
        spriteClips.y = 5 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 59)
    {
        spriteClips.x = 9 * width;
        spriteClips.y = 5 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 58)
    {
        spriteClips.x = 10 * width;
        spriteClips.y = 5 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 63)
    {
        spriteClips.x = 0 * width;
        spriteClips.y = 6 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 33)
    {
        spriteClips.x = 1 * width;
        spriteClips.y = 6 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 126)
    {
        spriteClips.x = 2 * width;
        spriteClips.y = 6 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }

    if (asc_code == 95)
    {
        spriteClips.x = 3 * width;
        spriteClips.y = 6 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 126)
    {
        spriteClips.x = 4 * width;
        spriteClips.y = 6 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 35)
    {
        spriteClips.x = 5 * width;
        spriteClips.y = 6 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 34)
    {
        spriteClips.x = 6 * width;
        spriteClips.y = 6 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 39)
    {
        spriteClips.x = 7 * width;
        spriteClips.y = 6 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 38 )
    {
        spriteClips.x = 8 * width;
        spriteClips.y = 6 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 40 )
    {
        spriteClips.x = 9 * width;
        spriteClips.y = 6 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 41 )
    {
        spriteClips.x = 10 * width;
        spriteClips.y = 6 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 91 )
    {
        spriteClips.x = 0 * width;
        spriteClips.y = 7 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 93 )
    {
        spriteClips.x = 1 * width;
        spriteClips.y = 7 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 124 )
    {
        spriteClips.x = 2 * width;
        spriteClips.y = 7 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 96 )
    {
        spriteClips.x = 3 * width;
        spriteClips.y = 7 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 92 )
    {
        spriteClips.x = 4 * width;
        spriteClips.y = 7 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 47 )
    {
        spriteClips.x = 5 * width;
        spriteClips.y = 7 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 64 )
    {
        spriteClips.x = 6 * width;
        spriteClips.y = 7 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == -80 )
    {
        spriteClips.x = 7 * width;
        spriteClips.y = 7 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 43 )
    {
        spriteClips.x = 8 * width;
        spriteClips.y = 7 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 61 )
    {
        spriteClips.x = 9 * width;
        spriteClips.y = 7 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 42 )
    {
        spriteClips.x = 10 * width;
        spriteClips.y = 7 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 36 )
    {
        spriteClips.x = 0 * width;
        spriteClips.y = 8 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 156 )
    {
        spriteClips.x = 1 * width;
        spriteClips.y = 8 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == -128 )
    {
        spriteClips.x = 2 * width;
        spriteClips.y = 8 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 60 )
    {
        spriteClips.x = 3 * width;
        spriteClips.y = 8 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
    if (asc_code == 62 )
    {
        spriteClips.x = 4 * width;
        spriteClips.y = 8 * height;
        spriteClips.w = width;
        spriteClips.h = height;
    }
}
