#ifndef BUTTON_H
#define BUTTON_H
#include "Word.h"

class Button : public Word
{
public:
    Button();
    Button( LTexture* image, float x, float y, char* c );
    void Render( long int& frame, SDL_Renderer* gRenderer, bool debug );
    virtual ~Button();

protected:

private:
    enum buttonFrames { Start, Mid, End, Total = 3 };
    SDL_Rect spriteClips[ Total ];
    LTexture* spriteSheetTexture;
    Point position;
    Word* word;


};
#endif // BUTTON_H
