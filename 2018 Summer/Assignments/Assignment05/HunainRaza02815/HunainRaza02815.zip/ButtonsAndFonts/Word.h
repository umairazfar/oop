#ifndef WORD_H
#define WORD_H
#include "Character.h"


class Word : public Character
{
public:
    Word();
    Word( LTexture* image, float x, float y, char* c );
    void Render( long int& frame, SDL_Renderer* gRenderer, bool debug );
    int Get_wordLength();
    Character* Get_CharacterArrayPtr();

    virtual ~Word();

protected:

private:
    Character* charArray;
    int wordLength;
};

#endif // WORD_H
