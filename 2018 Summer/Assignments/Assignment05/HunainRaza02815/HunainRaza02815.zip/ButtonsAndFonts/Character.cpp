#include"Character.h"
#include<iostream>
#include <string>

Character::Character()
{
    width = 44;
    height = 48;
    character_value = 0;
}

Character::Character(LTexture* image, float x, float y, char* c)
{
    std::cout<<"character overloaded constructor  strt";
    int x_coordinate = 0;    //to set the starting x coordinate of the sprite clip
    int y_coordinate = 0;    //to set the starting y coordinate of the sprite clip
    spriteSheetTexture = image;
    character_value = int(*c);     //converts to ascii code

    if( character_value > 64 && character_value < 76 )
    {
        x_coordinate = character_value - 65;
        y_coordinate = 0;
        spriteClips.x = x_coordinate * 44;
        spriteClips.y = y_coordinate;
    }
    if( character_value > 75 && character_value <  87 )
    {
        x_coordinate = character_value - 76;
        y_coordinate = 48;
        spriteClips.x = x_coordinate * 44;
        spriteClips.y = y_coordinate;
    }
    if( character_value >  86 && character_value <  91 )
    {
        x_coordinate = character_value - 87;
        y_coordinate = 48*2;
        spriteClips.x = x_coordinate * 44;
        spriteClips.y = y_coordinate;
    }
    if( character_value >  96 && character_value <  104 )
    {
        x_coordinate = character_value - 97;
        y_coordinate = 48*2;
        spriteClips.x = 44 * 4 + x_coordinate * 44;
        spriteClips.y = y_coordinate;
    }
    if( character_value >  103 && character_value <  115 )
    {
        x_coordinate = character_value - 104;
        y_coordinate = 48*3;
        spriteClips.x = x_coordinate * 44;
        spriteClips.y = y_coordinate;
    }
    if( character_value >  114 && character_value <  123 )
    {
        x_coordinate = character_value - 115;
        y_coordinate = 48*4;
        spriteClips.x = x_coordinate * 44;
        spriteClips.y = y_coordinate;
    }
    if( character_value > 47 && character_value <  51 )
    {
        x_coordinate = character_value - 48;
        y_coordinate = 48*4;
        spriteClips.x = 44 * 8 + x_coordinate * 44;
        spriteClips.y = y_coordinate;
    }
    if( character_value > 50 && character_value <  58 )
    {
        x_coordinate = character_value - 51;
        y_coordinate = 48*5;
        spriteClips.x = x_coordinate * 44;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 46 )
    {
        x_coordinate = 7 * 44;
        y_coordinate = 48*5;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 44 )
    {
        x_coordinate = 8 * 44;
        y_coordinate = 48*5;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 59 )
    {
        x_coordinate = 9 * 44;
        y_coordinate = 48*5;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 58 )
    {
        x_coordinate = 10 * 44;
        y_coordinate = 48*5;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 63 )
    {
        x_coordinate = 0;
        y_coordinate = 48*6;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 33 )
    {
        x_coordinate = 1 * 44;
        y_coordinate = 48*6;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 45 )
    {
        x_coordinate = 2* 44;
        y_coordinate = 48*6;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 95 )
    {
        x_coordinate = 3 * 44;
        y_coordinate = 48*6;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 126 )
    {
        x_coordinate = 4 * 44;
        y_coordinate = 48*6;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 35 )
    {
        x_coordinate = 5 * 44;
        y_coordinate = 48*6;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 34 )
    {
        x_coordinate = 6 * 44;
        y_coordinate = 48*6;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 39 )
    {
        x_coordinate = 7 * 44;
        y_coordinate = 48*6;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 38 )
    {
        x_coordinate = 8 * 44;
        y_coordinate = 48*6;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value > 39 && character_value <  42 )
    {
        x_coordinate = character_value - 40;
        y_coordinate = 48*6;
        spriteClips.x = 9 * 44 + x_coordinate * 44;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 91 )
    {
        x_coordinate = 0;
        y_coordinate = 48*7;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 93 )
    {
        x_coordinate = 1 * 44;
        y_coordinate = 48*7;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 124 )
    {
        x_coordinate = 2 * 44;
        y_coordinate = 48*7;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 96 )
    {
        x_coordinate = 3 * 44;
        y_coordinate = 48*7;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 92 )
    {
        x_coordinate = 4 * 44;
        y_coordinate = 48*7;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 47 )
    {
        x_coordinate = 5 * 44;
        y_coordinate = 48*7;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 64 )
    {
        x_coordinate = 6 * 44;
        y_coordinate = 48*7;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == -80 )
    {
        x_coordinate = 7 * 44;
        y_coordinate = 48*7;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 43)
    {
        x_coordinate = 8 * 44;
        y_coordinate = 48*7;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 61 )
    {
        x_coordinate = 9 * 44;
        y_coordinate = 48*7;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 42 )
    {
        x_coordinate = 10 * 44;
        y_coordinate = 48*7;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 36 )
    {
        x_coordinate = 0;
        y_coordinate = 48*8;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 156 )
    {
        x_coordinate = 1 * 44;
        y_coordinate = 48*8;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == -128 )
    {
        x_coordinate = 2 * 44;
        y_coordinate = 48*8;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 60 )
    {
        x_coordinate = 3 * 44;
        y_coordinate = 48*8;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }
    if( character_value == 62 )
    {
        x_coordinate = 4 * 44;
        y_coordinate = 48*8;
        spriteClips.x = x_coordinate;
        spriteClips.y = y_coordinate;
    }

    spriteClips.w = 44;
    spriteClips.h = 48;


    position.x = x;
    position.y = y - spriteClips.h / 2 ; //to set at the middle

    this->width = spriteClips.w;
    this->height = spriteClips.h;
    std::cout<<"\ncharacter overloaded constructor end";
}

Character::~Character()
{
    std::cout<<"\ncharacter destructor";
    char n = character_value;
    std::cout<<"\nCharacter "<< n <<" Destroyed";
}

void Character::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    std::cout<<"\ncharacter render";
    spriteSheetTexture->Render( position.x, position.y, &spriteClips, 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if( debug == true )
    {
        SDL_Rect rect = { position.x, position.y, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}

void Character::SetPosition( Point& position )
{
    this->position.x = position.x - width/2;
    this->position.y = position.y - height/2;
}

void Character::SetPosition( int x, int y )
{
    this->position.x = x - width/2;
    this->position.y = y - height/2;
}

int Character::GetFrameWidth()
{
    return width;
}
int Character::GetFrameHeight()
{
    return height;
}
int Character::GetCharacterValue()
{
    return character_value;
}
