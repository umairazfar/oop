#include "Button.h"
#include <iostream>
#include <string.h>



Button::Button()
{

}


Button::Button( LTexture* image, float x, float y, char* cstring )
{
    std::cout<<"\nButton constructor";
    spriteSheetTexture = image;
    position.x = x;
    position.y = y - 50 / 2;
    word = new Word( spriteSheetTexture, x, y, cstring ); //dynamic word created from arguments passed in the button constructor


    spriteClips[Start].x = 0;
    spriteClips[Start].y = 444;
    spriteClips[Start].w = 64;
    spriteClips[Start].h = 50;

    spriteClips[Mid].x = 20;
    spriteClips[Mid].y = 444;
    spriteClips[Mid].w = 64;
    spriteClips[Mid].h = 50;

    spriteClips[End].x = 89;
    spriteClips[End].y = 444;
    spriteClips[End].w = 64;
    spriteClips[End].h = 50;

    std::cout<<"\nButton constructor end";
}

Button::~Button()
{
    std::cout<<"\nButton destructor";

    delete[] word->Get_CharacterArrayPtr();
    delete word;
}

void Button::Render( long int& frame, SDL_Renderer* gRenderer, bool debug )
{
    std::cout<<"\nButton render strt";

    int wordLength = word->Get_wordLength();
    int startingXposition = ( position.x - ( wordLength * 64 ) / 2 ) - 64; //starting x position to render first clip which is the start of the button
    spriteSheetTexture->Render( startingXposition, position.y, &spriteClips[Start], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    startingXposition = startingXposition + 64; //first sprite clip has 64 width so added 64
    for ( int i = 0; i < wordLength; i++ )
    {
        spriteSheetTexture->Render( startingXposition + i * 64, position.y, &spriteClips[Mid], 0.0, NULL, SDL_FLIP_NONE, gRenderer ); //rendering the middle part of the button which will have the word
    }

    word->Render( frame, gRenderer, debug );

    startingXposition = startingXposition + ( wordLength ) * 64;
    spriteSheetTexture->Render( startingXposition, position.y, &spriteClips[End], 0.0, NULL, SDL_FLIP_NONE, gRenderer ); //rendering end part which will have the end part of the button

}

