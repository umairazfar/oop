#include "Word.h"
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <string.h>

Word::Word()
{

}
Word::Word( LTexture* image, float x, float y, char* cstringPassed )
{
    std::cout<<"\nWord overloaded constructor strt";
    wordLength = strlen( cstringPassed );   //gets the wordlength of the string passed
    std::cout<<"\nword length: "<<wordLength;
    float starting_Xcoordinate = x - ( wordLength * 64 ) / 2 + 10;  //starting position of the word to be rendered character width 44 button segment width 64 so +10
    charArray = new Character[ wordLength ];


    for( int i = 0; i < wordLength; i++ )
    {
        std::cout<<"\nLoop: "<<i<<std::endl;
        char temp = cstringPassed[i];
        charArray[i] = Character( image, starting_Xcoordinate + ( i * 64 ), y, &temp );  //initializes the character in the character array
    }

    std::cout<<"\nword constructor end";
}
void Word::Render( long int& frame, SDL_Renderer* gRenderer, bool debug )
{
    std::cout<<"\nword render strt";
    for( int i = 0; i < wordLength; i++ )
    {
        charArray[i].Render( frame, gRenderer, debug );  //renders all the characters in the array
    }
    std::cout<<"\nword render end";
}
int Word::Get_wordLength()
{
    return wordLength;
}
Character* Word::Get_CharacterArrayPtr()
{
    return charArray;
}
Word::~Word()
{
    std::cout<<"\nword destructor";
}
