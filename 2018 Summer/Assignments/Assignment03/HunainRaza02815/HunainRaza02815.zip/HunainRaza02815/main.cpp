#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

using namespace std;

struct Box
{
    int length;
    int width;
    int height;

    Box()
    {
        length = rand() %26 + 5;
        width =  rand() %26 + 5;
        height =  rand() %26 + 5;
    }


    int Volume()
    {
        return (length * width *height);
    }
};

struct Truck
{
    char driver[32];
    int petrol;
    int money;
    int fullMileage;
    int emptyMileage;
    int numBox;
    Box box;
    Box* boxPtr;


    void Load()
    {
        numBox = rand()  %9 + 12;
        boxPtr = new Box[numBox];
    }
    void Unload()
    {
         int TotalVolume = 0;
         for(int i = 0; i < numBox; i++)
        {
            TotalVolume = TotalVolume + boxPtr[i].Volume();
        }
        cout<<"Total Volume of all Packages delivered: "<<TotalVolume<<endl;

        delete[] boxPtr;
        boxPtr = NULL;

    }

    float Cost()
    {
        cout<<"Cost for the trip: "<< (60.0 / fullMileage + 60.0 / emptyMileage) * 2.73 <<"$\n"<< endl;
    }
};

int LineCounter(char* fileName)
{
    FILE* filePointer;                          //Declaring a file pointer
    char buff[32];                              //Declaring a character array to store a line

    filePointer = fopen(fileName, "r");         //Opening file as read only

    if (filePointer == NULL)                    //If file is not found
    {
        perror ("Error opening file");          //Show Error
        return 0;
    }

    int counter = 0;                            //Counts the lines in file

    while(fgets(buff, 32, (FILE*)filePointer) !=NULL)   //If line read is not NULL
    {
        counter++;                                      //increase line count
    }
    fclose(filePointer);                                //close file when done
    return counter;                                     //return line count
}
void writing_to_array_of_trucks(Truck* ural, FILE* &filePointer, char* buff, int &i ) //writing information to trucks in the array
{
    fgets(ural[i].driver, 32, (FILE*)filePointer); //Reading the name of the driver directly
    cout << "Truck driver is: " << ural[i].driver;
    fgets(buff, 32, (FILE*)filePointer);        //Reading the next line as string
    ural[i].petrol = atoi(buff);                   //Converting the string to integer
    cout << "Truck petrol is: " << ural[i].petrol<<endl;
    fgets(buff, 32, (FILE*)filePointer);
    ural[i].money = atoi(buff);
    cout << "Truck money is: " << ural[i]. money<<endl;

    fgets(buff, 32, (FILE*)filePointer);
    ural[i].fullMileage = atoi(buff);
    cout << "Truck full mileage is: " << ural[i].fullMileage<<endl;
    fgets(buff, 32, (FILE*)filePointer);
    ural[i].emptyMileage = atoi(buff);
    cout << "Truck empty mileage is: " << ural[i].emptyMileage<<endl;
}
void fillingTrucks(Truck* ural, double &petrolRequiredForJourney, double &petrolNeededForFullTank, double &petrolHeCanFill, int &i)
{
    petrolRequiredForJourney = 60.0 / ural[i].fullMileage + 60.0 / ural[i].emptyMileage; //calculating petrol required for full journey
    cout<<"petrol required for journey: "<<petrolRequiredForJourney<<endl;

    petrolNeededForFullTank = 50.0 - ural[i].petrol;
    cout<<"petrol Needed For Full Tank: "<<petrolNeededForFullTank<<endl;
    petrolHeCanFill = ural[i].money / 2.73;

    if(petrolNeededForFullTank == 0)

        cout<<"Tank full"<<endl;

    else if (petrolHeCanFill >= petrolNeededForFullTank)  //tank fulled
    {
        ural[i].petrol = 50;
        cout<<"He filled "<<petrolNeededForFullTank<<" liters of petrol" <<endl<<"Tank full"<<endl; //petrol filled in fulling the tank
        ural[i].money = ural[i].money - (petrolNeededForFullTank * 2.73);
    }

    else if(petrolHeCanFill < petrolNeededForFullTank)
    {
     cout<<"He filled "<<petrolHeCanFill<<" liters of petrol" <<endl;
     ural[i].petrol = ural[i].petrol + petrolHeCanFill;  //adding petrol in tank
     ural[i]. money = ural[i].money - (petrolHeCanFill * 2.73); //deducting money in filling petrol
     cout<<"Petrol in Tank: "<< (ural[i].petrol) <<endl;
    }
}
void Package_delivery(Truck* ural, int &i, int* allowedTrucks)
{

    cout << "Truck driver is: " << ural[allowedTrucks[i]].driver;
    ural[allowedTrucks[i]].Load();
    cout<<"Packages Loaded\n"<<endl;
    ural[allowedTrucks[i]].Unload();
    cout<<"\nPackages unloaded\n"<<endl;
    ural[allowedTrucks[i]].Cost();
}

int main()
{
    srand(time(NULL));


    int numOfTrucks = (LineCounter("Drivers.txt")) / 5 ;

    Truck* ural = new Truck[numOfTrucks];

    int* allowedTrucks = new int[numOfTrucks] ;
    int allowedTrucksCounter = 0;


    FILE* filePointer;                          //Declaring a file pointer
    char buff[32];                              //Declaring a character array to store a line

    filePointer = fopen("Drivers.txt", "r");    //Opening file as read only

    if (filePointer == NULL)
    {
        perror ("Error opening file");
        return 0;
    }

     double petrolRequiredForJourney;
     double petrolHeCanFill;
     double petrolNeededForFullTank;

    for(int i = 0; i < numOfTrucks; i++) //for all the trucks in the array
    {
        writing_to_array_of_trucks(ural, filePointer, buff, i);

        fillingTrucks(ural, petrolRequiredForJourney, petrolNeededForFullTank, petrolHeCanFill, i);


        if (petrolRequiredForJourney > ural[i].petrol)

             cout<<"\nCant make the Journey\n"<<endl;

        else
        {
            cout<<"\nHe CAN make the journey\n"<<endl;
            allowedTrucks[allowedTrucksCounter] = i; //storing the truck index to the allowed truck array
            allowedTrucksCounter ++; //incrementing to store the next allowed truck on the next index in the allowed truck array.

        }



    }
     for(int i = 0; i < allowedTrucksCounter; i++)
    {

        Package_delivery(ural, i, allowedTrucks);
    }


    delete[] ural;
    delete[] allowedTrucks;
    cout<<"\nTrucks deallocated\n"<<endl;
    ural = NULL;
    allowedTrucks = NULL;


    fclose(filePointer);                        //Closing file
    return 0;
}

