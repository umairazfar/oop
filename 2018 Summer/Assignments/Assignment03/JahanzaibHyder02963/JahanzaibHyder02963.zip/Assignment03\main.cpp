#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random>
#include "Box.h"
#include "Trucks.h"

using namespace std;

int LineCounter(char* fileName)                 //This function will count the no of lines in the file.
{
    FILE* filePointer;                          //Declaring a file pointer
    char buff[32];                              //Declaring a character array to store a line

    filePointer = fopen(fileName, "r");         //Opening file as read only

    if (filePointer == NULL)                    //If file is not found
    {
        perror ("Error opening file");          //Show Error
        return 0;
    }

    int counter = 0;                            //Counts the lines in file

    while(fgets(buff, 32, (FILE*)filePointer) !=NULL)   //If line read is not NULL
    {
        counter++;                                      //increase line count
    }
    fclose(filePointer);                                //close file when done
    return counter;                                     //return line count
}

int main()
{
    srand(time(NULL));                                  //For Creating Random Seed

    int LineCount = LineCounter("Drivers.txt");         //Total No. Of lines is stored in a integer.

    Trucks* Truck = new Trucks[LineCount/5];            //Will Create a dynamic Array having the no. of drivers as in the file

    FILE* filePointer;                          //Declaring a file pointer
    char buff[32];                              //Declaring a character array to store a line

    filePointer = fopen("Drivers.txt", "r");    //Opening file as read only

    if (filePointer == NULL)                    //error check
    {
        perror ("Error opening file");
        return 0;
    }
    for (int j = 0; j < LineCount/5; j++)       //Depending the no. of drivers, the loop will run that many times
    {
        fgets(Truck[j].driver, 32, (FILE*)filePointer); //Reading the name of the driver directly

        fgets(buff, 32, (FILE*)filePointer);        //Reading the next line as string
        Truck[j].petrol = atoi(buff);                   //Converting the string to integer
                                                        //The data is also stored in the truck array simultaneously using Truck[j].petrol and etc
        fgets(buff, 32, (FILE*)filePointer);
        Truck[j].money = atoi(buff);

        fgets(buff, 32, (FILE*)filePointer);
        Truck[j].fullMileage = atoi(buff);

        fgets(buff, 32, (FILE*)filePointer);
        Truck[j].emptyMileage = atoi(buff);

        Truck[j].Load( ( rand() % 9 ) + 12 );                   //Random no. of boxes from 12 - 20 will be loaded on the truck

        cout << "Truck driver is: " << Truck[j].driver; //The data of that that element of driver array is printed on the screen
        cout << "Truck petrol is: " << Truck[j].petrol<<endl;
        cout << "Truck money is: " << Truck[j].money<<endl;
        cout << "Truck full mileage is: " << Truck[j].fullMileage<<endl;
        cout << "Truck empty mileage is: " << Truck[j].emptyMileage<<endl;
        cout << "The volume of each box in truck is: ";
        Truck[j].Unload(); //The truck is unloaded here and Boxes is de allocated
        cout << endl;
        Truck[j].Cost(); //This will show the total cost of the journey, if driver can do the journey.

        cout << endl;
    }
    fclose(filePointer);                        //Closing file
    delete[] Truck; //the array of truck is deallocated and memory is made free
    return 0;
}
