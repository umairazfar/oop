#ifndef BOX_H
#define BOX_H


class Box
{
public:
    int length; //attributes and function of the class defined here
    int width;
    int height;
    Box();
    int Volume();
};

#endif // BOX_H
