/**

* OOP - Assignment 3
* Summer Semester 2018 - Habib University
* Instructor Dr. Umair Azfar - TA Nabiha Shahid

* Jahanzaib Hyder - jh02963

* Due Date 20th June (1200 pm)

**/


#include "Trucks.h"
#include "Box.h"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random>

using namespace std;

void Trucks::Load(int boxes) //This constructor will construct the no of boxes as given in the argument
{
    this->pkg = new Box[boxes];
    TotalBoxes = boxes;
    for (int i = 0; i < boxes; i++)
    {
        pkg[i] = Box();
    }
}

void Trucks::Unload() //This will print the volume of that object of the box and then will then delete the array at the end
{                       //unloading the truck
    for (int j = 0; j < TotalBoxes; j++)
    {
        cout << this->pkg[j].Volume() << " ";
    }
    delete[] pkg;
}

float Trucks::Cost() //This function print the cost of the journey, if driver can do the journey
{                    // else it will show that driver is not able to do the joutney
    TotalFuelConsupmtion = 60/(float)fullMileage + 60/(float)emptyMileage; //will count how many fuel will it need throughout the journey
    if (2.73 * ( 50 - this->petrol ) <= this->money) //this condition Will be true if driver have money to buy the extra petrol to full the tank
    {
        TotalCost = TotalFuelConsupmtion + ( 50 - this->petrol );
        cout << "Fuel to be used from the Storage is " << TotalFuelConsupmtion << endl;
        cout << "Cost of Total Fuel Bought: " << 2.73 * (50 - this->petrol) << endl;
        cout << "Cost of Total Fuel Consumption: " << TotalCost * 2.73 << endl;
        cout << "/// Driver can do the Journey ///" << endl;
        this->petrol = 50;
    }
    else
    {
        cout << "/// Due to insufficient resources driver cannot do the Journey ///" << endl;
    }
}
