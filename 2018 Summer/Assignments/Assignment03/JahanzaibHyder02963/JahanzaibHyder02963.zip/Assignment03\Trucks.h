#ifndef TRUCKS_H
#define TRUCKS_H
#include "Box.h"

class Trucks
{
public:
    char driver[32]; //attributes and function of the class defined here
    int petrol;
    int money;
    int fullMileage;
    int emptyMileage;
    int TotalBoxes;
    float TotalCost;
    Box* pkg;
    float TotalFuelConsupmtion;
    Box box;
    void Load(int);
    void Unload();
    float Cost();
};

#endif // TRUCKS_H
