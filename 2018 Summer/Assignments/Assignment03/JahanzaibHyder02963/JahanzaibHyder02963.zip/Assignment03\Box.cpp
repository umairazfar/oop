#include "Box.h"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random>

using namespace std;

Box::Box() //This constructor will create a box of random dimension
{
    this->length = this->width = this->height = (rand() % 26) + 5;
}

int Box::Volume() //This will return the volume of that object of the box
{
    return this->length * this->width * this->height;
}
