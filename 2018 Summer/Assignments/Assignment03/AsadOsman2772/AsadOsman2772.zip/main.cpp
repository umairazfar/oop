#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

using namespace std;

const float petrolCost = 2.73;                              //Constants set for Petrol rate and Maximum Capacity of petrol in truck
const int MaxPetrolCapacity = 50;


struct Box                                                  //Structure for Box data type is created, Box type has 3 properties
{
                                                            //length, width, and height
    int length;
    int width;
    int height;

    Box()                                                   //Constructor is created which assigns random values between 5 and 30
    {
                                                            //for the dimensions
        length = (rand() % 26) + 5;
        width = (rand() % 26) + 5;
        height = (rand() % 26) + 5;
    }


    int Volume()                                            //Function volume is created which calculates and returns the volume
    {
                                                            //of the box
        int volume = length * width * height;
        return volume;
    }
};

struct Truck                                                //Structure for Truck data type is created, it has 6 properties
{
                                                            //a character array for the driver name, petrol, money, mileage when
    char driver[32];                                        //full, mileage when empty.
    float petrol;
    float money;
    float fullMileage;
    float emptyMileage;

    Box* DarrBoxes = NULL;                                  //A pointer array for boxes is given an address NULL

    Truck()                                                 //Constructor for Truck is created, this gives all the
    {                                                       //properties default values
        char driver [] = "No Driver";
        petrol = 0;
        money = 0;
        fullMileage = 0;
        emptyMileage = 0;
    }

    void Load(int numBox)                                   //A function for loading boxes on truck is defined
    {
        int totalVolume = 0;                                //A variable for total volume of boxes
        DarrBoxes = new Box[numBox];                        //A dynamic array for boxes with length numBox is defined
                                                            //numBox is the number of boxes loaded on the truck

        for (int i = 0; i < numBox; i++)                    //A loop is defined to load all the boxes into the dynamic array
        {
                                                            //and add the individual volumes of each box
            Box a;
            DarrBoxes[i] = a;
            totalVolume = totalVolume + a.Volume();
        }
        cout << "Total Volume of boxes is " << totalVolume << " Inches squared" << endl;        //Total volume is displayed
    }
    void Unload()                                                                       //A function that unloads the boxes off the truck, this basically
    {
         delete[] DarrBoxes;                                                            //means that dynamic arrays addresses are reset
    }

    float Cost()                                                    //A function cost is set to determine and output the total cost of
    {
                                                                    //the journey

        float fullLiters = 60 / fullMileage;                        //Liters required for journey with the boxes
        float emptyLiters = 60 / emptyMileage;                      //Liters required for journey without the boxes

        float requiredLiters = (fullLiters) + (emptyLiters);        //Total required liters of petrol
        float extraLiters = MaxPetrolCapacity - petrol;             //Number of liters needed to be add over the initial amount
        float extraCost = extraLiters * petrolCost;                 //Cost of adding those extra liters


        if ((petrol < MaxPetrolCapacity) && money > 0)      //This loop adds the number of liters required to the petrol tank
        {
                                                            //and also decreases the money supply with the cost of the petrol
            petrol = petrol + extraLiters;
            money = money - extraCost;
        }


        if (money < 0)                                      //If the money value is negative then driver cannot buy the petrol
        {
                                                            //Meaning he cannot start the journey without filling up the tank
            cout << "Journey is not Possible" << endl;      //Petrol is set back as no petrol was bought
            petrol = petrol - extraLiters;
            return 0;
        }
        while (petrol >= requiredLiters)                    //This loop checks whether the tank is full, if it is full then
        {
                                                            //journey is possible.
            cout<<"Journey is Possible"<<endl;

            int crates = (rand() % 9) + 12;                 //Number crates is randomly generated
            Load(crates);                                   //Crates are loaded onto the truck
            cout << crates << " boxes have been loaded onto the truck" << endl;       //Number of crates loaded is displayed

            petrol = petrol - (fullLiters);                 //petrol used for first half of the trip is subtracted
            cout << "Journey with Boxes consumed " << fullLiters << " liters, leaving the truck with " << petrol << " liters" << endl;    //Liters used and Liters left are displayed

            Unload();                                       //Boxes are unloaded and removed from dynamic array
            cout << "Cargo is unloaded after travelling 60 km" << endl;             //Halfway point is displayed

            petrol = petrol - (emptyLiters);                //petrol used for second half is subtracted
            cout << "Journey without Boxes consumed " << emptyLiters << " liters, leaving the truck with " << petrol << " liters" << endl;    //Liters used and Liters left are displayed

            cout << "The total cost of the journey was " << extraCost << "$" << endl;       //Total cost is displayed, this the cost to fill up the tank
            break;                                          //Loop is broken
        }

    }
};

int LineCounter(char* fileName)
{
    FILE* filePointer;                          //Declaring a file pointer
    char buff[32];                              //Declaring a character array to store a line

    filePointer = fopen(fileName, "r");         //Opening file as read only

    if (filePointer == NULL)                    //If file is not found
    {
        perror ("Error opening file");          //Show Error
        return 0;
    }

    int counter = 0;                            //Counts the lines in file

    while(fgets(buff, 32, (FILE*)filePointer) != NULL)   //If line read is not NULL
    {
        counter++;                                      //increase line count
    }
    fclose(filePointer);                                //close file when done
    return counter;                                     //return line count
}

int main()
{
    srand(time(NULL));

    Truck ural;                                 //Truck object is defined

    FILE* filePointer;                          //Declaring a file pointer
    char buff[32];                              //Declaring a character array to store a line

    filePointer = fopen("Drivers.txt", "r");    //Opening file as read only

    if (filePointer == NULL)                    //Error check is set
    {
        perror ("Error opening file");
        return 0;
    }
    char txtFileArray[32] = "Drivers.txt";                  //This is to convert string to char, this was to remove warnings
    int numEntries = (LineCounter(txtFileArray) / 5);       //Number of entries (drivers) is determined

    Truck* DarrTrucks = NULL;                               //A NULL pointer is set for dynamic array for trucks
    DarrTrucks = new Truck[numEntries];                     //Dynamic array is created with length number of entries

    for (int i = 0; i < (numEntries); i++)                  //This loop is to load all entries into the dynamic array
    {

        fgets(ural.driver, 32, (FILE*)filePointer); //Reading the name of the driver directly

        fgets(buff, 32, (FILE*)filePointer);        //Reading the next line as string
        ural.petrol = atoi(buff);                   //Converting the string to integer

        fgets(buff, 32, (FILE*)filePointer);        //Reading the next line as string
        ural.money = atoi(buff);                    //Converting the string to integer

        fgets(buff, 32, (FILE*)filePointer);        //Reading the next line as string
        ural.emptyMileage = atoi(buff);             //Converting the string to integer

        fgets(buff, 32, (FILE*)filePointer);        //Reading the next line as string
        ural.fullMileage = atoi(buff);              //Converting the string to integer

        DarrTrucks[i] = ural;                       //Truck is loaded into the array

        cout<<"--------------------------------------------------------"<<endl;     //Formatting for essential data being
        cout << "Truck driver is: " << ural.driver;                                 //displayed
        cout << "Truck petrol is: " << ural.petrol<< endl;
        cout << "Truck money is: " << ural.money<< endl;
        cout << "Truck full mileage is: " << ural.fullMileage<< endl;
        cout << "Truck empty mileage is: " << ural.emptyMileage<< endl;
        cout << endl;

        DarrTrucks[i].Cost();       //Cost function is called for each individual truck
        cout << "--------------------------------------------------------" << endl;
        cout << endl;

    }

    delete[] DarrTrucks;        //Trucks addresses in dynamic array are removed
    fclose(filePointer);        //Text file is closed

    return 0;
}
