#include "Truck.h"

Truck::Truck()
{
    //ctor
}

Truck::~Truck()
{
    //dtor
}
