#include "Box.h"

Box::Box()
{
    //ctor
}

Box::~Box()
{
    //dtor
}
