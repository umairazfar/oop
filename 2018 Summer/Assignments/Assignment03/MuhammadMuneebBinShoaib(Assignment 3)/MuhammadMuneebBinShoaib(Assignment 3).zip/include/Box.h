#ifndef BOX_H
#define BOX_H


class Box
{
    public:
        Box();
        virtual ~Box();

    protected:

    private:
};

#endif // BOX_H
