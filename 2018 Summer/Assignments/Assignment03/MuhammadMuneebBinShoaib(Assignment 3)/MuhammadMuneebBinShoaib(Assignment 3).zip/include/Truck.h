#ifndef TRUCK_H
#define TRUCK_H
#pragma once


class Truck
{
    private:
        int petrol;
        float cost;


        virtual ~Truck();

    public:
        Truck();

};

#endif // TRUCK_H
