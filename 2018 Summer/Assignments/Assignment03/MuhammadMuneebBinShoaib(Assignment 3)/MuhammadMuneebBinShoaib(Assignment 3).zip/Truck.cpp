#include "Truck.h"
#include "Box.h"
#include <iostream>
#include <time.h>
#include <stdlib.h>

using namespace std;

Truck::Truck()
{
    num_boxes = (rand() % 9)+ 12;
    package = new Box[num_boxes];
}

float Truck::Cost()
{
    float cost=0;
    if (petrol<50)
    {
        cost = cost +(50-petrol)*2.73 + (60/fullMileage)*2.73 + (60/emptyMileage)*2.73;
    }
    else
    {
        cost = cost + (60/fullMileage)*2.73 + (60/emptyMileage)*2.73;
    }

    return cost;

}

void Truck::Load(int numBox)
{
    //package = new Box[numBox];
    for (int i=0; i<numBox; i++)
    {
        package[i] = Box();
    }

}

void Truck::Unload()
{
    for(int i=0; i<num_boxes; i++)
    {
        cout << package[i].Volume()<< ' ';
    }
    cout << "cubic inches" << endl;

}
Truck::~Truck()
{
    delete[] package;
}
