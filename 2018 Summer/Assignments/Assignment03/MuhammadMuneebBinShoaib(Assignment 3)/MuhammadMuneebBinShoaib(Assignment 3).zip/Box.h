#ifndef BOX_H
#define BOX_H
#pragma once


class Box                // Class of Box is declared.
{
    public:
        int length;               // attributes are introduced for dimensions of box.
        int width;
        int height;

    public:
        Box();                       // constructor of box. It initializes the random dimensions of a box.
        int Volume();             // returns the volume of a box.

        virtual ~Box();
};

#endif // BOX_H
