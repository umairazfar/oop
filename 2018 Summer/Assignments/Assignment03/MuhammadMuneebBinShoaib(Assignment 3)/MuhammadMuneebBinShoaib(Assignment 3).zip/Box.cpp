#include "Box.h"
#include <time.h>
#include <stdlib.h>

Box::Box()
{
    for (int i =0; i<3; i++)
    {
        int random = (rand() % 26) + 5;
        if (i==0)
        {
            length = random;
        }
        else if (i==1)
        {
            width = random;
        }
        else
        {
            height = random;
        }

    }

}

int Box::Volume()
{
    int vol = length*width*height;
    return vol;
}



Box::~Box()
{
}
