#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include<fstream>
#include "Truck.h"
#include "Box.h"

using namespace std;

int LineCounter(const char* filename)              // This function returns the no. of lines in the given "Drivers.txt" file.
{
    string line;
    ifstream readfile;
    int counter= 0;
    readfile.open(filename);
    while (getline(readfile,line))
    {
        counter ++;
    }
    readfile.close();
    return counter;
}

int main()
{
    cout << endl;
    cout << "X---------- X ----------X" << endl;
    cout << endl;
    cout << "Welcome to Package Delivery System" << endl;
    cout << endl;
    srand(time(NULL));
    float totalcost_trip = 0;
    int counters = LineCounter("Drivers.txt");
    int counts = (counters)/5;
    cout << "No. of Truck Drivers are "  << counts << endl;
    cout << endl;
    FILE* filePointer;                          //Declaring a file pointer
    char buff[32];                              //Declaring a character array to store a line
    filePointer = fopen("Drivers.txt", "r");    //Opening file as read only
    if (filePointer == NULL)
    {
        perror ("Error opening file");
        return 0;
    }
    Truck* trucks = new Truck[counts];
    for (int i=0; i<counts; i++)
    {
        cout << "The details of No. " << i+1 << " driver are:" << endl;

        fgets(trucks[i].driver, 32, (FILE*)filePointer);

        fgets(buff, 32, (FILE*)filePointer);        //Reading the next line as string
        trucks[i].petrol = atoi(buff);

        fgets(buff, 32, (FILE*)filePointer);
        trucks[i].money = atoi(buff);

        fgets(buff, 32, (FILE*)filePointer);
        trucks[i].emptyMileage = atoi(buff);

        fgets(buff, 32, (FILE*)filePointer);
        trucks[i].fullMileage = atoi(buff);

        cout << "Truck driver is: " << trucks[i].driver;                          // Truck details are showed.
        cout << "Truck petrol is: " << trucks[i].petrol<<endl;
        cout << "Truck money is: " << trucks[i].money<<endl;
        cout << "Truck full mileage is: " << trucks[i].fullMileage<<endl;
        cout << "Truck empty mileage is: " << trucks[i].emptyMileage<<endl;
        cout << endl;
        cout <<"The journey will take the cost of " << trucks[i].Cost() << " $" << endl;
        if (trucks[i].Cost()<trucks[i].money || trucks[i].Cost()==trucks[i].money)                  // Show the whole journey of the truck
        {
            cout <<"The driver has enough funds to make the journey !" << endl;
            cout << endl;
            cout << "First Driver needs to fill " << 50-trucks[i].petrol << " lit more to full the tank" << endl;
            cout << "JOURNEY STARTS" << endl;
            cout <<  "1) It will load the packages" << endl;
            trucks[i].Load(trucks[i].num_boxes);
            cout << "2) Then it will make the " << trucks[i].fullMileage << " km of full Mileage" << endl;
            cout << "3) Before return, it will unload the packages"<< endl;
            cout << "Unloading Packages : ";
            trucks[i].Unload();
            cout << endl;
            cout << "On return it will make the " << trucks[i].emptyMileage <<" km of empty Mileage" << endl;
            cout <<"The journey took the cost of " << trucks[i].Cost() << " $" << endl;
            cout << endl;
            cout << "X---------- X ----------X" << endl;
            cout << endl;
        }
        else
        {
            cout << trucks[i].driver << " cannot do the journey" << endl;
        }
        totalcost_trip = totalcost_trip + trucks[i].Cost();
    }
    cout << "Total Cost of the trip is " << totalcost_trip << endl;
    fclose(filePointer);
    delete[] trucks;
    return 0;
}
