/*****
By: S.M.Umair Hashmi I.D:sh02513 OOP Assignment 3
The result is created in console. To obtain result we first take input from 'Drivers.txt' file.
That input is used to obtain the result.
*****/
/**
this can also be done in different files using header files that is also included in folder by name 'oopsasss3' just run the .cbp file
**/
#include <iostream>
#include <stdio.h>
#include <fstream>
#include <stdlib.h>
using namespace std;
//the structs of Box and Truck could have been made in different header files and inputted here but as these are structs so no
//private components so it can be done here (if these had been classes then they could have been made here as well)
struct Box  //struct used as no private components required
{
    int length;//length of box
    int width;//width of box
    int height;//height of box
    Box()//default constructor
    {
        //as these are boxes so have width, length, height
        length = 5 + rand() % 25;//length can be between 5 and 30 inclusive
        width = 5 + rand() % 25;//width can be between 5 and 30 inclusive
        height = 5 + rand() % 25;//height can be between 5 and 30 inclusive
    }
    int Volume()//function
    {
        int volume = 0;
        volume = length * width * height;
        return volume;//returns the volume of box
    }
};

struct Truck//struct used as no private components required
{
    char driver[32];//character array
    float petrol;//variables required
    float money;
    float fullMileage;
    float emptyMileage;
    Box box;//an object of data type Box
    Box* boxArray = NULL;//Array pointer put to NULL

    void Load(int numBox)//takes in no. of boxes
    {
        int totalVolume = 0;//a variable totalVolume set to 0
        boxArray = new Box[numBox];//creating dynamic array of boxes
        for (int i = 0; i < numBox; i++)
        {
            boxArray[i] = box;//each box is inputted into array through its dimensions
            totalVolume = totalVolume + box.Volume();//using dimensions volume of box obtained
        }   //that volume is added to volume of next box i.e. total volume obtained.
        cout << "the total volume of the boxes is: " << totalVolume<<endl;
    }
    void Unload()
    {
        delete[] boxArray;//unlocks the memory where array lies now computer can add anything anytime to it
    }
    float Cost()//function
    {
        int literloaded = 0;
        int literemptty = 0;
        literloaded = 60/fullMileage;//60 km divided by kilometers per liter gives liters consumed when loaded
        literemptty = 60/emptyMileage;//60 km divided by kilometers per liter gives liters consumed when empty
        int totallitre = 0;
        totallitre = literloaded + literemptty;//liters used for complete journey
        int totalcost = 0;
        totalcost = totallitre*2.73;//liters used converted to money
        if (totallitre <= petrol)//if petrol needed is less than petrol already in truck
        {
            cout << "There is enough fuel for the journey" << endl;
            int boxes = 0;
            boxes = 12 + rand() % 8;//no. of boxes between 12 and 20 inclusive
            cout << boxes <<" Boxes being loaded" << endl;//packages loaded
            Load(boxes);//Load function called
            cout<<"The boxes are being unloaded"<<endl;
            cout << "The total fuel consumed is:" << totallitre <<" liters"<< endl;
            cout << "The total cost of the journey is:$ " << totalcost << endl;
            Unload();//Unload function called
        }
        else if (totallitre > petrol && totalcost <= money)//petrol needed is more than available and the money that driver has is more than cost of journey
        {
            cout << "There is not enough fuel for the journey" << endl;
            cout << "Buying fuel" << endl;
            int litreneeded=0;
            litreneeded=50 - petrol;//liter required to make petrol 50 liters
            int moneyneeded=0;
            moneyneeded = 2.73 * litreneeded;//money required to make petrol 50 liters
            if (moneyneeded <= money)//as if needed fuel is more than available it will be bought but when buying fuel it makes tank full so money required to have 50 liters
            {
                int MoneyLeft = 0;
                MoneyLeft = money - moneyneeded;//money left after buying petrol
                cout << "Bought:" << litreneeded << " liters" <<endl;
                cout << "the fuel cost was:$ " << moneyneeded <<endl;
                int boxes = 0;
                boxes = 12 + rand() % 8;//12 to 20 boxes generated
                cout << boxes<<" Boxes being loaded" << endl;
                Load(boxes);//Load function called
                cout << "Boxes are unloaded, the volume of the boxes are:" <<endl;
                Unload();//Unload function called
                cout << "The total fuel consumed is:" << totallitre <<" liters"<< endl;
                cout << "The total cost of the journey is:$ " << moneyneeded << endl;
                cout << "The remaining funds are:$ " << MoneyLeft << endl;
            }
            else
            {
                cout << "no travel" << endl;
            }
        }
        else if(totallitre > petrol && totalcost > money)//less money than needed and less petrol than needed
        {
            cout << "no travel" << endl;
        }
    }
};

int LineCounter(char* fileName)
{
    FILE* filePointer;                          //Declaring a file pointer
    char buff[32];                              //Declaring a character array to store a line

    filePointer = fopen(fileName, "r");         //Opening file as read only

    if (filePointer == NULL)                    //If file is not found
    {
        perror ("Error opening file");          //Show Error
        return 0;
    }

    int counter = 0;                            //Counts the lines in file

    while(fgets(buff, 32, (FILE*)filePointer) != NULL)   //If line read is not NULL
    {
        counter++;                                      //increase line count
    }
    fclose(filePointer);                                //close file when done
    return counter;                                     //return line count
}

int main()
{
    int no_of_lines = 0;
    no_of_lines = LineCounter((char *)"Drivers.txt");//Declaring a character array to store a line
    cout<<"No. of lines in the file: "<<no_of_lines<<endl;
    FILE* filePointer;                          //Declaring a file pointer
    char buff[32];
    filePointer = fopen("Drivers.txt", "r");    //Opening file as read only
    if (filePointer == NULL)//if file not found
    {
        perror ("Error opening file");//show error
        return 0;
    }
    else
    {
        int data = 0;
        data = no_of_lines/5;//means no. of drivers
        Truck* trucks = NULL;
        trucks = new Truck[data];
        for (int i = 0; i<data; i++)
        {
            Truck ural;//an object of class Truck
            fgets(ural.driver, 32, (FILE*)filePointer); //Reading the name of the driver directly

            fgets(buff, 32, (FILE*)filePointer);        //Reading the next line as string
            ural.petrol = atoi(buff);                   //Converting the string to integer

            fgets(buff, 32, (FILE*)filePointer);
            ural.money = atoi(buff);

            fgets(buff, 32, (FILE*)filePointer);
            ural.fullMileage = atoi(buff);

            fgets(buff, 32, (FILE*)filePointer);
            ural.emptyMileage = atoi(buff);

            trucks[i] = ural;//each truck is inputted into array
            cout << "\nTruck driver is: " << ural.driver;//driver name outputted
            cout << "Petrol available is: " << ural.petrol<<" liters"<<endl;//petrol available in truck outputted
            cout << "Driver has money: $" << ural.money<<endl;//money driver has outputted
            cout << "Truck full mileage is: " << ural.fullMileage<<" km per liter"<<endl;//journey when loaded per liter outputted
            cout << "Truck empty mileage is: " << ural.emptyMileage<<" km per liter"<<endl;//journey when empty per liter outputted
            trucks[i].Cost();//finds the cost of each truck
        }
    }

    fclose(filePointer);//file closed
    return 0;
}
//the end
