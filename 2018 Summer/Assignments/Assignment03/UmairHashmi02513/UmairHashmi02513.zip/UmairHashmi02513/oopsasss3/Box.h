/*****
By: S.M.Umair Hashmi I.D:sh02513 OOP Assignment 3
The result is created in console. To obtain result we first take input from 'Drivers.txt' file.
That input is used to obtain the result.
*****/
#pragma once
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

struct Box  //struct used as no private components required
{
    int length;//length of box
    int width;//width of box
    int height;//height of box
    Box()//default constructor
    {
        //as these are boxes so have width, length, height
        length = 5 + rand() % 25;//length can be between 5 and 30 inclusive
        width = 5 + rand() % 25;//width can be between 5 and 30 inclusive
        height = 5 + rand() % 25;//height can be between 5 and 30 inclusive
    }
    int Volume()//function
    {
        int volume = 0;
        volume = length * width * height;
        return volume;//returns the volume of box
    }
};
