/*****
By: S.M.Umair Hashmi I.D:sh02513 OOP Assignment 3
The result is created in console. To obtain result we first take input from 'Drivers.txt' file.
That input is used to obtain the result.
*****/
/**
This code has 2 header files Truck.h and Box.h.
As structs used for these it can be done in a single file as well which is also included by the name 'OOPAssignment3s'
**/
#include <iostream>
#include <stdio.h>
#include <fstream>
#include <stdlib.h>
#include "Truck.h"
using namespace std;

int LineCounter(char* fileName)
{
    FILE* filePointer;                          //Declaring a file pointer
    char buff[32];                              //Declaring a character array to store a line

    filePointer = fopen(fileName, "r");         //Opening file as read only

    if (filePointer == NULL)                    //If file is not found
    {
        perror ("Error opening file");          //Show Error
        return 0;
    }

    int counter = 0;                            //Counts the lines in file

    while(fgets(buff, 32, (FILE*)filePointer) != NULL)   //If line read is not NULL
    {
        counter++;                                      //increase line count
    }
    fclose(filePointer);                                //close file when done
    return counter;                                     //return line count
}

int main()
{
    int no_of_lines = 0;
    no_of_lines = LineCounter((char *)"Drivers.txt");//Declaring a character array to store a line
    cout<<"No. of lines in the file: "<<no_of_lines<<endl;
    FILE* filePointer;                          //Declaring a file pointer
    char buff[32];
    filePointer = fopen("Drivers.txt", "r");    //Opening file as read only
    if (filePointer == NULL)//if file not found
    {
        perror ("Error opening file");//show error
        return 0;
    }
    else
    {
        int data = 0;
        data = no_of_lines/5;//means no. of drivers
        Truck* trucks = NULL;
        trucks = new Truck[data];
        for (int i = 0; i<data; i++)
        {
            Truck ural;//an object of class Truck
            fgets(ural.driver, 32, (FILE*)filePointer); //Reading the name of the driver directly

            fgets(buff, 32, (FILE*)filePointer);        //Reading the next line as string
            ural.petrol = atoi(buff);                   //Converting the string to integer

            fgets(buff, 32, (FILE*)filePointer);
            ural.money = atoi(buff);

            fgets(buff, 32, (FILE*)filePointer);
            ural.fullMileage = atoi(buff);

            fgets(buff, 32, (FILE*)filePointer);
            ural.emptyMileage = atoi(buff);

            trucks[i] = ural;//each truck is inputted into array
            cout << "\nTruck driver is: " << ural.driver;//driver name outputted
            cout << "Petrol available is: " << ural.petrol<<" liters"<<endl;//petrol available in truck outputted
            cout << "Driver has money: $" << ural.money<<endl;//money driver has outputted
            cout << "Truck full mileage is: " << ural.fullMileage<<" km per liter"<<endl;//journey when loaded per liter outputted
            cout << "Truck empty mileage is: " << ural.emptyMileage<<" km per liter"<<endl;//journey when empty per liter outputted
            trucks[i].Cost();//finds the cost of each truck
        }
    }

    fclose(filePointer);//file closed
    return 0;
}
//the end
