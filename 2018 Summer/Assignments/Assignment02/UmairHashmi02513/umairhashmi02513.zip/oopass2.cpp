/*****
By: S.M.Umair Hashmi I.D:sh02513
The result is created in consule. At first it asks you whether you want to move forward or give up.
If you give up the game ends.But if you decide to move forward the game begins. The game is a day by day story
game. So after each day the events occurring are shown and a report about that day is seen.
*****/
#include<iostream>
#include <time.h>
#include<stdlib.h>
using namespace std;

void EveryTurn(int &,int &,int &,int &,int &,int &,int &);//these all are w made below the main.
void Conditions(int &,int &,int &,int &,int &,int &,int &);
void MoveForward(int &,int &,int &,int &,int &,int &,int &);
void HiddenChest(int &,int &,int &,int &,int &,int &,int &);
void Enemies(int &,int &,int &,int &,int &,int &,int &);
void CombatLoss(int &,int &,int &,int &,int &,int &,int &);
void Dagger(int &,int &,int &,int &,int &,int &,int &);

int main()
{
    cout<<"Welcome to the Rastan's journey game!"<<endl;
    cout<<"The scenario is that a young man Rastan was on his way to Persia from Delhi \nbefore he got separated from his caravan. Armed only with a dagger, Rastan has \nnowhere to go except to move forward. But his path is laden with awards and \nmischief. He does not know what he will encounter across the next corner. After a good nights rest, he chooses to move forward and brace himself for the things to come."<<endl;
    cout<<"You are Ratan!"<<endl;
    srand(time(NULL));// to change value of random numbers after every day. done everywhere.
    int day_count = 0;//number of days initialized
    int FoodWater_Count = 10;//food water count initialized. it is 10 at start
    int health = 20;  //health initialized. it is 20 at start
    int no_of_bow = 0;//the rest are all 0 initially.
    int no_of_arrows = 0;
    int tracks = 0;
    int bandit = 0;//these are all the variables used in all functions
    EveryTurn(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);//function EverTurn is called here
    return 0;
}

void EveryTurn(int & day_count,int & FoodWater_Count,int & health,int & no_of_bow,int & no_of_arrows,int & tracks,int & bandit)
{        //in all functions like here reference pointers are used for the variables so as to save the value of them for all functions
    cout<<"\nDaily Report:"<<endl;//each day report
    cout<<"Food and Water count:"<<FoodWater_Count<<endl;
    cout<<"Days:"<<day_count<<endl;
    cout<<"His health is:"<<health<<endl;
    cout<<"The number of bows :"<<no_of_bow<<endl;
    cout<<"Rastan found: "<<no_of_arrows<<" arrows"<<endl;
    cout<<"Tracks found: "<<tracks<<" times"<<endl;
    srand(time(NULL));
    string choice;
    cout<<"Tell do you want to move forward or give up? Insert f or e"<<endl;
    cin>>choice;//input taken from game player
    if (choice=="f")
    {//if you decide to move forward
        Conditions(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);

    }
    if (choice=="e")
    {//if you chose to give up
        cout<<"Sorry Ratan chose to give up. OOPs!"<<endl;
        srand(time(NULL));
        int death=rand() % 5;// death can be any number between 0 to 5
        if(death==0)//rastan can die by 5 different ways randomly chosen
        {
            cout<<"As Ratan gave up he has to DIE! Hence he will die by STARVATION"<<endl;
        }
        else if(death==1)
        {
            cout<<"As Ratan gave up he has to DIE! Hence he will die by DISEASE"<<endl;
        }
        else if(death==2)
        {
            cout<<"As Ratan gave up he has to DIE! Hence he will die by DEHYDRATION"<<endl;
        }
        else if(death==3)
        {
            cout<<"As Ratan gave up he has to DIE! Hence he will die by AVADA KADAVERA"<<endl;
        }
        else if(death==4)
        {
            cout<<"As Ratan gave up he has to DIE! Hence he will die by SNAKE BITE"<<endl;
        }
    }
}

void Conditions(int & day_count,int & FoodWater_Count,int & health,int & no_of_bow,int & no_of_arrows,int & tracks,int & bandit)
{
    if (FoodWater_Count > 0)//will only move ahead if food water count is more than 0
    {
        MoveForward(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);
    }
    else
    {
        cout<<"As Rastan has run out of food and water so now he dies."<<endl;
    }
}

void MoveForward(int & day_count,int & FoodWater_Count,int & health,int & no_of_bow,int & no_of_arrows,int & tracks,int & bandit)
{
    cout<<"Ratan chose to move forward! Bravo!"<<endl;
    cout<<"As Ratan has decided to move forward he consumes food for one day."<<endl;
    FoodWater_Count=FoodWater_Count-1;//after every day food decreases by 1 and a day is increased
    day_count++;
    srand(time(NULL));
    int forward_events = rand() % 5;//options 0 to 4
    if (forward_events==0)
    {
        cout<<"He comes across food and water and replenishes his supplies for 5 more turns"<<endl;
        FoodWater_Count=FoodWater_Count+5;//food water count becomes more by 5
        EveryTurn(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);
        //this will be seen many times. it is to restart loop of the game
    }
    else if(forward_events==1)
    {
        cout<<"He comes across a hidden chest that contains a weapon or arrows"<<endl;
        cout<<"In the chest there is either a bow or arrows"<<endl;
        HiddenChest(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);//function hidden chest is called
        EveryTurn(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);
    }
    else if(forward_events==2)
    {
        cout<<"He comes across 3 bandits"<<endl;
        bandit=3;//whenever this event is found bandits are 3 at start
        Enemies(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);//Enemies is called
        if (health > 0)//will only reenter loop if health is more than 0
            EveryTurn(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);
        else
        {
            health=0; //as health is now 0 or less than that it becomes 0 as it cannot be negative.
            cout<<"Food and Water count:"<<FoodWater_Count<<endl;
            cout<<"Days:"<<day_count<<endl;
            cout<<"His health is:"<<health<<endl;
            cout<<"The number of bows :"<<no_of_bow<<endl;
            cout<<"Rastan found: "<<no_of_arrows<<" arrows"<<endl;
            cout<<"Tracks found: "<<tracks<<" times"<<endl;
            cout<<"As Rastan's health had deteriorated so he has to die."<<endl;
        }

    }
    else if(forward_events==3)
    {
        cout<<"He comes across a healer who heals him."<<endl;
        health=20;//health variable becomes 20 again
        //cout<<"He has healed so now his health is:"<<health<<endl;
        EveryTurn(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);
    }
    else if(forward_events==4)
    {
        cout<<"He comes across caravan"<<endl;
        tracks++;
        if (tracks < 6)//if tracks found 6 times the game ends
        {
            EveryTurn(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);
        }
        else
        {
            cout<<"ALAS! FINALLY RASTAN REACHED PERSIA!!!"<<endl;
        }
    }
}

void HiddenChest(int & day_count,int & FoodWater_Count,int & health,int & no_of_bow,int & no_of_arrows,int & tracks,int & bandit)
{
   srand(time(NULL));
   int weapon=rand() % 3;//0 to 2

   if(weapon==0)
   {
       cout<<"Rastan found a bow"<<endl;
       no_of_bow++;//no of bows increase by 1
   }
   else if(weapon==1)
   {
       cout<<"Rastan found arrows"<<endl;
       srand(time(NULL));
       int arrows_found=rand() % 5 + 5;// arrows found in chest will be between 5 and 10 inclusive
       no_of_arrows = no_of_arrows + arrows_found;//arrows found are added to total arrows
   }
    else if(weapon==2)
   {
       cout<<"Rastan found no new weapon."<<endl;//no weapon can be found
   }

}

void Enemies(int & day_count,int & FoodWater_Count,int & health,int & no_of_bow,int & no_of_arrows,int & tracks,int & bandit)
{
    cout<<"Now Rastan will fight against the 3 bandits"<<endl;
    if(no_of_arrows>0 && no_of_bow>0)//bow and arrow used only when both are more than 1
    {
        cout<<"Now as no. of arrows and bow both are more than 0 they can be used"<<endl;
        while(bandit != 0)//to create a loop until all bandits are dead
        {
             if (health != 0)//Rastan cannot fight bandit if his health becomes 0
             {
                 cout<<"Rastan fighting the bandits now! Will he win? Or will he lose? Lets find out"<<endl;
                cout<<"Rastan now fights the bandits"<<endl;
                if (bandit != 0)//3 if else done as there are 3 bandits
                {//rastan will fight first with all 3
                    int rastanhit=0;
                    rastanhit=rand() % 20;//0 to 19
                    if (rastanhit==0 || rastanhit==1 || rastanhit==2 || rastanhit==3 || rastanhit==4)//to have a chance of 25%
                    {
                        cout<<"Rastan attack bandit by bow and arrows but missed hitting him"<<endl;//missed
                        no_of_arrows=no_of_arrows - 1;//one arrow used
                    }
                    else
                    {
                        cout << "Rastan kills 1 bandit with bow and arrow" << endl;//bandit hit
                        bandit=bandit - 1;//one bandit killed
                        cout << "Bandits remaining = " << bandit << endl;
                        no_of_arrows=no_of_arrows - 1;//arrow used
                    }
                }
                else
                {
                    cout<<"All bandits dead"<<endl;
                }
                if (bandit != 0){//same as above if else
                    int rastanhit1=0;
                    rastanhit1=rand() % 20;
                    if (rastanhit1==0 || rastanhit1==1 || rastanhit1==2 || rastanhit1==3 || rastanhit1==4)
                    {
                        cout<<"Rastan attack bandit by bow and arrows but missed hitting him"<<endl;
                        no_of_arrows=no_of_arrows - 1;
                    }
                    else
                    {
                        cout << "Rastan kills 1 bandit with bow and arrow" << endl;
                        bandit=bandit - 1;
                        cout << "Bandits remaining = " << bandit << endl;
                        no_of_arrows=no_of_arrows - 1;
                    }
                }
                else
                {
                    cout<<"All bandits dead"<<endl;
                }
                if (bandit != 0){//same as above if else
                    int rastanhit2=0;
                    rastanhit2=rand() % 20;
                    if (rastanhit2==0 || rastanhit2==1 || rastanhit2==2 || rastanhit2==3 || rastanhit2==4)
                    {
                        cout<<"Rastan attack bandit by bow and arrows but missed hitting him"<<endl;
                        no_of_arrows=no_of_arrows - 1;
                    }
                    else
                    {
                        cout << "Rastan kills 1 bandit with bow and arrow" << endl;
                        bandit=bandit - 1;
                        cout << "Bandits remaining = " << bandit << endl;
                        no_of_arrows=no_of_arrows - 1;
                    }
                }
                else
                {
                    cout<<"All bandits dead"<<endl;
                }
             }
             else
             {
                 cout<<"His health deteriorated Rastan died"<<endl;//when health =0
             }

            if (bandit != 0)//bandits fight now
            {
                cout<<"Bandits fighting Rastan now! Will they win? Or will they lose? Lets find out"<<endl;
                int bandithit=0;
                bandithit=rand() % 20;//0 to 19
                if (bandithit==0 || bandithit==1 || bandithit==2 || bandithit==3 || bandithit==4 || bandithit==5 || bandithit==6)
                {//chance to 35%
                    cout<<"Bandit attacked Rastan and hit him"<<endl;
                    CombatLoss(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);//function called
                }
                else
                {
                    cout<<"Bandits attacked Rastan but missed hitting him"<<endl;

                }
                int bandithit2=0;
                bandithit2=rand() % 20;
                if (bandithit2==0 || bandithit2==1 || bandithit2==2 || bandithit2==3 || bandithit2==4 || bandithit2==5 || bandithit2==6)
                {//3 if else as each bandit fight rastan now
                    cout<<"Bandit attacked Rastan and hit him"<<endl;
                    CombatLoss(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);
                }
                else
                {
                    cout<<"Bandits attacked Rastan but missed hitting him"<<endl;

                }
                int bandithit3=0;//same as above
                bandithit3=rand() % 20;
                if (bandithit3==0 || bandithit3==1 || bandithit3==2 || bandithit3==3 || bandithit3==4 || bandithit3==5 || bandithit3==6)
                {
                    cout<<"Bandit attacked Rastan and hit him"<<endl;
                    CombatLoss(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);
                }
                else
                {
                    cout<<"Bandits attacked Rastan but missed hitting him"<<endl;

                }
            }
            else
            {
                cout<<"\nAll bandits are killed!\n"<<endl;
            }
        }
        if (no_of_arrows < 0)
        {
            no_of_arrows = 0;//meaning when arrows used if they are less than 0 they become 0 as no. of arrows cannot be negative.
        }
    }
    else//as arrow and bow both not more than 1 so dagger used
    {
        cout<<"Now as no. of arrows and bow both are NOT more than 0 Dagger will be used."<<endl;
        while(bandit != 0)
        {
            if (health != 0){//same as above
                Dagger(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);
                Dagger(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);
                Dagger(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);
            }//dagger is called 3 times as 3 bandits
            else
            {
                cout<<"Rastan died when his health ended"<<endl;
            }
            if (bandit != 0)
            {
                cout<<"Bandits fighting Rastan now! Will they win? Or will they lose? Lets find out"<<endl;
                int bandithit=0;//same as with bow arrow
                bandithit=rand() % 20;
                if (bandithit==0 || bandithit==1 || bandithit==2 || bandithit==3 || bandithit==4 || bandithit==5 || bandithit==6)
                {
                    cout<<"Bandit attacked Rastan and hit him"<<endl;
                    CombatLoss(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);
                }
                else
                {
                    cout<<"Bandits attacked Rastan but missed hitting him"<<endl;
                }

                int bandithit1=0;
                bandithit1=rand() % 20;
                if (bandithit1==0 || bandithit1==1 || bandithit1==2 || bandithit1==3 || bandithit1==4 || bandithit1==5 || bandithit1==6)
                {
                    cout<<"Bandit attacked Rastan and hit him"<<endl;
                    CombatLoss(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);
                }
                else
                {
                    cout<<"Bandits attacked Rastan but missed hitting him"<<endl;
                }

                int bandithit3=0;
                bandithit3=rand() % 20;
                if (bandithit3==0 || bandithit3==1 || bandithit3==2 || bandithit3==3 || bandithit3==4 || bandithit3==5 || bandithit3==6)
                {
                    cout<<"Bandit attacked Rastan and hit him"<<endl;
                    CombatLoss(day_count,FoodWater_Count,health,no_of_bow,no_of_arrows,tracks,bandit);
                }
                else
                {
                    cout<<"Bandits attacked Rastan but missed hitting him"<<endl;
                }
            }
            else
            {
                cout<<"\nAll bandits are killed!\n"<<endl;
            }
        }
    }
}

void CombatLoss(int & day_count,int & FoodWater_Count,int & health,int & no_of_bow,int & no_of_arrows,int & tracks,int & bandit)
{
    health = health - 1;// health reduces by 1
}

void Dagger(int & day_count,int & FoodWater_Count,int & health,int & no_of_bow,int & no_of_arrows,int & tracks,int & bandit)
{
    if (bandit != 0){
        cout<<"Rastan fighting the bandits now! Will he win? Or will he lose? Lets find out"<<endl;
        srand(time(NULL));
        int DaggerHit=rand() % 10;//0 to 9
        if(DaggerHit==0 || DaggerHit==1 || DaggerHit==2 || DaggerHit==3)
        {//chance of 40%
            cout << "Rastan kills 1 bandit with dagger" << endl;
            bandit=bandit - 1;//bandit killed
            cout << "Bandits remaining = " << bandit << endl;
        }
        else
        {
            cout<<"Raskan missed when he hit the enemy"<<endl;
        }
    }
    else
    {
        cout<<"all bandits dead"<<endl;
    }
}
//the end
