#include <iostream>
#include <time.h>
#include <stdlib.h>


using namespace std;


/* combat function*/
void combat(bool* alive, bool* bow, int* health, int* arrows, int* bandits)
{   int random = 0 ;
    int banditsKilled = 0;
    while (*bandits > 0 && *alive == true)
    {
        cout << endl << "Bandits: " << *bandits << endl;
        for (int i = 0; i < *bandits; i++ )
        {
            cout << endl;
            cout << "Rastan attacks bandit" << endl;

            if (*bow == true && *arrows > 0)
            {
                cout << endl;
                cout << "Weapon: bow and arrow" << endl;
                random = rand() %100 ;

                if (random <= 75)      // probability of hitting with an arrow
                {
                    cout << endl << "KILLED" << endl;
                    banditsKilled += 1;
                }
                else
                {
                    cout << endl << "Missed" << endl;
                }
                *arrows -= 1;
                cout << endl<< "arrows left: " << *arrows << endl;

            }
            else
            {
                cout << "Weapon: Dagger" << endl;
                random = rand() %100 ;
                if (random <= 40)                     // probability of hitting with a dagger
                {
                    cout << endl << "KILLED" << endl;
                    banditsKilled += 1;
                }
                else
                {
                    cout<< endl << "MISSED" <<endl;
                }
            }
        }

        *bandits -= banditsKilled;
        cout << endl << "bandits left: " << *bandits << endl;

        banditsKilled = 0; //resetting counter for next turn

        if (*bandits == 0)
        {
            cout<<endl;
            cout<<"All bandits killed"<<endl;
        }

        for (int i = 0; i < *bandits; i++ )

        {
            cout << endl;
            cout << "Bandit " << (i+1) << " attacks" << endl;
            random = rand() %100 ;
            if (random <= 35)               // probability of bandits hitting
            {
                cout << endl;
                cout << "HIT" << endl << endl;
                *health -= 1;
                cout << "Health: " << *health << endl;

                if (*health == 0)
                {
                cout << endl;
                cout << "Rastan Killed" << endl;
                *alive = false ;
                break ;
                }
            }
            else
            {
                cout << endl << "MISSED" << endl;
            }
        }
    }
}


int main()
{   srand(time(NULL));
    int day = 0;
    int tracks = 0;
    int bandits = 0;
    int supplies = 10;
    int health = 20;
    int arrows = 0;
    int random = 0;
    char moveForward[] = "";
    char choice[1];
    char yes[] = "y";
    char no[] =  "n";
    char randomChararacter[] = "r";
    bool alive = true;
    bool bow = false;



    while (alive)
    {
        day++;
        supplies -= 1;
        cout<<endl;
        cout<<"Day: "<<day<<endl;
        cout<<"Supplies: "<<supplies<<endl;
        cout<<"Health: "<<health<<endl;
        cout<<"tracks: "<<tracks<<endl<<endl;
        cout<<"Do you want to move forward? press y or n: ";

        while(choice[0]!= yes[0] && choice[0]!= no[0]) //runs until user enters y or n as first character input
        {
            cin>>choice[0];
            cout<<endl<<endl;
            choice[0] = tolower(choice[0]);
        }

        moveForward[0] = choice[0];
        choice [0] = randomChararacter[0]; //to reset choice to a character other than y or n so that it can enter while loop and get user input again

        if (moveForward[0] == no[0])
        {
            alive = false;
            if (supplies > 0)
            {
                random = rand()%3; // to exclude death due to starvation and dehydration in case supplies available
            }
            else
            {
                random = rand()%4;
            }
            if (random == 0)
            {
                cout << "Rastan died of Disease" << endl;
            }
            else if (random == 1)
            {
                cout << "Rastan died of Snake bite" <<endl;
            }
            else if (random == 2)
            {
                cout << "Rastan died of Avadakedavra" << endl;
            }
            else if (random == 3)
            {
                cout << "Rastan died of starvation and Dehydration" << endl;
            }
        }

        else
        {
            random = rand() %5;

            if (supplies == 0)
            {
                if (random != 1)
                {
                   cout << "Rastan's supplies ran out." << endl << "Rastan died of starvation and dehydration" << endl;
                   alive = false ;
                }
            }
            else if (random == 0)
            {
                cout << "Rastan came across caravan tracks" << endl;
                tracks += 1;
                if (tracks==6)
                {
                    cout<<endl<<"Rastan found his caravan and reached Persia!!"<<endl;
                    break;
                }
            }
            else if (random == 1)
            {
                cout<<"Rastan came across Food and water" <<endl;
                supplies += 5;
                cout<<"He got supplies for 5 more days"<<endl;
            }
            else if (random == 2)
            {
                cout<<"Rastan came across a Healer"<<endl;
                health = 20;
                cout<<"health: "<<health<<endl;
            }
            else if (random == 3)
            {
                cout<<"Rastan came across a hidden chest"<<endl;

                random = rand() %2;
                if (random == 0)
                {
                    cout<<"Rastan found a bow"<<endl;
                    bow = true;
                }
                else
                {
                    random = 0;
                    while (random < 5)   // loop runs until random is greater than 5 for arrows to be between 5-10
                    {
                        random = rand() %11;
                    }
                    arrows += random;
                    cout<<"Rastan found "<<random<<" arrows."<<endl<<"Total Arrows: "<<arrows<<endl;
                }
            }

            else if (random == 4)
            {
                bandits = 3 ;
                cout<<"Rastan came across 3 bandits. He has to fight now"<<endl;
                combat(&alive, &bow, &health, &arrows, &bandits);
            }
        }
    }

    return 0;
}
