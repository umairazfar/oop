/**

* OOP - Assignment 2
* Summer Semester 2018 - Habib University
* Instructor Dr. Umair Azfar - TA Nabiha Shahid

* Jahanzaib Hyder - jh02963

* Due Date 11th June (1200 PST)

**/

#include <iostream>
#include <stdlib.h>
#include <time.h>

using namespace std;

void StockUp(int &food) //This function will increase the food supplies by 5
{
    food+=5;
}

void chest(int &teer, bool &kamaan) //This function will first randomly chose between taking Bow or Arrow from the chest.
{
    int hathyaar = rand() % 2;
    if (hathyaar == 1)
    {
        int CurrentArrow = (rand() % 6) + 5; //Rastan can pick the arrows randomly between 5 - 10.
        teer = CurrentArrow + teer; //This updates the total number of arrows.
        cout << "   Rastan founds " << CurrentArrow << " Arrows." << endl;
        cout << "   Total Arrows: " << teer << "." << endl;
    }
    if (hathyaar == 0)
    {
        kamaan = 1; //kamaan is a bool, either there will be a bow or there won't be.
        cout << "   Rastan Founds a Bow." << endl;
    }
}

void bandit(int &sehat, int &dushman, int &teer, bool &kamaan) //This function plays out the combat whenever Rastan encounters enemies.
{
    char BowOrDag;

    int RastanHitChance;
    int BanditsHitChance;

    while (dushman > 0 && sehat > 0) //This loop will keep running untill there is health of Rastan Left and at least there is one bandit.
    {
        cout << endl << "Rastan is attacking the Bandits now." << endl;
        int CurrentEnemies = dushman;
        for (int i = 0; i < CurrentEnemies; i++) //This loop will run the times the number of enemies alive at the moment.
        {
            if (teer >= 1 && kamaan == 1) //This condition will run if there is more than and equal to one arrow and there is a bow
            {
                BowOrDag = 'B';
                cout << endl << ">>> Ratsan used Bow and Arrow against Bandit " << (i+1) << " ." <<endl << endl;
            }
            else
            {
                BowOrDag = 'D';
                cout << endl << ">>> Ratsan used Dagger against Bandit " << (i+1) << " ." << endl << endl;
            }
            RastanHitChance = rand() % 100; //for every loop this function will help to calculate the probability of hit
            if (BowOrDag == 'B' && RastanHitChance < 75)
            {
                dushman--;
                teer--;
                cout << "   ***Ratsan killed a Bandit***" << endl;
            }
            else if (BowOrDag == 'D' && RastanHitChance < 40)
            {
                dushman--;
                cout << "   ***Ratsan killed a Bandit***" << endl;
            }
            else
            {
                if (BowOrDag == 'B')
                {
                    teer--;
                }
                cout << "   Ratsan missed" << endl;
            }
        }
        if (dushman > 0)
        {
            cout << endl << "Bandits are attacking Rastan now." << endl << endl;
        }
        for (int j = 0; j < dushman; j++) //This loop will hit the Rastan by Bandits, if there is any bandit (dushman)
        {
            BanditsHitChance = rand() % 100;
            if (BanditsHitChance < 35)
            {
                sehat--;
                cout << "   ***Rastan got Hit from Bandit " << (j+1) << " ***" << endl;
            }
            else
            {
                cout << "   Bandit " << (j+1) << " missed"  << endl;
            }
        }
    }
}

int main()
{
    srand(time(NULL));

    char choice = 'Y';
    int DeathPossiblities = (rand() % 5) + 1;
    int LivePossiblities = 0;
    int tracks = 0;
    int supplies = 11; //11 because 1 is going to run by default
    bool bow = 0;
    int arrow = 0;
    int health = 20;
    int enemies = 3;
    bool game = 0;
    int days = 0;

    cout << endl << "A young man Rastan was on his way to Persia from Delhi, before he got separated from his caravaan. Armed only with Dagger Rastan has nowhere to go except to move forward. He does not know what he is going to encounter next. After a good nights rest, he chooses to move forward and brace himself for the things to come."  << endl;

    while (choice == 'Y') //This loop will keep running until the choice changes from Y to any value.
    {
        days++;
        supplies--;

        if (days > 1) //so the first day could run pre define
        {
            LivePossiblities = (rand() % 5) + 1; //Will randomly select what the Rastan is going to encounter this day
            cout << endl << "===========================================" << endl << endl;
        }
        if (LivePossiblities == 1)
        {
            cout << "Rastan comes across food and water." << endl;
            StockUp(supplies); //will increase the supply
        }
        if (LivePossiblities == 2)
        {
            cout << "Rastan comes across a hidden chest." << endl;
            chest(arrow, bow); //will either increase the arrow or will find the bow
        }
        if (LivePossiblities == 3)
        {
            cout << "Rastan encounters 3 Bandits." << endl;
            bandit(health, enemies, arrow, bow); //combat will take place
            if (enemies == 0) //will update the count of bandits to 3 after each battle
            {
                enemies = 3;
            }
            if (health <= 0) //if Rastan dies, break the current while loop.
            {
                DeathPossiblities = 6;
                break;
            }
        }
        if (LivePossiblities == 4)
        {
            cout << "Rastan finds a healer." << endl;
            health = 20;
        }
        if (LivePossiblities == 5)
        {
            cout << "Rastan finds a track." << endl;
            tracks++;
            if (tracks == 6) //if tracks are 6, he wins the game, for that the loop is break.
            {
                game = 1;
                break;
            }
        }
        //now this will be printed after end of each day, displaying things which Rastan have left.
        cout << "" << endl;
        cout << "===========================================" << endl;
        cout << "" << endl;
        cout << "Day " << days << " ended." << endl;
        cout << "" << endl;
        if (supplies > 0)
        {
            cout << "* The Supplies for just " << supplies << " days are left." << endl;
        }
        cout << "* " << health << " Health is left." << endl;
        if (arrow > 0 && bow == 1)
        {
            cout << "* Rastan have " << arrow << " arrows left." << endl;
        }
        else
        {
            cout << "* Rastan have Dagger left as weapon." << endl;
        }
        if (tracks > 0)
        {
            cout << "* Rastan have found " << tracks << " carvaan track(s)." << endl;
        }
        else
        {
            cout << "* Rastan have found no carvaan tracks yet." << endl;
        }
        cout << "" << endl;
        if (supplies > 0) //if he has supplies left for next day, it will ask weather you want to continue or not. In case of no supplies left, the loop will break.
        {
        cout << "Do Rastan have what it takes to live another day? in that case enter 'Y' else press any key : ";
        cin >> choice;
        }
        else
        {
            cout << "Rastan have run out of the supplies." << endl;
            DeathPossiblities = 1;
            break;
        }
    }

    if (game == 1)
    {
        cout << "===========================================" << endl;
        cout << "" << endl;
        cout << "Congratulations!! You WIN and Rastan has reached Persia." << endl;
    }
    else
    {
        cout << endl << "++++++++++++++++++++++++++++++++++++++++++++" << endl << endl;
        if (DeathPossiblities == 1)
        {
            cout << "Game Over. Rastan died due to Starvation." << endl;
        }
        if (DeathPossiblities == 2)
        {
            cout << "Game Over. Rastan died due to Disease." << endl;
        }
        if (DeathPossiblities == 3)
        {
            cout << "Game Over. Rastan died due to Dehydration." << endl;
        }
        if (DeathPossiblities == 4)
        {
            cout << "Game Over. Rastan died due to avada kadavera." << endl;
        }
        if (DeathPossiblities == 5)
        {
            cout << "Game Over. Rastan died due to Snake Bite." << endl;
        }
        if (DeathPossiblities == 6)
        {
            cout << "Game Over. Rastan died due to the Fight with Bandits" << endl;
        }
        cout << endl << "++++++++++++++++++++++++++++++++++++++++++++" << endl << endl;
    }
    return 0;
}
