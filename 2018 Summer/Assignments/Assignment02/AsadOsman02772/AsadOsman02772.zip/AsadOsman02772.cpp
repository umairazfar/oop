#include<iostream>
#include<math.h>
#include<time.h>
#include<stdlib.h>
#include<fstream>
#include<stdio.h>

using namespace std;

void supplies(int&);                                        //All functions are defined here
void chest(int&, int&);
void bandits(int&, int&, int&);
void healer(int&);
void caravan(int&);
void banditAttack(int&, int&);
void combat(int&, int&, int&);


void GiveUp(string turn)                                    //This function uses the user input stored in string turn
{                                                           //If it is equal to "give up", then random value between
    srand(time(NULL));                                      //0 and 4 inclusive is used to decide what was the cause
    if (turn == "give up")                                  //of Rastans death. This was done by comparing the random numbers
    {
        int rand_value = rand() % 5;

        if (rand_value == 0)
        {
            cout<<endl;
            cout<<"Rastan died by starvation"<<endl;
        }
        else if (rand_value == 1)
        {
            cout<<endl;
            cout<<"Rastan died by disease"<<endl;
        }
        else if (rand_value == 2)
        {
            cout<<endl;
            cout<<"Rastan died by dehydration"<<endl;
        }
        else if (rand_value == 3)
        {
            cout<<endl;
            cout<<"Rastan died by avada kadavera"<<endl;
        }
        else if (rand_value == 4)
        {
            cout<<endl;
            cout<<"Rastan died by snake bite"<<endl;
        }
    }
}


void MoveForward(int& food, int& health, int& bows, int& arrows, string turn, int& num_caravans)
{
    if (turn == "move forward")                             //This function uses references for all the inventory:(Food supplies,
    {                                                       //health, bows, etc) and the user inputted string turn. If the
        int rand_num_1 = rand() % 5;                        //string is equal to 'move forward then function will run.
                                                            // Then a random number between 0 and 4 inclusive is stored in
        if(rand_num_1 == 0)                                 //rand_num_1 and is used to decide 1 of 5 outcomes after moving
        {                                                   //forward. This is done by comparing the random numbers
            supplies(food);
        }
        else if (rand_num_1 == 1)
        {
            chest(bows, arrows);
        }
        else if (rand_num_1 == 2)
        {
            bandits(bows, arrows, health);
        }
        else if (rand_num_1 == 3)
        {
            healer(health);
        }
        else if (rand_num_1 == 4)
        {
            caravan(num_caravans);
        }
    }
}


void supplies(int& food)                                        //This function is for restocking of supplies, it will set
{                                                               //food by 5 and display that "Rastan found supplies" in the
    food = food + 5;                                            //console. A reference is used so the value of food will change
    cout<<endl;                                                 //for the original value of food.
    cout<<"Rastan found food supplies!"<<endl;
}

void chest(int& bows, int& arrows)                              //This function is when Rastan finds a chest. He will either
{                                                               //find a bow or 5 to 10 arrows in the chest. A random number
    int rand_num_2 = rand() % 2;                                //between 0 and 1 inclusive was used to decide which was found.
    if (rand_num_2 == 0)                                        //As the arrows and bows are references, they will change the
    {                                                           //initial values for each.
        bows = bows+1;
        cout<<endl;
        cout<<"Rastan found a chest containing a bow!"<<endl;
    }
    else if (rand_num_2 == 1)
    {
        arrows = arrows + (rand() % 6) + 5;                     //A random number between 0 and 5 inclusive is generated
        cout<<endl;                                             //and is then incremented by 5.
        cout<<"Rastan found a chest containing arrows!"<<endl;
    }
}

void bandits(int& bows, int& arrows, int& health)               //This function is for when Rastan encounters bandits, it uses health
{                                                               //arrows and bows as references. He has to kill 3 bandits. He
    int kills = 0;                                              // gets 3 attempts first and then the remaining bandits get an
                                                                //attempt.
    while((kills < 3) && (health>0))                            //A while loop for fighting will continue only if Rastan has less
    {                                                           // than 3 kill and more than 0 health. A function combat is called
        combat(arrows,bows,kills);                              //for Rastans attack and then banditAttack function is called.
        while (kills == 3)                                      //If Rastan kills 3 bandits then the loop will break.
        {
            break;
        }
        banditAttack(health, kills);
    }
    if (kills == 3)                                             //If 3 bandits are killed then kills will be reset for next
    {                                                           //bandit encounter.
        kills = 0;
    }
    if(health <= 0)                                             //If health is less than or equal to zero then this means
    {                                                           //Rastan has died.
        cout<<"Rastan died!"<<endl;
    }
    cout<<endl;
    cout<<"Rastan encountered 3 bandits!"<<endl;
}

void combat(int& arrows, int& bows, int& kills)                 //The combat function is for when Rastan attacks the bandits.
{                                                               //The number of bandits is also stored. This will be used for
    int num_bandits = 3 - kills;                                //deciding how many bandits Rastan has to attack in the for loop.
    for (int n = 0; n < num_bandits; n++)                       //Reference are used also.
    {
        if ((arrows > 0) && (bows > 0))                         //Within the loop there are if conditions to decide whether
        {                                                       //Rastan should use bow and arrow or dagger. If either there
            arrows = arrows - 1;                                //zero arrows or no bow, Rastan will use the dagger.
            int rand_num_3 = rand() % 100;                      //If both arrows and bows exist then Rastan will prefer those
            if (rand_num_3 < 75)                                //over the dagger
            {
                kills = kills + 1;                              //Within those nested loops, there is another if condition
            }                                                   //for chance of hitting. A random number between 0 and 99 is
        }                                                       //generated and for the bow, if the number is less than 75 then
        else if (arrows == 0 || bows == 0)                      //arrow will hit; and for the dagger , if the number is less than
        {                                                       //35 then dagger will hit. If hit is successful then kills will
            int rand_num_3 = rand() % 100;                      //increment.
            if (rand_num_3 < 40)
            {
                kills = kills + 1;
            }
        }
    }
}

void banditAttack(int& health, int& kills)                      //This function is used for the bandits attacking turn. First
{                                                               //number of bandits are decided. This will decide how many bandtis
    int num_bandits = 3 - kills;                                //will attack Rastan. References are used.

    for (int m = 0; m < num_bandits; m++)                       //The loop will then generate a random number between 0 and 99,
    {                                                           // and if the number is less than 35 then Rastans health will
        int rand_num_4 = rand() % 100;                          //decrement due a successful bandit attack.
        if (rand_num_4 < 35)
        {
            health = health - 1;
        }
    }
}

void healer(int& health)                                        //This function will set Rastans health back to 20.
{                                                               //References are used.
    health = 20;
    cout<<endl;
    cout<<"Rastan found a healer!"<<endl;
}

void caravan(int& num_caravans)                                 //This function will increment number of caravans by 1.
{                                                               //References are used.
    num_caravans = num_caravans+1;
    cout<<endl;
    cout<<"Rastan found a caravan!"<<endl;
}



int main()
{
    srand(time(NULL));                                          //Firstly, all the important stats are initialized. All of these
    int food = 10;                                              //will have references across all the functions written, as they
    int health = 20;                                            //will need to change as Rastan moves forward.
    int num_turn = 0;
    int bows = 0;
    int arrows = 0;
    int num_caravans = 0;
    string turn;

    cout<<"\t\t\tSTORY"<<endl;                                                          //Story is displayed on console
    cout<<"---------------------------------------------------------------"<<endl;
    cout<<"A young man Rastan was on his way to Persia from Delhi"<<endl;
    cout<<"before he got separated from his caravan. Armed only"<<endl;
    cout<<"with a dagger, Rastan has nowhere to go except to"<<endl;
    cout<<"move forward. But his path is laden with awards and"<<endl;
    cout<<"mischief. He does not know what he will encounter"<<endl;
    cout<<"across the next corner. After a good nights rest, he"<<endl;
    cout<<"chooses to move forward and brace himself for the"<<endl;
    cout<<"things to come."<<endl;
    cout<<"---------------------------------------------------------------"<<endl;
    cout<<endl;
    cout<<"Should Rastan move forward or should he give up"<<endl;
    cout<<"(To move forward type 'move forward', to give up type 'give up')"<<endl;
    cout<<endl;



    while (health > 0)                                          //Game will only continue if Rastan has health.
    {
        getline(cin, turn);                                     //User input is stored as string.

        cout<<"---------------------------------------------------------------"<<endl;

        if ((turn != "move forward") && (turn != "give up"))    //This check is for invalid inputs
        {
            cout<<endl;
            cout<<"Invalid move"<<endl;
            num_turn--;
            food++;                                        //This was done so that day and food doesn't increment for invalid turn
        }

        num_turn++;
        cout<<"Day "<<num_turn<<endl;                           //Day is displayed

        GiveUp(turn);                                           //If user gives up then give up function will be called and
        if (turn == "give up")                                  //game will end.
        {
            return 0;
        }


        food = food - 1;                                                    //Food decrements every turn
        MoveForward(food, health, bows, arrows, turn, num_caravans);        //move forward function is called
        if (food == 0)
        {
            cout<<endl;
            cout<<"Rastan died by starvation"<<endl;                        //If Rastan runs out of supplies
            return 0;
        }

        if (num_caravans == 6)                                               //When Rastan gets 6 caravans, then game will
        {                                                                    //end and Rastan will reach Persia.
            cout<<endl;
            cout<<"Rastan reached Persia"<<endl;
            cout<<"------------------WINNER----------------"<<endl;
            return 0;
        }

        cout<<endl;                                                                 //All the stats are displayed for user
        cout<<"------------------------------------------------------"<<endl;       //to decide whether to give up or carry
        cout<<"Health:\t\t"<<health<<endl;                                          //on.
        cout<<"Food:\t\t"<<food<<endl;
        cout<<"Arrows:\t\t"<<arrows<<endl;
        cout<<"Bows:\t\t"<<bows<<endl;
        cout<<"Caravans:\t"<<num_caravans<<endl;
        cout<<"------------------------------------------------------"<<endl;
        cout<<"If you wish to continue, type 'move forward'"<<endl;
        cout<<"If you wish to give up and die, type 'give up'"<<endl;
        cout<<endl;
    }
    return 0;
}

