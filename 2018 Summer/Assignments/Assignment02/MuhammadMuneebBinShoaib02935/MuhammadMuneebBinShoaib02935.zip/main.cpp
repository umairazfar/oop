#include<iostream>             //Similar to import command in Python
#include<stdlib.h>              //For random numbers
#include<time.h>               //For generating a new random seed

using namespace std;

void hidden_chest(int&, int&, int&);               // Functions are Declared.
void combat(int&, int&, int&, int&, int&);
void give_up();
void game_over(int&, int&, int&, int&);

int main()
{
    srand(time(NULL));         // For random numbers.
    int option=0;
    int consume = 0;
    int supplies = 10;             // Some variables are introduced.
    int day_no = 0;
    int caravan=0;
    int health = 20;
    int bow = 0;
    int arrows = 0;
    int weapon = 0;
    int enemy =0;
    cout << "x-------------------x-----------------x" << endl << endl;
    cout << "<Welcome to Rastan's Adventure Game>" << endl;
    while (consume<=supplies)                           // loop that stops when food supplies are finished.
    {
        enemy= 3;
        day_no++;
        cout << "DAY " << day_no << endl;
        cout << "You have two options to choose" << endl;
        cout <<  "Press 1 to move forward or press 2 to give up" << endl;
        cin >> option;                                         // user opt to move forward or give up in every turn.
        if (option==1)
        {
            consume++;
            cout << "supplies = " << supplies << endl;
            cout << "consume = " << consume << endl;
            cout << "Health = " << health << endl;
            cout << "caravan track = " << caravan << endl;
            cout << "weapon = " << weapon << endl;
            cout << "bow = " << bow << endl;
            cout << "arrows = " << arrows << endl;
            cout << "dagger = 1" << endl;
            int random = rand() % 100;
            if (random<=20)                 // If Rastan opt to move forward he can come across the following 5 conditions.
            {
                cout << "Rastan has come across food and water and replenishes his supplies for 5 more days"<< endl;
                supplies = supplies + 5;                  // 5 more food supplies are increased.
            }
            else if (random<=40)
            {
                cout << "Rastan has come across the hidden chest" << endl;
                hidden_chest(bow, arrows, weapon);                       // hidden chest function is called.
            }
            else if (random<=60)
            {
                cout << "Rastan has come across a 3 bandits" << endl;
                combat(bow, arrows, weapon, enemy, health);               // combat function is called.

                if (health<=0)
                {
                    break;                                                               // program will come out of the while loop.
                }
                else
                {
                    continue;
                }
            }
            else if (random<=80)
            {
                cout << "Rastan has come across a healer" << endl;
                health = 20;
            }
            else
            {
                cout << "Rastan has come across a caravan track" << endl;
                caravan++;
                if (caravan==6)
                {
                    break;                                                             // program will come out of the while loop.
                }
                else
                {
                    continue;
                }
            }
        }
        else if(option==2)
        {
            give_up();                                                                // give up function is called.
            break;                                                                    // program will come out of the while loop.
        }
        else
        {
            cout << "You've pressed a wrong key. Press the correct key again" << endl;
            day_no--;
        }
    }
    game_over(caravan, consume, supplies, health);                                    // game over function is called.
    return 0;
}


void hidden_chest(int& bow, int& arrows, int& weapon)                            // hidden chest function is defined. It'll be called when rastan
{                                                                                                      // will come across the hidden chest. It randomly equip rastan
    srand(time(NULL));                                                                          // with a weapon or bow or arrows.
    int random = rand() % 3;
    if (random==0)
    {
        cout << "Rastan got a bow" << endl;
        if (bow==0 && weapon==0)
        {
            bow++;

        }
        else if (weapon >0)
        {
            bow++;                                                                                 // If rastan got a bow, it will replace the old weapon.
            weapon--;
        }

    }
    else if (random==1)
    {
        cout << "Rastan got an arrow" << endl;
        arrows=(rand() % 5) + 5;                                                           //  arrows can be in the range of 5 -10.


    }
    else
    {
        cout << "Rastan got a weapon" << endl;
        if (weapon==0 && bow==0)
        {
            weapon++;
        }
        else if (bow>0)
        {
            weapon++;                                                                     // if rastan got new weapon it'll replace the old weapon including bow.
            bow--;
        }

    }
}

void combat(int& bow, int& arrows, int& weapon, int& enemy, int& health)       // combat function is defined. It'll be called when rastan
{                                                                                                           // will come across 3 bandits. first rastan will hit the enemies
    bool rastan_turn = true;                                                                        // once and then the enemies will hit him.
    while (rastan_turn)                                                                         // Once the condition get false, enemies will get a chance to
    {                                                                                                  // hit rastan.
        srand(time(NULL));
        if (bow > 0 && arrows >0)                                                                   // if rastan has both bow and arrows he'll fight using them.
        {
            cout << "Rastan has a bow and " << arrows << " arrows to fight" << endl;
            for (int i=1; i < 4; i++)
            {
                if (arrows > 0)                                                                         // if arrows got finished, it'll be replaced by dagger.
                {
                    int random = rand() % 100;
                    if (random > 25)                                                                 // bows or any other weapon has a hit chance of 75%.
                    {
                        cout << "Rastan hits no." << i << " enemy" << endl;
                        enemy--;
                        cout << "enemy left = " << enemy << endl;
                        arrows--;
                        cout << "arrows left = " << arrows << endl;
                    }
                    else
                    {
                        cout << "Rastan miss the chance to hit no." << i << " enemy" << endl;
                        cout << "enemy left = " << enemy << endl;
                    }
                }
                else
                {
                    cout << "Rastan has a dagger to fight" << endl;
                    int random = rand() % 100;
                    if (random > 60)
                    {
                        cout << "Rastan hits no." << i << " enemy" << endl;
                        enemy--;
                        cout << "enemy left = " << enemy << endl;
                    }
                    else
                    {
                        cout << "Rastan miss the chance to hit no." << i << " enemy" << endl;
                        cout << "enemy left = " << enemy << endl;
                    }
                }
            }
            rastan_turn = false;                                                             // to get to the enemies' turn.

        }
        else if (weapon >0)                                                                  // if rastan has a weapon, he will fight using it instead of dagger.
        {
            cout << "Rastan has a weapon to fight" << endl;
            for (int i=1; i < 4; i++)
            {
                int random = rand() % 100;
                if (random > 25)                                                            // any other weapon has a hit chance of 75%.
                {
                    cout << "Rastan hits no." << i << " enemy" << endl;
                    enemy--;
                    cout << "enemy left = " << enemy << endl;

                }
                else
                {
                    cout << "Rastan miss the chance to hit no." << i << " enemy" << endl;
                    cout << "enemy left = " << enemy << endl;
                }
            }
            rastan_turn = false;                                                                   // to get to the enemies' turn.
        }
        else
        {
            cout << "Rastan has a dagger to fight" << endl;                              // if no weapon is found. rastan will fight using dagger.
            for (int i=1; i < 4; i++)
            {
                int random = rand() % 100;
                if (random > 60)                                                                    // dagger has a hit chance of 40%.
                {
                    cout << "Rastan hits no." << i << " enemy" << endl;
                    enemy--;
                    cout << "enemy left = " << enemy << endl;

                }
                else
                {
                    cout << "Rastan miss the chance to hit no." << i << " enemy" << endl;
                    cout << "enemy left = " << enemy << endl;

                }
            }
            rastan_turn=false;                                                                  // to get to the enemies' turn.
        }
    }
    for (int i =1; i<enemy+1;i++)                                             // enemies got a turn.
    {
        int random = rand() % 100;
        if (random > 65)                                                         // enemies has a hit chance of 35%.
        {
            cout << "Rastan got hit by no. " << i << " enemy" << endl;
            health--;
            cout << "Rastan's health left = " << health << endl;
        }
        else
        {
            cout << "enemy no." << i << " miss the chance to hit Rastan" << endl;
            cout << "Rastan's health left = " << health << endl;
        }
    }


}

void give_up()                                                                     // give up function is defined. It'll be called when rastan will decide to
{                                                                                       // to give up one day. He will die for any of the reasons given in the
    int random=rand() % 10;                                                   // conditions.
    if (random<=2)
    {
        cout << "Death by Starvation is the ultimate fate of Rastan !" << endl;

    }
    else if (random<=4)
    {
        cout << "Death by Disease is the ultimate fate of Rastan !" << endl;

    }
    else if (random<=6)
    {
        cout << "Death by Dehydration is the ultimate fate of Rastan !" << endl;

    }
    else if (random<=8)
    {
        cout << "Death by Avada Kadavera is the ultimate fate of Rastan !" << endl;

    }
    else
    {
        cout << "Death by Snake bite is the ultimate fate of Rastan !" << endl;

    }
}

void game_over(int& caravan, int& consume, int& supplies, int& health)                // game over function is defined. It'll be called when
{                                                                                                                // the game will end for any of the reasons given in the
    if (caravan==6)                                                                                         // conditions.
    {
        cout << "Rastan has come across the caravan track 6 times and has reached Persia" << endl;
        cout << "YOU WON THE GAME !" << endl;
    }
    else if (consume>supplies)
    {
        cout << "Rastan has ran out of food and supplies, now death is the ultimate fate of Rastan" << endl;
        cout << "The game is over." << endl;
    }
    else if (health <=0)
    {
        cout << "Rastan has died" << endl;
        cout << "The game is over." << endl;
    }
    else
    {
        cout << "The game is over." << endl;

    }
}
