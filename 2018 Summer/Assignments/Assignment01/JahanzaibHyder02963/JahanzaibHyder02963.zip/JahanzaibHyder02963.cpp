/**

* OOP - Assignment 1
* Summer Semester 2018 - Habib University
* Instructor Dr. Umair Azfar - TA Nabiha Shahid

* Jahanzaib Hyder - jh02963

* Due Date 7th June (1200 pm)

**/

#include<math.h> //Declares a set of functions to compute common mathematical operations
#include<fstream> //For Reading and Writing on the files

using namespace std; //required for using cin and cout commands

const double PI = 3.14159265;

void GraphMaker() //This Function will generate a sin graph on a file
{
    ofstream myfile; //for writing on the file
    myfile.open ("graph.txt"); //create or open the file

    for (int i = 0; i < 361; i++) //Running this loop for 361 times for a complete period
    {
        int sine = 300 + sin(i * PI / 180) * 100; //converting the angle into Radians, then multiplied it by 100
                                                  //to get a larger value and then after setting the off set to see the
                                                  //negative cycle stored it in an integer
        for (int j = 0; j < sine; j++)
        {
            myfile << " ";
        }
        myfile << "*\n";
    }
}

int main()
{
    GraphMaker(); //The function GraphMaker is being called in the main.
    return 0;
}
