/*****
OOP Assignment 1 Date:07/06/2018
By: S.M.Umair Hashmi I.D:sh02513
The result is created in a text file by the name 'graph' created in the folder where the file of this code is saved.
Kindly change the font of the created text file to 1, from format, so as to look at complete graph.
The result seen on consule is the values of the number of spaces made on each line of graph in the text file.
*****/

#include<iostream>
#include<math.h>
#include<time.h>
#include<stdlib.h>
#include <fstream>

using namespace std;

const double PI = 3.14159265;//the value pi is used to a pre-defined number of decimal places


void GraphMaker()//the function that creates a sin wave in a text file
{
    ofstream myfile;//inputs into the file
    myfile.open ("graph.txt");//the result is created in a text file by the name 'graph'
    for (int m = 0; m<360; m++)//for loop used for incrementing m, notice how m<360 means as a sin function used a complete cycle is shown
    {
        float points = (sin(m*(PI/180)));//random is a decimal value according to the incrementing value of m which is inputted into sin function in radians
        float shape= (points*72) + 72;//stretch and offset is adjusted to random and incorporated into float ran
        cout<<shape<<" ";//shape is outputted
        for (int i = 0; i<shape; i++)//now a loop to input into text file line by line according to previous loop
            myfile<<" ";//prints the value on each increment and places spaces in text file as much as the value of ran
        myfile<<"*\n";//in text file places *asterick after the spaces and changes line using \n
    }
}

int main()
{
    GraphMaker();//the function GraphMaker is called here
    return 0;
}
