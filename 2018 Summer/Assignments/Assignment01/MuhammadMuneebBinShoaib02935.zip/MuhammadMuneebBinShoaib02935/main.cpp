#include<iostream>   //  library which includes input / output functions etc.
#include<math.h>     //  library which includes mathematics built-in functions.
#include<stdlib.h>    //  standard library to include data types etc.
#include <fstream>   //  library to include the functionality of reading or writing a file.

using namespace std;    //  for repetitive use of cout and cin.

const double PI = 3.14159265;   // value of pi which cannot be changed.

void GraphMaker()                      // function which plots sine wave in .txt file.
{
    ofstream sinefile;                  // declared a file to write in.
    sinefile.open("graph.txt");         // open the file with name "graph" and format .txt.
    int count=0;
    while (count<360)                   // run loop from 0 to 360 to draw the one complete cycle of sine wave.
    {
        double space=50+50*sin(count*(PI/180));   //  variable named "space" is used to define a sine wave with amplitude "50" and
                                                                            // angle is increasing by 1 degree which is being converted into radians each
                                                                            //time the while loop runs. 50 is added to shift the sine wave near to the middle of .txt file.
        for (int i=0;i<space;i++)
        {
            sinefile<<' ';                                              // this loop increases the space in the start of each line in .txt file to form a sine
                                                                            // wave.
        }
        sinefile<<"@";
        sinefile<<"\n";                                             //  go to next line in .txt file.
        count = count + 1;

    }
}


int main()
{
    GraphMaker();                // "GraphMaker" function is called.
    return 0;
}

