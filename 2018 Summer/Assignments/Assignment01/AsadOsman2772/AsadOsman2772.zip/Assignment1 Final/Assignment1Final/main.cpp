#include<iostream>
#include<math.h>
#include<time.h>
#include<stdlib.h>
#include <fstream>

using namespace std;

const double PI = 3.14159265;


void GraphMaker()
{
    ofstream myfile;                        //Define a file to write into
    myfile.open ("graph.txt");              //Open a file graph.txt to write into

    int count = 0;                          //initialize a counter, this will be used for number of cycles of the code

    while (count < 2)                         //while condition will make the code run twice, this will also generate 2 sine waves of period 2*PI
    {
        int angle = 0;                       //this variable will be used as the angle for determining number of spaces required

        while (angle < 360)                  //while condition will allow the loop to run till 360 degrees
        {
            int spaces=(sin( PI * angle / 180) * 45) + 50;      //a variable for number of spaces is defined which stores the number of spaces required
                                                                //45 is the amplitude and 50 is the initial shift required so that the negative cycle is printed properly on text file
                                                                //the angle is also multiplied by PI/180 to convert into radians

            for (int i = 0; i<spaces; i++)                 //the for loop will now print a space an loop until the required number of spaces is achieved
            {
                myfile<<" ";                //printing of space

            }
            myfile<<"*";                    //after the required spaces are printed, an asterisks is printed at the end
            myfile<<"\n";                   //code goes to next line in text file
            angle++;                       //next angle is inputed and the 2nd while loop repeats
        }

        count = count + 1;                  //counter increments
    }

}


int main()
{
    GraphMaker();                           //GraphMaker function is called and sine wave text file is generated
    return 0;
}

