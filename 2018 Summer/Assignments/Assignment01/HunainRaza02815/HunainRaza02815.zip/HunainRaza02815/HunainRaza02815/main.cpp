#include<iostream>
#include<math.h>
#include<time.h>
#include<stdlib.h>
#include <fstream>

using namespace std;

const double PI = 3.14159265;

void GraphMaker()
{
    //Write correct code to complete this function

    ofstream myfile;
    myfile.open ("graph.txt");
    double result;
    int amplitude;

   for (int deg=0;deg<360;deg++)     //runs 360 times for 1 period of a sine wave
  {
      result = sin (deg*PI/180);    //converts deg to radians and calculates sine
      amplitude = result*50;        //increases the value times 50 and converts float to int

      for (int j=0;j<(50+amplitude);j++)
      {
            myfile<<" ";        //gives 50 blank spaces first as base and then adds further spaces according to the amplitude
      }
      myfile<<"*\n";             // prints a "*" at that position in the file

  }

}

int main()
{
    GraphMaker();

    return 0;

}
