#pragma once
#include"Stack.h"
#include"Rect.h"
struct Node//a struct Node
{//struct made as no private attributes required
    Rect* data;//pointer of type Rect
    Node* next;//pointer of type Node
};
