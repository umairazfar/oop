/*****
By: S.M.Umair Hashmi I.D:sh02513 OOP Assignment 4
The result is created in SDL Window.
*****/
//Using SDL and standard IO
#include <SDL.h>
#include <stdio.h>
//#include <string>
#include <cmath>
#include <iostream>
#include"Rect.h"
#include"Stack.h"
#include<stdlib.h>
//Screen dimension constants
const int SCREEN_WIDTH = 640;
const int SCREEN_HEIGHT = 480;

bool init();//Starts up SDL and creates window
bool loadMedia();//Loads media
void close();//Frees media and shuts down SDL

SDL_Window* gWindow = NULL;//The window we'll be rendering to
SDL_Renderer* gRenderer = NULL;

bool init()
{
    bool success = true;//Initialization flag

    if( SDL_Init( SDL_INIT_VIDEO ) < 0 )//Initialize SDL
    {
        printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
        success = false;
    }
    else
    {
        //Set texture filtering to linear
        if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
        {
            printf( "Warning: Linear texture filtering not enabled!" );
        }

        //Create window
        gWindow = SDL_CreateWindow( "OOP Assignment 4", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
        if( gWindow == NULL )
        {
            printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
            success = false;
        }
        else
        {
            //Create renderer for window
            gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED );
            if( gRenderer == NULL )
            {
                printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
                success = false;
            }
            else
            {
                //Initialize renderer color
                SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );


            }
        }
    }

    return success;
}

bool loadMedia()
{
    bool success = true;//Loading success flag
    return success;
}

void close()
{
    //Destroy window
    SDL_DestroyRenderer( gRenderer );
    SDL_DestroyWindow( gWindow );
    gWindow = NULL;//Deallocate surface
    gRenderer = NULL;
    //Quit SDL subsystems
    SDL_Quit();
}

int main( int argc, char* args[] )
{
    //Start up SDL and create window
    if( !init() )
    {
        printf( "Failed to initialize!\n" );//failure
    }
    else
    {
        if( !loadMedia() )  //Load media
        {
            printf( "Failed to load media!\n" );//failure
        }
        else
        {
            bool quit = false;  //Main loop controller

            SDL_Event e;        //Event handler that takes care of all events

            bool mouseClicked = false;
            SDL_Rect fillRect;//object of SDL_Rect
            int oldx = 0;//integer
            int oldy = 0;//integer
            Rect* rect = NULL;//pointer of a type Rect
            Stack stk;//object of Stack
            Stack reStack;//object of Stack
            //While application is running
            while( !quit )
            {
                //Handle events on queue
                while( SDL_PollEvent( &e ) != 0 )
                {
                    //User requests quit
                    if( e.type == SDL_QUIT )
                    {
                        quit = true;
                    }

                    if( e.type == SDL_MOUSEMOTION || e.type == SDL_MOUSEBUTTONDOWN || e.type == SDL_MOUSEBUTTONUP )//regarding mouse activity
                    {
                        //Get mouse position
                        int x, y;
                        SDL_GetMouseState( &x, &y );//position of mouse

                        if(e.type ==  SDL_MOUSEMOTION)//mouse is dragging
                        {
                            if(mouseClicked == true)
                                fillRect = { oldx, oldy, x - oldx, y - oldy };//fill with color across the rectangle made
                        }

                        if(e.type == SDL_MOUSEBUTTONDOWN)//mouse button pressed
                        {
                            if (e.button.button == SDL_BUTTON_LEFT)//left mouse button pressed
                            {
                                if(mouseClicked == false)
                                {
                                    mouseClicked = true;
                                    oldx = x;
                                    oldy = y;
                                }
                            }
                        }

                        if(e.type == SDL_MOUSEBUTTONUP)//mouse button released
                        {
                            mouseClicked = false;
                            rect = new Rect( &fillRect );//new rectangle being made
                            if (e.button.button == SDL_BUTTON_RIGHT)//right mouse button pressed
                            {
                                    reStack.Push(stk.Pop());//rectangle stored in Stack stk and put into Stack reStack
                                    stk.Show(gRenderer);//shows all rectangles in Stack
                            }
                            if (e.button.button == SDL_BUTTON_LEFT)//left mouse button pressed
                            {
                                stk.Push(rect);//put address of rectangle into Stack stk
                                reStack.doEmpty();//function called
                            }
                            if(e.button.button == SDL_BUTTON_MIDDLE)//middle mouse button pressed
                            {
                                if (!reStack.ifEmpty())//function called
                                {
                                    Rect* temp=reStack.Pop();
                                    stk.Push(temp);//taken from reStack put into stk back
                                }
                            }
                        }
                    }
                }
                //Clear screen
                SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );
                SDL_RenderClear( gRenderer );
                if (rect != NULL)
                {
                    SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
                    stk.Show(gRenderer);
                }
                SDL_RenderPresent( gRenderer );
            }
        }
    }
    close();
    return 0;
}
