#pragma once
#include"SDL.h"
#include"Point.h"

/** Rect class **/

class Rect
{
public:
    Rect();
    Rect(SDL_Rect*);
    void Draw(SDL_Renderer*, SDL_Rect*);
    SDL_Rect* GetSdlRect();    //to access private attribute

private:
    SDL_Rect* fillRect;
    //Color color;
    Point topLeft;
    Point bottomRight;
};

