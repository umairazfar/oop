#pragma once
#include "Rect.h"
#include<iostream>

using namespace std;
struct Node
{
    Rect* data;
    Node* next;
    ~Node()
    {
        delete data;
        cout << "destructor called" << endl;
    }
};

