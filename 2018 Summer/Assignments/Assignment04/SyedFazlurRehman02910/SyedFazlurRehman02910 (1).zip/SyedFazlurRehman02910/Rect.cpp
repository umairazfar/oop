#include"Rect.h"
#include<iostream>
using namespace std;

Rect::Rect()
{
    cout << " constructor Called\n ";
    this->fillRect;
}

/** Draws the rectangle **/
void Rect::Draw(SDL_Renderer* gRenderer, SDL_Rect* fillRect)
{
    SDL_RenderFillRect( gRenderer, this->fillRect );
}

Rect::Rect(SDL_Rect* rect)
{
    this->fillRect = new SDL_Rect();
    this->fillRect->x = rect->x;
    this->fillRect->y = rect->y;
    this->fillRect->w = rect->w;
    this->fillRect->h = rect->h;
}

SDL_Rect* Rect::GetSdlRect()
{
    return fillRect;
}


