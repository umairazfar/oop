#pragma once
#include"Node.h"
#include"Rect.h"

class Stack
{
public:
    Stack();
    ~Stack();
    void Push(Rect*);
    Rect* Pop();
    void Show(SDL_Renderer*);
    void Clear();
    int EmptyCheck();
    int stackLength = 0;

private:
    Node* head;
};

