#include"Stack.h"
#include"Rect.h"
#include"SDL.h"
#include"Node.h"

#include <iostream>
using namespace std;

Stack::Stack()
{
    head = NULL;
}

Stack::~Stack()
{
    while(head != NULL)
    {
        Node* temp = head;
        head = head->next;
        temp->data;
        delete temp;
    }
}

void Stack::Push(Rect* val)     //function to Push objects in stack
{
    stackLength++;
    if (head == NULL)
    {
        head = new Node;
        head->data = val;
        head->next = NULL;
        cout << "Push called" << endl;
    }
    else
    {
        Node* temp = head;
        head = new Node;
        head->data = val;
        head->next = temp;
        cout << "Push called" << endl;
    }
}

Rect* Stack::Pop()
{
    stackLength--;
    Rect* val;
    if(head != NULL)
    {
        Node* temp = head;
        head = head->next;
        val = temp->data;
        delete temp;
        temp = NULL;
        cout << " Pop called " << endl;
    }
    return val;
}


void Stack::Show(SDL_Renderer* gRenderer)
{
    Node* temp = head;
    Rect* rec;
    while(temp != NULL)
    {
        rec = temp->data;
        rec->Draw (gRenderer, rec->GetSdlRect());
        temp = temp->next;
    }
}

void Stack::Clear()
{
    Node* temp = head;
    while (temp != NULL)
    {
        Stack::Pop();
        temp = temp->next;
    }
}

int Stack::EmptyCheck()
{
    return stackLength;
}
