#pragma once
#include <SDL.h>
#include"Rect.h"
#include"Node.h"

class Stack     //Creating stack class
{
public:
    Stack();
    ~Stack();
    void push(Rect*);   //Pushing the objects in stack
    Rect* pop();        //Popping the objects from stack
    void Draw(SDL_Renderer*);       //Function to Draw rectangles
    void Show(SDL_Renderer*);       //Function to  show the drawn rectangles.

private:
    Node* head;

};
