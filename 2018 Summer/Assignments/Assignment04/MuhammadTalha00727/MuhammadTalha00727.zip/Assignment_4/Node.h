#pragma once
#include "Rect.h"
#include <SDL.h>

struct Node
{
    Rect* data;
    Node* next;
};
