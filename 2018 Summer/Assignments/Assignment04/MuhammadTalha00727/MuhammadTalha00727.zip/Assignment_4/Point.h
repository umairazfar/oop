#pragma once

struct Point
{
    int x;        //Declaring coordinates
    int y;

    Point()     //Point constructor
    {
        this->x = 0;
        this->y = 0;
    }

    Point(int x, int y)     //Overloaded Point constructor
    {
        this->x = x;
        this->y = y;
    }

    Point(const Point& point)   //Copy constructor
    {
        x = point.x;
        y = point.y;
    }

};
