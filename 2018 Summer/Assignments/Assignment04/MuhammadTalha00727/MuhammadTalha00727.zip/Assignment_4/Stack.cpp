#include"Stack.h"
#include"Rect.h"
#include <iostream>
#include <SDL.h>

using namespace std;

Stack::Stack()      //Declaring constructor
{
    head = NULL;
}

Stack::~Stack()     //Declaring destructor
{
    head = NULL;
    cout<<"Destructor called"<<endl;
}

void Stack::push(Rect* object)
{
    if (head == NULL)   //For first case when stack is empty
    {
        head = new Node;
        head->data = object;
        head->next = NULL;
    }
    else
    {
        Node* temp = head;
        head = new Node;
        head->data = object;
        head->next = temp;
    }

}

Rect* Stack::pop()
{
    Rect* object = NULL;        //Declaring a pointer of type Type to point at the stored object in the stack
    if(head != NULL)
    {
        Node* temp = head;  //Creating temporary pointer of type Node and now both head and temp are pointing at same object
        head = head->next;
        object = temp->data;
        delete temp;        //Deleting temporary pointer
        temp = NULL;

    }
    return object;      //Returning the popped object
}

void Stack::Show(SDL_Renderer *gRenderer)   //Showing the drawn rectangles
{
    Node* temp = head;      //Declaring temporary pointer temp
    while(temp!=NULL)       //Temp will only become NULL when all the object will be popped, hence
    {
        temp->data->Draw( gRenderer );
        temp = temp->next;
    }
}
