#pragma once
#include"Point.h"
#include"SDL.h"


/** Rect class **/

class Rect
{
public:
    Rect(SDL_Rect);     //Overloaded Rect constructor
    void Draw(SDL_Renderer*);

private:
    SDL_Rect fillRect;
};

