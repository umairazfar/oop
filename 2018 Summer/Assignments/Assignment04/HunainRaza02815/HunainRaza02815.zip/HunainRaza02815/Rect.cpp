#include"Rect.h"
#include<iostream>
using namespace std;
Rect::Rect(SDL_Rect* rect)
{
    this->fillRect = new SDL_Rect;

    this->fillRect->x = rect->x;            //assigns members of the fillrect of rect class to the members of the rect object in the parameter
    this->fillRect->y = rect->y;
    this->fillRect->w = rect->w;
    this->fillRect->h = rect->h;

}


/** Draws the rectangle **/
void Rect::Draw(SDL_Renderer* gRenderer, SDL_Rect* fillRect)
{
    SDL_RenderFillRect( gRenderer, fillRect );  //sdl drawing function
}

SDL_Rect* Rect::Get_fillRect()
{
    return fillRect;
}
Rect::~Rect()
{
    //std::cout<<"\nRect destructor called"<<std::endl;
    //delete fillRect;
    //fillRect = NULL;
    //cout<<"Fillrect destroyed"<<endl;
}
