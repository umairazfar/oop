#pragma once
#include"Node.h"

class Stack
{
private:
    Node* head;

public:
    Stack();
    ~Stack();
    void Push(Rect* rect);
    Rect* Pop();
    void Show(SDL_Renderer*);
};
