#pragma once
#include"Rect.h"

struct Node
{
    Rect* data;
    Node* next;
};
