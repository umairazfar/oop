#include"Stack.h"
#include <iostream>

Stack::Stack()
{
    std::cout<<"stack constructor called"<<std::endl;
    head = NULL;
}

Stack::~Stack()
{
    std::cout<<"\nStack destructor called"<<std::endl;
    //std::cout<<"\nRect destructor called"<<std::endl;
    //delete fillRect;
    //fillRect = NULL;
    //std::cout<<"Fillrect destroyed"<<std::endl;
    head = NULL;
}

void Stack::Push(Rect* rect)   //int val)
{
      std::cout<<"stack push called"<<std::endl;
    if (head == NULL)
    {
        head = new Node;
        head->data = rect;

        head->next = NULL;
    }
    else
    {

        Node* temp = head;
        head = new Node;
        head->data = rect;
        head->next = temp;
    }
}

Rect* Stack::Pop()
{
    Rect* data = NULL;
    if(head != NULL)
    {
        Node* temp = head;
        head = head->next;
        data = temp->data;
        delete temp;
        temp = NULL;
    }
    return data;
}

void Stack::Show(SDL_Renderer* gRenderer)
{
    Node* temp = head;
    while(temp != NULL)                             //draws all the rects in the stack. Each rect's fillrect is passed in the draw function
    {
        temp->data->Draw(gRenderer, temp->data->Get_fillRect());   //Get fillrect function gets the fillrect member of the rect object we want to draw and passes it in the draw function
        temp = temp->next;
    }
}
