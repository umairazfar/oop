#include"Stack.h"
#include <iostream>

using namespace std;

Stack::Stack()
{
    head = NULL;
}

void Stack::Push(SDL_Rect val)
{
    if (head == NULL)
    {
        head = new Node;
        head->data = val;
        head->next = NULL;
    }
    else
    {
        Node* temp = new Node;
        temp->data = val;
        temp->next = head;
        head=temp;

    }
}

SDL_Rect Stack::Pop()
{
    SDL_Rect val;
    if (head != NULL)
    {
        Node* temp;
        temp=head;
        head=head->next;
        val = temp->data;
        delete temp;
    }
    return val;

}

void Stack::Show(SDL_Renderer* gRenderer )
{
    Node* temp = head;
    while(temp!=NULL)
    {
        SDL_RenderFillRect( gRenderer, &(temp->data) );
        temp = temp->next;
    }

}

void Stack::Vacate()
{
    while(head!=NULL)
    {
        Pop();
    }
}

Stack::~Stack()
{
    while (head != NULL)
    {
        Pop();
        cout<<"Node Deleted"<<endl;
    }
}

