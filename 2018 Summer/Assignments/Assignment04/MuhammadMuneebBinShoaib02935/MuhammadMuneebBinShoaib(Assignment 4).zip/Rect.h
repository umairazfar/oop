#pragma once
#include"SDL.h"
#include"Point.h"

/** Rect class **/

class Rect                    // class for rectangle is declared.
{
private:
    SDL_Rect fillRect;      // object of built in SDL rectangle class is declared.
    Point topLeft;
    Point bottomRight;
public:
    Rect(SDL_Rect);       // overloaded constructor of class rectangle is declared.
    void Draw(SDL_Renderer*);  // draw function which takes pointer of type SDL_Renderer built in SDL type.
};

