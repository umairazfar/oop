#pragma once
#include"Node.h"
#include"Rect.h"

class Stack                    // class "stack" is declared for linked list.
{
private:
    Node* head;               // pointer is declared of type Node.
public:
    Stack();                     // constructor of a class. It assigns the head pointer to NULL.
    ~Stack();                   // destructor of a class. It empties the stack.
    void Push(SDL_Rect);   // It push the rectangle type object into the stack.
    SDL_Rect Pop();          // It pops the last in element from the stack.
    void Vacate();             // It calls the pop function.
    void Show(SDL_Renderer*);    // It takes the SDL_Renderer type pointer and calls the built in function of SDL_RenderFillRect which
    // shows the rectangle on screen.
};

