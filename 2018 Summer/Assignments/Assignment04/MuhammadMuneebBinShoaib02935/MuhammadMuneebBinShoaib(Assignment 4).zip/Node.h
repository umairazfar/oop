#pragma once
#include "Rect.h"



struct Node                  // structure of node is declared.
{
    SDL_Rect data;          // data of type SDL_Rect is declared.
    Node* next;              // pointer of type node is declared.
};
