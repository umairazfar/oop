#pragma once
//Explain access specifier and classes
struct Light
{
    bool activated;
    int brightness;
    Light();
    Light(bool active, int bright);
    void Brighten();
    void Dim();
    void ShowStatus();
};
