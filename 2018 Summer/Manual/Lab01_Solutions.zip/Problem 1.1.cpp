#include <iostream>

using namespace std;

int main()
{
    int Hardness;
    int CarbonContent;
    double TensileStrength;

    cout << "Enter Hardness of the Steel: " << endl;
    cin >> Hardness;

    cout << "Enter Tensile Strength of the Steel: " << endl;
    cin >> TensileStrength;

    cout << "Enter Carbon Content of the Steel: " << endl;
    cin >> CarbonContent;

    bool Condition1 = Hardness > 50;
    bool Condition2 = CarbonContent < 0.7;
    bool Condition3 = TensileStrength > 5600;

    //For Grade 10
    int Grade;

    if (Condition1 && Condition2 && Condition3)
    {
        Grade = 10;
    }

    else if (Condition1 && Condition2)
    {
        Grade = 9;
    }

    else if (Condition1 && Condition3)
    {
        Grade = 8;
    }

    else if (Condition1 && Condition3)
    {
        Grade = 7;
    }

    else if (Condition1 || Condition2 || Condition3)
    {
        Grade = 6;
    }

    else
    {
        Grade = 5;
    }

    cout << "The grade of the steel is: " << Grade << endl;


    return 0;
}
