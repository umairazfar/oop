#include <iostream>

using namespace std;

bool isPrime(int n)
{
    bool isPrimeCheck = true;;

    for (int i = 2; i < n; i++)
    {
        if ( n % i == 0 )
        {
            isPrimeCheck = false;
        }
    }

    return isPrimeCheck;
}

int Fibonacci (int n)
{
  int Term1 = 0, Term2 = 1, SumOfTerm1AndTerm2;
  if ( n == 0 )
  {
    return Term1;
  }

  for (int i = 2; i <= n; i++)
  {
     SumOfTerm1AndTerm2 = Term1 + Term2;
     Term1 = Term2;
     Term2 = SumOfTerm1AndTerm2;
  }

  return Term2;
}

int main()
{

    int PrimeFibonacciNumbers = 0;
    int n = 1;

    while (PrimeFibonacciNumbers != 5)
    {
        int nthFibonacci = Fibonacci(n);
        if (isPrime(nthFibonacci))
        {
            cout << nthFibonacci << endl;
            PrimeFibonacciNumbers++;
        }

        n++;
    }


    return 0;
}
