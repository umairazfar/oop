#include <iostream>
#include <cstddef>
#include <cstdlib>
using namespace std;
bool checkTemp(int curr,int* tem)
{
    if (curr>tem[0] || curr<tem[1])
    {
        return (true);
    }
    return false;
}
void checkPes(int curr,int& max,int* min, bool& alar)
{
    if (curr>max || curr<*min)
    {
        alar = true;
    }
}
void checkHum(int curr,int* max,int* min, bool* alar)
{
    if (curr> *max || curr<*min)
    {
        *alar = true;
    }
}
int main()
{
    int humdity[2] = {0};
    int temp[2] = {0};
    int press[2] = {0};
    int current_reading[3] = {0};
    bool alarm = false;


    for (int i = 0;i<50;i ++)     //menu display
      {
       cout<<"~";
      }
    cout<<"\n WELCOME TO DATA CENTER ALARM PROBLEM"<<endl;     //menu display
    for (int i = 0;i<50;i ++)     //menu display
      {
      cout<<"~";
      }
    cout<<endl;
    cout<<"Please enter maximum limit of temperature: ";
    cin>>temp[0]; cout<<endl;
    cout<<"Please enter minimum limit of temperature: ";
    cin>>temp[1]; cout<<endl;

    cout<<"Please enter maximum limit of pressure: ";
    cin>>press[0]; cout<<endl;
    cout<<"Please enter minimum limit of pressure: ";
    cin>>press[1]; cout<<endl;


    cout<<"Please enter maximum limit of humidity: ";
    cin>>humdity[0]; cout<<endl;
    cout<<"Please enter minimum limit of humidity: ";
    cin>>humdity[1]; cout<<endl;

    system("CLS");
    bool terminator = false;
    char inp;
    while (terminator != true)
    {
        cout<<"Please enter current reading of temperature: ";
        cin>>current_reading[0]; cout<<endl;
        cout<<"Please enter current reading of pressure: ";
        cin>>current_reading[1];cout<<endl;
        cout<<"Please enter current reading of humidity: ";
        cin>>current_reading[2];cout<<endl;

        alarm = checkTemp(current_reading[0],temp);
        checkPes(current_reading[1],press[0],&press[1], alarm);
        checkHum(current_reading[2], &humdity[0], &humdity[1], &alarm);

        if (alarm == true)
        {
            cout<<"Alarm is on"<<endl;
        }
        else
        {
           cout<<"All is well"<<endl;
        }

        cout<<"enter 'c' to continue and 'e' to exit ";
        cin>>inp;cout<<endl;


        if (inp == 'e')
        {
            terminator = true;
        }
        else if(inp == 'c')
        {
            system("CLS");
        }
        else
        {
            cout<<"You entered wrong input, program terminated"<<endl;
            terminator = true;
        }


    }



    return 0;
}
