#include <iostream>

using namespace std;

class SuperString
{
private:
    char* text;
    int length;
public:
    SuperString()
    {
        length = 0;
        text = NULL;
    }
    SuperString(char* text)
    {
        length = 0;
        char c = text[0];
        while ( c!= '\0')
        {
            c = text[++length];

        }

        this->text = new char[length+1];
        for (int i=0; i<length; i++)
        {
            this->text[i] = text[i];
        }
        this->text[length] = '\0';
    }

    SuperString(const SuperString& myString)
    {
        this->text = new char[myString.length];
        this->length = myString.length;
        for (int i = 0; i< myString.length; i++)
        {
            this->text[i] = myString.text[i];
        }
        this->text[this->length] = '\0';
    }

    void Show()
    {
        if (text!= NULL)
        {
            cout<<text<<endl;
        }
        else
        {
            cout<<"";
        }
    }
SuperString Join (char array_1[], char array_2[])
    {
        int len_array_1 = 0;
        int len_array_2 = 0;
        while ( a[len_array_1] != '\0')
        {
            len_array_1++;
        }
        while ( b[len_array_2] != '\0')
        {
            len_array_2++;
        }
        int tempLen = len_array_1 + len_array_2;
        char* temp = new char[tempLen+1];
        int i = 0;
        while ( array_1[i] != '\0')
        {
            temp[i] = array_1[i];
            i++;
        }
        int j = 0;
        while ( i < tempLen)
        {
            temp[i] = array_2[j];
            i++;
            j++;
        }
        temp[tempLen] = '\0';
        SuperString s(temp);
        delete temp;
        temp = NULL;
        return s;

    }
SuperString Join (SuperString& a,SuperString& b)
{
    int new_len = a.length + b.length + 1;
    cout << new_len;
    char* temp = new char[new_len];
    int i = 0;
    int j = 0;
    while (a.text[i] != '\0')
    {
        temp[i] = a.text[i];
        i++;
    }
    while (b.text[j] != '\0')
    {
       temp[i] = b.text[j];
        i++;
        j++;
    }
    temp[i+1] = '\0';

    SuperString s(temp);
    return s;
}
SuperString Slice(int start, int end)
{
    int new_len = end - start;
    if (start < 0 || end > length)
    {
        cout<<"Incorrect index entered"<<endl;
        return *this;
    }
    char* temp = new char[new_len+1];
    int i = 0;
    while (start <= end)
    {
        temp[i] = text[start];
        start++;
        i++;
    }
    temp[new_len+1] = '\0';
    SuperString s(temp);
    delete temp;
    temp = NULL;
    return s;
}

SuperString Empty()
{
    delete text;
    text = NULL;
}


    ~SuperString()
    {
        if (text!=NULL)
        {
            delete[] text;
        }
    }
};


int main()
{
//    SuperString str("hello");
//    char a[6] = "Hello";
//    char b[6] = "World";
//    SuperString sd = (str.Join(a,b));

    SuperString a("Hello World");
    SuperString b (" World");
    SuperString c;
//    SuperString d = c.Join(a, b);
//    d.Show();
//    c = a.Slice(2,7);
    a.Empty();
    a.Show();

    return 0;
}
