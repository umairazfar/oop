#include<iostream>

using namespace std;

int* Push(int* index, int* endIndex, int val);
int* Pop(int* index, int*endIndex);

int main()
{
    int stk[4] = {0, 0, 0, 0};


    int* index = &stk[0];
    int* endIndex = &stk[3];

    index = Push(index, endIndex, 10);
    index = Push(index, endIndex, 20);
    index = Push(index, endIndex, 30);
    index = Push(index, endIndex, 40);
    index = Push(index, endIndex, 50);

    index = Pop(index, &stk[0]);
    index = Pop(index, &stk[0]);
    index = Pop(index, &stk[0]);
    index = Pop(index, &stk[0]);
    index = Pop(index, &stk[0]);


    return 0;
}

int* Push(int* ind, int* endInd, int val)
{
    if(ind != endInd+1)
    {
        *ind = val;
        ind++;
    }
    else
    {
        cout<<"\nCannot Push further\n\n";
    }


    return ind;
}

int* Pop(int* index, int*endIndex)
{
    if (index != endIndex)
    {
        index--;
        cout<<*index<<endl;
    }
    else
    {
        cout<<"\nCannot Pop further\n";
    }
    return index;
}
