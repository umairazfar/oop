#include<iostream>

using namespace std;

struct Stack
{
    int stk[4];

    Stack();
    int* Push(int* index, int* endIndex, int val);
    int* Pop(int* index, int* endIndex);
};

int main()
{
    Stack stak;
    int* index = &stak.stk[0];
    int* endIndex = &stak.stk[3];

    index = stak.Push(index, endIndex, 10);
    index = stak.Push(index, endIndex, 20);
    index = stak.Push(index, endIndex, 30);
    index = stak.Push(index, endIndex, 40);
    index = stak.Push(index, endIndex, 50);

    index = stak.Pop(index, &stak.stk[0]);
    index = stak.Pop(index, &stak.stk[0]);
    index = stak.Pop(index, &stak.stk[0]);
    index = stak.Pop(index, &stak.stk[0]);
    index = stak.Pop(index, &stak.stk[0]);


    return 0;
}

Stack::Stack()
{
    for(int i = 0; i<4; i++)
    {
        stk[i] = 0;
    }
}

int* Stack::Push(int* ind, int* endInd, int val)
{
    if(ind != endInd+1)
    {
        *ind = val;
        ind++;
    }
    else
    {
        cout<<"\nCannot Push further\n\n";
    }


    return ind;
}

int* Stack::Pop(int* index, int*endIndex)
{
    if (index != endIndex)
    {
        index--;
        cout<<*index<<endl;
    }
    else
    {
        cout<<"\nCannot Pop further\n";
    }
    return index;
}
