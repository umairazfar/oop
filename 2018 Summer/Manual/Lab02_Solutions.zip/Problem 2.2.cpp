#include<iostream>

using namespace std;

int* GetArray(int array1[], int array2[], int sizeArr1, int sizeArr2);

int main()
{
    int array1[4] = {1, 1, 1, 1};
    int array2[6] = {2, 2, 2, 2, 2, 2};

    int sizeArr1 = sizeof(array1)/sizeof(array1[0]);
    int sizeArr2 = sizeof(array2)/sizeof(array2[0]);

    int* returnedArray = GetArray(array1, array2, sizeArr1, sizeArr2);

    for(int i = 0; i<sizeArr1+sizeArr2; i++)
    {
        cout<<returnedArray[i]<<endl;
    }

    delete[] returnedArray;
    return 0;
}

int* GetArray(int array1[], int array2[], int sizeArr1, int sizeArr2)
{

    int* pArray = new int[sizeArr1 + sizeArr2];

    int i;

    for(i = 0; i<sizeArr1; i++)
    {
        pArray[i] = array1[i];
    }

    for(i = sizeArr1; i<(sizeArr1 + sizeArr2); i++)
    {
        pArray[i] = array2[i - sizeArr1];
    }

    return pArray;
}
