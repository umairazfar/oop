#include<iostream>
#include"Circle.h"

using namespace std;

int main()
{
    Circle circle1;
    Circle circle2(7,8);
    Point point;
    point.x = 90;
    point.y = 80;
    Circle circle3(point);
    circle2.Area();
    circle3.Callout();
    return 0;
}
