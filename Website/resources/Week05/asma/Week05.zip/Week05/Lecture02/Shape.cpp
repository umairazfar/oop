#include"Shape.h"

void Shape::Callout()
{
    cout<<"This is just a Shape\n";
}
