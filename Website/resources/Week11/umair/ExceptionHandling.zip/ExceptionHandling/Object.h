#include<iostream>

using namespace std;

struct Object
{
    string data;

    Object()
    {
        data = "This is data";
    }

    void Say()
    {
        cout<<data<<endl;
    }
};
