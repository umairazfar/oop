#include"Object.h"

struct Node
{
    Object* object;
    Node* next;
};

class Stack
{
private:
    Node* head;
public:
    Stack()
    {
        head = NULL;
    }
    void Push(Object* object)
    {
        if(head == NULL)
        {
            head = new Node;
            head->object = object;
            head->next = NULL;
        }
        else
        {
            Node* temp = new Node;
            temp->object = object;
            temp->next = head;
            head = temp;
        }
    }
    Object* Pop()
    {
        Object* object = NULL;
        try
        {
            if(head == NULL)
            {
                throw"Head is NULL";
            }
            object = head->object;
            head = head->next;
        }
        catch (const char* msg)
        {
            cerr << msg << endl;
            return 0;
        }
        return object;
    }
};
