#include<iostream>
#include"Stack.h"

using namespace std;


int main()
{
    cout << "**Exception Handling**"<<endl;
    Stack mainStack;
    Object* object = new Object;

    mainStack.Push(object);
    //object = mainStack.Pop();
    //object = mainStack.Pop();
    try
    {
        object = mainStack.Pop();
        object = mainStack.Pop();
        if(object == NULL)
        {
            throw"Object is NULL";
        }
    }
    catch (const char* msg)
    {
        cerr << msg << endl;
        return 0;
    }

    cout << object->data << endl;
    return 0;
}



