#include<iostream>
#include"Point.h"
#include"Stack.h"

using namespace std;

int main()
{
    Point p1(10,20);
    Point p2(10,10);

    Point p3 = p1 + p2;
    cout<<"\nShowing p3:\n";
    p3.Show();

    Point p4 = ++p3;
    cout<<"\nShowing p4:\n";
    p4.Show();
    cout<<"\nShowing p3:\n";
    p3.Show();

    Point p5 = p3++;
    cout<<"\nShowing p5:\n";
    p5.Show();
    cout<<"\nShowing p3:\n";
    p3.Show();

    p1 += p5;
    cout<<"\nShowing p1:\n";
    p1.Show();

    if(p1 == p2)
    {
        cout<<"\ntrue\n";
    }
    else
    {
        cout<<"\nfalse\n";
    }

    Stack stk;
    stk.Push(6);
    stk.Push(9);
    stk.Push(87);
    stk.Push(45);

    cout<<stk[0];

    return 0;
}
