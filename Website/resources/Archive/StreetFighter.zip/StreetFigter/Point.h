#pragma once

struct Point
{
    float x;
    float y;

    Point()
    {

    }

    Point(float x, float y)
    {
        this->x = x;
        this->y = y;
    }
};
