#pragma once
#include<iostream>
#include"allegro.h"
#include"Object.h"

using namespace std;
struct Node
{
    Object* object;
    Node* next;
    Node* prev;
    ~Node(){
        //std::cout<<"Node Deleted"<<endl;
        delete object;
    }
};
class LinkedList
{
private:
    int length;
    Node* head;
    Node* tail;
    bool collisionLeft;
    bool collisionRight;
    BITMAP* image;
public:
    LinkedList(BITMAP*);
    ~LinkedList();
    void Append(Object*);
    int Length();
    Node* GetHead();
    void MoveObjectsRight(float);
    void MoveObjectsLeft(float);
    void Draw(BITMAP*,bool);
    void Clean();
    void Save(ofstream&);

    void Update();
    void CheckCollision(Object*,Object*);
    void View(){
        Node* temp = new Node;
        temp = head;
        if (temp==NULL)
            std::cout<<"No Object"<<std::endl;
        while(temp!=NULL){
            std::cout<<"Object "<<temp->object->GetType()<<std::endl;
            temp=temp->next;
        }

    }
};


