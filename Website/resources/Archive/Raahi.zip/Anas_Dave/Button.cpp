#include"Button.h"


void Button::Initialize(std::string text, BITMAP* font_image, Point* position)
{
    word = new Word(text, font_image, position);
    image  = font_image;
    this->position.x = position->x;
    this->position.y = position->y;
}

Button::Button(std::string text, BITMAP* font_image, Point* position)
{
    word = new Word(text, font_image, position);
    image  = font_image;
    this->position.x = position->x;
    this->position.y = position->y;
}

void Button::Draw(BITMAP* buffer, int animation, bool debug)
{
    int stringLength = word->GetStringLength();
    int startx = position.x - (stringLength*36/2);
    masked_blit(image, buffer, 36*6,36*3, startx-36, position.y-36/2, 36,36);
    for (int i =0; i<stringLength-1;i++){
        masked_blit(image,buffer,36*6,36*3,startx+i*36, position.y-36/2, 36, 36);
        //position.x=i*64;
    }
    masked_blit(image,buffer, 36*6,36*3,startx+(stringLength-1)*36,position.y -36/2, 36,36);
    word->Draw(buffer, animation, debug);
}

void Button::SetPosition(Point* position)
{
    this->position.x = position->x;
    this->position.y = position->y;
}

Button::~Button()
{
    delete word;
    word = NULL;
//    delete image;
//    image = NULL;
    std::cout<<"BUTTON DESTROYED\n";
}
