#include "Map.h"
#include<iostream>
#include "Flag.h"
#include "Life.h"
#include "Pistol.h"
#include "Gate.h"

bool atobool (string myStr){
    if (myStr == "true")
        return true;
    else
        return false;
}
Map::Map(BITMAP* gameSprite,string fname,LinkedList* objList){
    //Assume Player would always be first in file.
    cout<<"Loading map from "<<fname<<"..."<<endl;
    ifstream inFile (fname.c_str());
    if (inFile.is_open())
    {
        string line;
        getline(inFile,line);
        int objType = atoi(line.c_str());
        while(!inFile.eof())
        {
            //cout<<"Object List looks like: "<<endl;
            //objList->View();
            switch (objType)
            {

            /*Reference:
                    1 Brick
                    2 Plant
                    3 Fire
                    4 Pistol
                    5 Life
                    6
                    7 Gate
                    10 Enemy1
                    20 Player
                    30 Bullet
                */

            case 1:
                {
                    getline (inFile,line);
                    int x = atoi(line.c_str());
                    getline (inFile,line);
                    int y = atoi(line.c_str());
                    getline (inFile,line);
                    int slr = atoi(line.c_str());
                    getline (inFile,line); //Wasting the line with "End"
                    Brick* brick = new Brick(gameSprite,(float) x,(float) y, slr);
                    objList->Append(brick);
                    cout<<"Successfully added Brick"<<endl;
                    //Preparing for new type
                    getline (inFile,line);
                    objType = atoi(line.c_str());
                    break;
                }
            case 2:
                {
                    getline (inFile,line);
                    int x = atoi(line.c_str());
                    getline (inFile,line);
                    int y = atoi(line.c_str());
                    getline (inFile,line); //Wasting the line with "End"
                    objList->Append(new Plant(gameSprite,(float) x,(float) y));
                    cout<<"Successfully added Plant"<<endl;
                    //Preparing for new type;
                    getline (inFile,line);
                    objType = atoi(line.c_str());
                    break;
                }
            case 3:
                {
                    getline (inFile,line);
                    int x = atoi(line.c_str());
                    getline (inFile,line);
                    int y = atoi(line.c_str());
                    getline (inFile,line); //Wasting the line with "End"
                    objList->Append(new Fire(gameSprite,(float) x,(float) y));
                    cout<<"Successfully added Fire"<<endl;
                    //Preparing for new type
                    getline (inFile,line);
                    objType = atoi(line.c_str());
                    break;
                }
            case 4:
                {
                    getline (inFile,line);
                    int x = atoi(line.c_str());
                    getline (inFile,line);
                    int y = atoi(line.c_str());
                    getline (inFile,line); //Wasting the line with "End"
                    objList->Append(new Life(gameSprite,(float) x,(float) y));
                    cout<<"Successfully added Life"<<endl;
                    //Preparing for new type;
                    getline (inFile,line);
                    objType = atoi(line.c_str());
                    break;
                }
            case 5:
                {
                    getline (inFile,line);
                    int x = atoi(line.c_str());
                    getline (inFile,line);
                    int y = atoi(line.c_str());
                    getline (inFile,line); //Wasting the line with "End"
                    objList->Append(new Pistol(gameSprite,(float) x,(float) y));
                    cout<<"Successfully added Pistol"<<endl;
                    //Preparing for new type;
                    getline (inFile,line);
                    objType = atoi(line.c_str());
                    break;
                }
            case 6:
                {
                getline (inFile,line);
                int x = atoi(line.c_str());
                getline (inFile,line);
                int y = atoi(line.c_str());
                getline (inFile,line);
                bool taken = atobool(line);

                getline (inFile,line); //Wasting the line with "End"
                Flag* flag = new Flag(gameSprite,x,y);
                flag->SetTaken(taken);
                objList->Append(flag);
                cout<<"Successfully added Flag"<<endl;
                //Preparing for new type
                getline (inFile,line);
                objType = atoi(line.c_str());
                break;
                }
                case 7:
                {
                getline (inFile,line);
                int x = atoi(line.c_str());
                getline (inFile,line);
                int y = atoi(line.c_str());

                getline (inFile,line); //Wasting the line with "End"
                Gate* gate = new Gate(gameSprite,x,y);
                objList->Append(gate);
                cout<<"Successfully added Flag"<<endl;
                //Preparing for new type
                getline (inFile,line);
                objType = atoi(line.c_str());
                break;
                }
            case 10:
                {
                    getline (inFile,line);
                    int x = atoi(line.c_str());
                    getline (inFile,line);
                    int y = atoi(line.c_str());
        //            getline (inFile,line);
        //            int xLimit = atoi(line);
                    if (player==NULL)
                    {
                        getline (inFile,line);
                        objType = atoi(line.c_str());
                        break;
                    }
                    Enemy1* enemy = new Enemy1(gameSprite,x,y,objList,player);
                    cout<<"Successfully added Enemy"<<endl;
                    objList->Append(enemy);
                    getline (inFile,line); //Wasting the line with "End"
                    //Preparing for new type
                    getline (inFile,line);
                    objType = atoi(line.c_str());
                    enemy = NULL;
                    break;
                }
            case 20:
                {
                    //Get x
                    getline (inFile,line);
                    int x = atoi(line.c_str());
                    //Get y
                    getline (inFile,line);
                    int y = atoi(line.c_str());
                    //Get state
                    getline (inFile,line);
                    int state = atoi(line.c_str());
                    //Get weapon
                    getline (inFile,line);
                    int weapon = atoi(line.c_str());
                    //Get rightleft
                    getline (inFile,line);
                    bool rightleft = atobool(line);  //write function
                    //Get Speed
                    getline (inFile,line);
                    int speed = atoi(line.c_str());
                    //Get Lives
                    getline (inFile,line);
                    int lives = atoi(line.c_str());
                    //Get Gravity
                    getline (inFile,line);
                    int gravity = atoi(line.c_str());
                    //Get Score
                    getline (inFile,line);
                    int score = atoi(line.c_str());

                    player = new Player(gameSprite,x,y,objList);
                    player->SetState(state);
                    player->SetWeapon(weapon);
                    player->SetRightLeft(rightleft);
                    player->SetSpeed(speed);
                    player->SetLives(lives);
                    player->SetGravity(gravity);
                    player->SetScore(score);

                    objList->Append(player);
                    cout<<"Successfully added Player"<<endl;
                    getline (inFile,line); //Wasting the line with "End"
                    //Preparing for new type
                    getline (inFile,line);
                    objType = atoi(line.c_str());
                    break;
                }
            case 30:
                getline (inFile,line);
                int x = atoi(line.c_str());
                getline (inFile,line);
                int y = atoi(line.c_str());
                getline (inFile,line);
                bool rightleft = atobool(line);

                getline (inFile,line); //Wasting the line with "End"

                objList->Append(new Bullet(create_sub_bitmap(gameSprite,36*11,0,36,36),(float) x,(float) y,rightleft));
                cout<<"Successfully added Bullet"<<endl;
                //Preparing for new type
                getline (inFile,line);
                objType = atoi(line.c_str());
                break;
            }
        }
    }
    else
    {
        cout<<"File could not be opened. Some error"<<endl;
    }
    inFile.close();
    cout<<"Map "<<fname<<" loaded successfully"<<std::endl;
    return;
}
Map::~Map(){
    //delete player;
}
