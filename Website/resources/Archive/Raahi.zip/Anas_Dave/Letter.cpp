#include"Letter.h"
#include<iostream>

Letter::Letter()
{
    frame_width = 36;
    frame_height = 36;
}

Letter::Letter(int frame_width, int frame_height)
{
    this->frame_width = frame_width;
    this->frame_height = frame_height;
}

Letter::~Letter()
{
    std::cout<<"\nLetter Destroyed";
}

void Letter::Initialize(BITMAP* image, Point position, int character_value)
{
    this->image = image;
    this->position.x = position.x - frame_width/2;
    this->position.y = position.y - frame_height/2;
    this->character_value = character_value;
}

void Letter::Initialize(BITMAP* image, int x, int y, int character_value)
{
    this->image = image;
    this->position.x = x - frame_width/2;
    this->position.y = y - frame_height/2;
    this->character_value = character_value;
}

void Letter::Draw(BITMAP* buffer, bool debug)
{

    if(character_value < 12)
        masked_blit(image, buffer, character_value * frame_width, 0, position.x, position.y, frame_width,frame_height);
    else if (character_value < 24)
        masked_blit(image, buffer, (character_value%12) * frame_width, frame_height, position.x, position.y, frame_width,frame_height);
    else
        masked_blit(image, buffer, (character_value%12) * frame_width, frame_height*2, position.x, position.y, frame_width,frame_height);
    if(debug == true)
    {
        line(buffer, position.x,position.y, position.x+frame_width,position.y, makecol(255, 0, 0));
        line(buffer, position.x+frame_width,position.y, position.x+frame_width,position.y+frame_height, makecol(255, 0, 0));
        line(buffer, position.x,position.y+frame_height, position.x+frame_width,position.y+frame_height, makecol(255, 0, 0));
        line(buffer, position.x,position.y+frame_height, position.x,position.y, makecol(255, 0, 0));
    }
}

void Letter::SetPosition(Point* position)
{
    this->position.x = position->x - frame_width/2;
    this->position.y = position->y - frame_height/2;
}

void Letter::SetPosition(int x, int y)
{
    this->position.x = x - frame_width/2;
    this->position.y = y - frame_height/2;
}

int Letter::GetFrameWidth()
{
    return frame_width;
}
int Letter::GetFrameHeight()
{
    return frame_height;
}
