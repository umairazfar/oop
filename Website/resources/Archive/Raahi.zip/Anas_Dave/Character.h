#pragma once
#include "Object.h"
class Character : public Object {
private:
protected:
    int health;
    float gravity;
    bool rightleft;
public:
/*Following functions are constant and needed by character child classes: Enemy and Player.*/
    Character(BITMAP* image,float x, float y)
    {
        this->position.x = x;
        this->position.y = y;
        this->gravity = 0.005;
        this->health = 100;
        this->frameWidth = 36;
        this->frameHeight = 36;
        this->alive = true;

        box = new BoundingBox(position.x-frameWidth/2,position.x+frameWidth/2,position.y-frameHeight/2,position.y+frameHeight/2);

    }
    Character(BITMAP* image,Point position)
    {
        this->alive = true;
        this->position = position;
        this->gravity = 0.005;
        this->health = 100;
        this->frameWidth = 36;
        this->frameHeight = 36;
        box = new BoundingBox(position.x-frameWidth/2,position.x+frameWidth/2,position.y-frameHeight/2,position.y+frameHeight/2);
    }
    void SetHealth(int health){
        this->health = health;
    }
    int GetHealth(){
        return health;
    }
    void TakeDamage(int damage){
        this->health = this->health-damage;
        if (health<=0)
            this->alive = false;
    }
    void SetGravity(float gravity){
        this->gravity = gravity;
    }
    float GetGravity(){
        return gravity;
    }

    void SetRightLeft(bool rightleft)
    {
    /*false is right, true is left */
        this->rightleft = rightleft;
    }

    bool GetRightLeft()
    {
        return rightleft;
    }

};

