#pragma once
#include"allegro.h"
#include"Point.h"
#include"Letter.h"

class Number : public Letter
{
private:
    int numberVal;
public:
    Number():Letter(){}
    Number(int fw,int fh) : Letter(fw,fh){}

    void Initialize(BITMAP* image, Point position, int numberVal) //: Letter::Initialize(image, position,numberVal)
    {
        this->numberVal = numberVal;
        this->image = image;
        this->position.x = position.x - frame_width/2;
        this->position.y = position.y - frame_height/2;
    }
    void Initialize(BITMAP* image, int x, int y, int numberVal) //: Letter::Initialize(image, x, y,numberVal)
    {
        this->numberVal = numberVal;
        this->image = image;
        this->position.x = x - frame_width/2;
        this->position.y = y - frame_height/2;
    }


    void Draw(BITMAP* buffer, bool debug)
    {
        masked_blit(image, buffer, (numberVal+2) * frame_width, 36*4, position.x, position.y, frame_width,frame_height);
        if(debug == true)
        {
            line(buffer, position.x,position.y, position.x+frame_width,position.y, makecol(255, 0, 0));
            line(buffer, position.x+frame_width,position.y, position.x+frame_width,position.y+frame_height, makecol(255, 0, 0));
            line(buffer, position.x,position.y+frame_height, position.x+frame_width,position.y+frame_height, makecol(255, 0, 0));
            line(buffer, position.x,position.y+frame_height, position.x,position.y, makecol(255, 0, 0));
        }
    }
};
