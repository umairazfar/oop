//#pragma once
//#include <allegro.h>
//#include "Object.h"
//#include "Point.h"
//#include "Word.h"
////#include "BoundingBox.h"
//
//class Score{
//protected:
//
//private:
//    long int frameCounter;
//    int* score;
//    Word scoreWord;
//public:
//    Score(BITMAP* image, Point position,int* score)
//    {
//        scoreWord.Initialize(*score, image,&position);
//    }
//
//    void Draw(BITMAP* buffer, bool debug){
//        //Have to implement animation.
//        scoreWord.Draw(buffer,0,debug);
//    }
//
//};
//
//
//
