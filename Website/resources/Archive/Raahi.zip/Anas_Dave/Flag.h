
#pragma once
#include <allegro.h>
#include "Object.h"
#include "Point.h"
#include <sstream>
//#include "BoundingBox.h"

class Flag : public Object {
protected:

private:
    long int frameCounter;
    bool taken;
public:
    Flag(BITMAP* image, Point position) : Object(image, position)
    {
        this->image = create_sub_bitmap(image,4*36,8*36,frameWidth*8,frameHeight);
        this->type=6;
        frameCounter = 0;
        taken = false;
    }
    Flag(BITMAP* image, Point position,bool taken) : Object(image, position)
    {
        this->image = create_sub_bitmap(image,4*36,8*36,frameWidth*8,frameHeight);
        this->type=6;
        frameCounter = 0;
        this->taken = taken;
    }

    Flag(BITMAP* image, float x, float y) : Object(image, x, y)
    {
        this->image = create_sub_bitmap(image,0*36,9*36,frameWidth*4,frameHeight);
        this->type=6;
        frameCounter = 0;
        taken = false;
    }
    void Draw(BITMAP* buffer, bool debug)
    {
        if (frameCounter<60)
        {
            if (!taken)
                masked_blit(image, buffer, 36*4,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            else
                masked_blit(image, buffer, 0,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
        }
        else if (frameCounter>=60 && frameCounter<120)
        {
            if (!taken)
                masked_blit(image, buffer, 36*5,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            else
                masked_blit(image, buffer, 36,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
        }
        else if (frameCounter>=120 && frameCounter<180)
        {
            if (!taken)
                masked_blit(image, buffer, 36*6,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            else
                masked_blit(image, buffer, 36*2,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
        }
        else if (frameCounter>=180 && frameCounter<240)
        {
            if (!taken)
                masked_blit(image, buffer, 36*7,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            else
                masked_blit(image, buffer, 36*3,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
        }
        else
        {
            frameCounter = 0;
        }

    }
    void Move(float x, float y)
    {
        position.x += x;
        position.y += y;
        box->Update(position.x-frameWidth/2,position.x+frameWidth/2,position.y-frameHeight/2,position.y+frameHeight/2);
    }
    bool GetTaken()
    {
        return taken;
    }
    void SetTaken(bool taken)
    {
        this->taken = taken;
    }
    void Update()
    {
        box->Update(position.x-frameWidth/2,position.x+frameWidth/2,position.y-frameHeight/2,position.y+frameHeight/2);
    }
    string GetSaveState()
    {
        ostringstream out;
        out<< this->type<<endl;
        out<<this->position.x<<endl;
        out<<this->position.y<<endl;
        out<<this->taken<<endl;
        out<<"End\n";
        return out.str();
    }
};




