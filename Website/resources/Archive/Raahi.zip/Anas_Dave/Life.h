
#pragma once
#include <allegro.h>
#include "Object.h"
#include "Point.h"
//#include "BoundingBox.h"

class Life : public Object {
protected:

private:

public:
    Life(BITMAP* image, Point position) : Object(image,position)
    {
        this->image = create_sub_bitmap(image,11*36,3*36,frameWidth,frameHeight);
        this->type= 4;

    }
    Life(BITMAP* image, float x, float y) : Object(image, x, y)
    {
        this->image = create_sub_bitmap(image,11*36,3*36,frameWidth,frameHeight);
        this->type= 4;
    }

    void Draw(BITMAP* buffer, bool debug){
        masked_blit(image, buffer, 0,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
        box->Draw(buffer, debug);
    }
    void Move(float x, float y)
    {
        position.x += x;
        position.y += y;
        box->Update(position.x-frameWidth/2,position.x+frameWidth/2,position.y-frameHeight/2,position.y+frameHeight/2);
    }
    void Update(){
        box->Update(position.x-frameWidth/4,position.x+frameWidth/4,position.y-frameHeight/2,position.y+frameHeight/2);
    }
    string GetSaveState()
    {
        ostringstream out;
        out<< this->type<<"\n";
        out<<this->position.x<<endl;
        out<<this->position.y<<endl;
        out<<"End\n";
        return out.str();
    }

};



