#pragma once
#include"allegro.h"

struct BoundingBox
{
    float left;
    float right;
    float top;
    float bottom;

    BoundingBox(float left, float right, float top, float bottom)
    {
        this->left = left;
        this->right = right;
        this->top = top;
        this->bottom = bottom;
    }
    void Draw(BITMAP* buffer, bool debug)
    {
        if(debug == true)
        {
            line(buffer, left, top, right, top, makecol(255,0,0));
            line(buffer, left, bottom, right, bottom, makecol(255,0,0));
            line(buffer, left, top, left, bottom, makecol(255,0,0));
            line(buffer, right, top, right, bottom, makecol(255,0,0));
        }
    }
    void Update(float left, float right, float top, float bottom)
    {
        this->left = left;
        this->right = right;
        this->top = top;
        this->bottom = bottom;
    }
};
