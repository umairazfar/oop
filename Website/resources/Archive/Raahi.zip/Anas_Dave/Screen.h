#pragma once
#include <allegro.h>

class Screen {
private:
//    volatile long speed_counter = 0; // A long integer which will store the value of the speed counter.
//    volatile long objectCounter = 0;

protected:
public:
    Screen (){}
    ~Screen (){}

    void PlayGame()
    {
    }
};
