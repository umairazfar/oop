#include <allegro.h>
#include"Point.h"
#include"Player.h"
#include"LinkedList.h"
#include<iostream>
#include <string>
#include "Object.h"
#include "Enemy1.h"
#include "Brick.h"
#include "Plant.h"
#include <fstream>
#include "Screen.h"
#include "Fire.h"
#include "Map.h"
#include "SplashScreen.h"
#include "MenuScreen.h"
#include "GameScreen.h"
#include "PauseScreen.h"
#include "GameOverScreen.h"
#include "Score.h"
#include "Pistol.h"
#include "Gate.h"
#include "Flag.h"


        /*Remove Block of Code to include in Game Screen */
        volatile long speed_counter = 0; // A long integer which will store the value of the speed counter.
        volatile long objectCounter = 0;

        void increment_speed_counter() // A function to increment the speed counter
        {
          speed_counter++; // This will just increment the speed counter by one. :)
          objectCounter++;
        }
        END_OF_FUNCTION(increment_speed_counter);

        /* Uptill Here */

int main(int argc, char* argv[])
{
	if (allegro_init() != 0)
	{
		allegro_message("Cannot initialize Allegro.\n");
		return 1;
	}

	//Set the window title when in a GUI environment
	set_window_title("Dave");

	if (install_keyboard()) {
		allegro_message("Cannot initialize keyboard input.\n");
		return 1;
	}

	if (install_timer()) {
		allegro_message("Cannot initialize timer.\n");
		return 1;
	}

	install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, "");

    /*Figure out a way to cut this too. */
                //Setting FPS to 60
                LOCK_VARIABLE(speed_counter); //Used to set the timer - which regulates the game's speed
                LOCK_FUNCTION(increment_speed_counter);
                install_int_ex(increment_speed_counter, BPS_TO_TIMER(60));//Set our BPS

	//set graphics mode, trying all acceptable depths
	set_color_depth(32);

	set_color_depth(desktop_color_depth());
	set_gfx_mode(GFX_SAFE, 640, 480, 0, 0);
//    Screen* mainScreen = new Screen();
//    mainScreen->PlayGame();


        /*Buffer*/
        BITMAP* buffer = create_bitmap(640, 480);

        BITMAP* gameSprite = load_bitmap("images/gameSprite.bmp", NULL);
        BITMAP* splashSprite = load_bitmap("images/splash.bmp",NULL);

        /* Splash Screen Viewing */
        SplashScreen* splashScreen = new SplashScreen(splashSprite);
        splashScreen->Draw(buffer);
        draw_sprite(screen,buffer,0,0);
        speed_counter = 0;
        while (speed_counter<1500 || !key[KEY_SPACE])
        {
            speed_counter++;
            //cout<<speed_counter<<endl;
        }

        speed_counter = 0;
        delete splashScreen;
        clear_bitmap(buffer);
        /* Splash Screen End */

        /*Main Menu */
        int selection = 0;
        int keyDelay = 0;
//        MenuScreen* menuScreen = new MenuScreen(gameSprite);
//        while(!key[KEY_ENTER])
//        {
//            while(speed_counter>0)
//            {
//                if (keyDelay>10)
//                {
//
//                    if (key[KEY_UP])
//                        menuScreen->DecrementSelection();
//                    if (key[KEY_DOWN])
//                        menuScreen->IncrementSelection();
//
//                    keyDelay=0;
//                }
//                clear_bitmap(buffer);
//                menuScreen->Draw(buffer,false);
//                selection = menuScreen->GetSelection();
//                draw_sprite(screen,buffer,0,0);
//                speed_counter--;
//
//                keyDelay++;
//            }
//        }
//
//        if (selection==EXIT)
//            return 0;

        LinkedList* objects = new LinkedList(gameSprite);
        Player* player = new Player(gameSprite,300,300,objects);

        //Map* myMap;
        Point startPosition;
        //If continue, then load save.txt
//        if (selection == CONTINUE)
//        {
//            Map* myMap = new Map(gameSprite,"save.txt",objects);
//            player = myMap->GetPlayer();
//            player->SetWeapon(PISTOL);
//            startPosition = player->GetPosition();
//        }
//        else
//        {//only map1 for now.
//            Map* myMap = new Map(gameSprite,"maps/map1.txt",objects);
//            player = myMap->GetPlayer();
//            player->SetWeapon(PISTOL);
//            startPosition = player->GetPosition();
//            cout<<startPosition.x<<", "<<startPosition.y<<endl;
//        }
        Pistol* pistol = new Pistol(gameSprite,350,250);
        Brick* brick = new Brick(gameSprite,300,300,1);
        Gate* gate = new Gate(gameSprite, 350, 350);
        Flag* flag = new Flag(gameSprite,250,250);

        objects->Append(player);
        objects->Append(pistol);
        objects->Append(brick);
        objects->Append(gate);
        objects->Append(flag);

        /*Initializing Game Screen */
        GameScreen* gameScreen = new GameScreen(objects, player);
        /* Initializing Pause Screen */
        PauseScreen* pauseScreen = new PauseScreen(gameSprite);
        GameOverScreen* gameOverScreen = new GameOverScreen(gameSprite);
        bool pause = false;

        keyDelay = 0;

        Point p(SCREEN_W-36*5,SCREEN_H+36);
        //Word scoreWord;
        //scoreWord.Initialize(player->GetScore(), gameSprite,&p);
        /*Main Game Screen Loop */
        int lives = player->GetLives();
        while(!key[KEY_ESC])
        {
            if (key[KEY_P])
                pause = true;
            if (pause)
            {
                while (!key[KEY_ENTER])
                {
                    while (speed_counter>0){

                    if (keyDelay>20)
                    {
                        if (key[KEY_UP])
                            pauseScreen->DecrementSelection();
                        if (key[KEY_DOWN])
                            pauseScreen->IncrementSelection();
                        keyDelay=0;
                    }
                    else
                    {
                        clear_bitmap(buffer);
                        pauseScreen->Draw(buffer,false);
                        selection = pauseScreen->GetSelection();
                        draw_sprite(screen,buffer,0,0);
                        keyDelay++;
                        speed_counter--;
                    }
                }
                }
                if (selection==PCONTINUE)
                    pause = false;
                if (selection== PSAVE)
                    gameScreen->SaveGame();
                    pause = false;
                    cout<<"Game Saved"<<endl;
                if (selection == PEXIT)
                    break;
            }
            else
            {
                while (speed_counter > 0)
                {
                    gameScreen->PlayGame();
                    speed_counter--;
                }
            if (!player->Alive())
            {
                lives--;
                cout<<"Player died at "<<player->GetPosition().x<<", "<<player->GetPosition().y<<endl;
                if (lives<0)
                    {   keyDelay=0;
                        while (!key[KEY_ENTER])
                        {while(speed_counter>0){
                            if (keyDelay>20)
                            {
                                if (key[KEY_UP])
                                    gameOverScreen->DecrementSelection();
                                if (key[KEY_DOWN])
                                    gameOverScreen->IncrementSelection();
                                keyDelay=0;
                            }
                            else
                            {
                                clear_bitmap(buffer);
                                gameOverScreen->Draw(buffer,false);
                                selection = gameOverScreen->GetSelection();
                                draw_sprite(screen,buffer,0,0);
                                keyDelay++;
                                speed_counter--;
                            }
                        }
                        }
                        if (selection==CONTINUE)
                        {   lives=3;
                            player->SetPosition(startPosition);
                            player->SetAlive(true);
                            objects->Append(player); //player will not be at top of save file.
                            cout<<"Player set to" <<startPosition.x<<", "<<startPosition.y<<endl;

                        }
                        if (selection == EXIT)
                            break;
                    }
                else
                {
                    player->SetAlive(true);
                    player->SetPosition(startPosition);

                }
            }

            objects->Update();
            objects->Draw(buffer,false);
            //scoreWord.Draw(buffer,0,false);
            draw_sprite(screen, buffer, 0, 0);
            clear_bitmap(buffer);
            }


        }


        	//Cleaning Memory
	destroy_bitmap(buffer);
	destroy_bitmap(gameSprite);


	delete objects;
//	delete myMap;

    //player is deleted by saveMap
    //delete player;

	return 0;
	//Allegro will automatically deinitalize itself on exit

}
END_OF_MAIN();
