#pragma once
#include <allegro.h>

class SplashScreen
{
private:
    BITMAP* image;

public:
    SplashScreen (BITMAP* image)
    {
        this->image = image;
    }

    void Draw(BITMAP* buffer)
    {
        draw_sprite(buffer,image,0,0);
    }
};
