#pragma once
#include"Point.h"
#include"allegro.h"
#include <iostream>
#include "BoundingBox.h"

using namespace std;

class Object
{
protected:
    BITMAP* image;
    bool alive;
    int type;
    int frameWidth;
    int frameHeight;
    Point position;
    BoundingBox* box;
public:
    Object(){}
    Object(BITMAP* image, Point position)
    {
        this->frameWidth = 36;
        this->frameHeight = 36;
        this->alive = true;
        this->position = position;
        box = new BoundingBox(position.x-frameWidth/2,position.x+frameWidth/2,position.y-frameHeight/2,position.y+frameHeight/2);
    }
    Object(BITMAP* image, float x, float y)
    {
        this->frameWidth = 36;
        this->frameHeight = 36;
        this->alive = true;
        this->position.x = x;
        this->position.y = y;
        box = new BoundingBox(position.x-frameWidth/2,position.x+frameWidth/2,position.y-frameHeight/2,position.y+frameHeight/2);
    }

    bool Alive(){
        return alive;
    }

    void SetAlive(bool alive){
        this->alive = alive;
    }

    int GetType(){
        return type;
    }

    int GetFrameWidth(){
        return frameWidth;
    }

    int GetFrameHeight(){
        return frameHeight;
    }

    Point GetPosition(){
        return position;
    }
// Functions in other classes, needed by linked list.
    virtual void SetRightLeft(bool){}
    virtual bool GetRightLeft(){return false;}
    virtual void SetMovementCounter(int){}
    virtual void SetVely(float){}
    virtual float GetGravity(){return 0.0005;}
    virtual void SetState(int){}
    virtual void DecreaseLives(){}
    virtual void SetFlagTaken(bool,Object*){}
    virtual void SetTaken(bool){}
    virtual void SetWon(bool){}
    virtual void IncreaseLives(int){}
    virtual void SetWeapon(int){}

    virtual void Move(float,float) = 0;
    virtual void Draw(BITMAP*,bool) = 0;
    virtual void Update() = 0;
    virtual BoundingBox* GetBoundingBox(){
        return box;
    }
    virtual string GetSaveState() = 0;
};

