#include "Player.h"
#include <math.h>
#include <sstream>
Player::Player(BITMAP* image, Point position,LinkedList* linkedList) : Character(image, position)
{
    this->position = position;
    this->rightleft = false;
    this->speed = 1;
    this->image = create_sub_bitmap(image,0,0,frameWidth*12,frameHeight*2);
    this->weapon = NONE;
    this->linkedList = linkedList;
    this->type = 20;
    this->vely = 0;
    this->lives = 3;
    this->score = 10;
    flag= NULL;
}

Player::Player(BITMAP* image, float x, float y,LinkedList* linkedList): Character(image,x,y)
{
    this->rightleft = false;
    this->speed = 1;
    this->image = create_sub_bitmap(image,0,0,frameWidth*12,frameHeight*2);
    this->weapon = NONE;
    this->linkedList = linkedList;
    this->type = 20;
    this->vely = 0;
    this->lives = 3;
    this->score = 10;
    flag=NULL;
}

Player::~Player()
{
    std::cout<<"Player destroyed.."<<std::endl;
    delete box;
}

void Player::SetPosition(Point position)
{
    this->position = position;
}

void Player::SetPosition(float x, float y)
{
    this->position.x = x;
    this->position.y = y;
}

void Player::SetState(int state)
{
        this->state = state;
}

int Player::GetState()
{
    return state;
}

void Player::SetWeapon(int weapon)
{
    if (weapon<FLAMETHROWER)
        this->weapon = weapon;
}

int Player::GetWeapon()
{
    return weapon;
}

void Player::SetSpeed(int speed)
{
    this->speed = speed;
}

int Player::GetSpeed()
{
    return speed;
}

void Player::SetLives(int lives)
{
    this->lives = lives;
}
int Player::GetLives()
{
    return lives;
}
void Player::DecreaseLives()
{
    this->lives--;
    if (this->lives<=0)
        this->alive = false;
}
void Player::SetVely(float vely)
{
    this->vely = vely;
}
float Player::GetVely()
{
    return vely;
}

void Player::Draw(BITMAP* buffer,bool debug){
    switch(state){
    case STAND:
        if (!rightleft)
            masked_blit(image, buffer, 0,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
        else
            masked_blit(image, buffer, 0,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
        box->Draw(buffer,debug);
        break;
    case WALK:
        if (frameCounter<60){
            if (!rightleft)
                masked_blit(image, buffer, 36*3,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            else
                masked_blit(image, buffer, 36*3,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
            break;
        }
        else if (frameCounter>=60 && frameCounter<120){
            if (!rightleft)
                masked_blit(image, buffer, 36*4,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            else
                masked_blit(image, buffer, 36*4,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
            break;
        }
        else if (frameCounter>=120 && frameCounter<180){
            if (!rightleft)
                masked_blit(image, buffer, 36*5,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            else
                masked_blit(image, buffer, 36*5,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
            break;
        }
        else if (frameCounter>=180 && frameCounter<240){
            if (!rightleft)
                masked_blit(image, buffer, 36*6,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            else
                masked_blit(image, buffer, 36*6,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
            break;
        }
        else if (frameCounter>=240 && frameCounter<300){
            if (!rightleft)
                masked_blit(image, buffer, 36*7,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            else
                masked_blit(image, buffer, 36*7,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
            break;
        }
        state = STAND;
        frameCounter=0;
        break;
    case FIRE:
        {
            if (frameCounter<=180){
                if (!rightleft)
                    masked_blit(image, buffer, 36,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
                else
                    masked_blit(image, buffer, 36,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);

                box->Draw(buffer,debug);
                frameCounter++;
                break;
            }
        }
        frameCounter=0;
        break;
    case JUMP:
        if (!rightleft)
            masked_blit(image, buffer, 36*2,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
        else
            masked_blit(image, buffer, 36*2,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
        box->Draw(buffer,debug);
        break;
    case DEAD:
        {
            if (frameCounter<=300)
            {
                if (!rightleft)
                    masked_blit(image, buffer, 36*8,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
                else
                    masked_blit(image, buffer, 36*8,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);

                box->Draw(buffer,debug);
                frameCounter++;
                break;
            }
            else if (frameCounter>300 and frameCounter<=600)
            {
                if (!rightleft)
                    masked_blit(image, buffer, 36*9,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
                else
                    masked_blit(image, buffer, 36*9,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);

                box->Draw(buffer,debug);
                frameCounter++;
                break;
            }
            else if (frameCounter>600 and frameCounter<=900)
            {
                if (!rightleft)
                    masked_blit(image, buffer, 36*10,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
                else
                    masked_blit(image, buffer, 36*10,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);

                box->Draw(buffer,debug);
                frameCounter++;
                break;
            }
            frameCounter=0;
            //play_sample  wasted
            alive = false;
            break;
            }
//            switch (weapon){
//                case PISTOL:
//                    std::cout<<"Firing"<<std::endl;
//              }
        }
}

void Player::Move(float x, float y){
    position.x += x;
    position.y += y;
    if (flag!=NULL)
    {
        flag->Move(x,y);
    }
    if (position.y-frameHeight/2 >= SCREEN_H)
        position.y = 0-frameHeight/2;
    box->Update(position.x-frameWidth/4,position.x+frameWidth/4,position.y-frameHeight/2,position.y+frameHeight/4);
}


void Player::Fire(){
    if (weapon!=NONE)
    {
        state=FIRE;
        if (!rightleft)
        {
            Bullet* bullet = new Bullet(create_sub_bitmap(image,36*11,0,36,36),this->position.x+16,position.y-4,rightleft);
            linkedList->Append(bullet);
        }
        else
        {
            Bullet* bullet = new Bullet(create_sub_bitmap(image,36*11,0,36,36),this->position.x-16,position.y-4,rightleft);
            linkedList->Append(bullet);
        }
    }
}
void Player::Update()
{
    this->Move(0,gravity*0.04);
    this->Move(0,vely);
    vely=vely*0.90;
}
string Player::GetSaveState()
{
        ostringstream out;
        out<<this->type<<endl;
        out<<this->position.x<<endl;
        out<<this->position.y<<endl;
        out<<state<<endl;
        out<<weapon<<endl;
        out<<rightleft<<endl;
        out<<speed<<endl;
        out<<lives<<endl;
        out<<gravity<<endl;
        out<<score<<endl;
        out<<"End\n";
        return out.str();
}
//Object* Player::Fire();

