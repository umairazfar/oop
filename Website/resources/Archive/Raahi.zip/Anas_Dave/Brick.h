#pragma once
#include <allegro.h>
#include "Object.h"
#include "Point.h"
#include <sstream>
//#include "BoundingBox.h"
enum {SINGLE, LEFT, RIGHT, MIDDLE};
class Brick : public Object {
protected:

private:
    int slr;  //Will store if brick is single, right or left
public:
    Brick(BITMAP* image, Point position, int slr) : Object(image, position)
    {
        this->image = create_sub_bitmap(image,4*36,9*36,frameWidth*6,frameHeight);
        this->slr = slr;
        this->type = 1;
    }
    Brick(BITMAP* image, float x, float y, int slr) : Object(image, x,y)
    {
        this->image = create_sub_bitmap(image,4*36,9*36,frameWidth*6,frameHeight);
        this->slr = slr;
        this->type = 1;
    }

    int GetSLR()
    {
        return slr;
    }
    void Draw(BITMAP* buffer, bool debug){
        switch(slr){
        case SINGLE:
            masked_blit(image, buffer, 0,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth/2,frameHeight);
            masked_blit(image, buffer, 36*2.5,0,position.x,position.y-frameHeight/2,frameWidth/2,frameHeight);
            box->Draw(buffer, debug);
            break;
        case LEFT:
            masked_blit(image, buffer, 0,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            break;
        case RIGHT:
            masked_blit(image, buffer, 36*2,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            break;
        case MIDDLE:
            masked_blit(image, buffer, 36,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            break;
        }
    }
    void Move(float x, float y){
        position.x += x;
        position.y += y;
        box->Update(position.x-frameWidth/2,position.x+frameWidth/2,position.y-frameHeight/2,position.y+frameHeight/2);
    }
    void Update(){
        box->Update(position.x-frameWidth/2,position.x+frameWidth/2,position.y-frameHeight/2,position.y+frameHeight/2);
    }

    string GetSaveState(){
        ostringstream out;
        out<< this->type<<"\n";
        out<<this->position.x<<endl;
        out<<this->position.y<<endl;
        out<<this->slr<<endl;
        out<<"End\n";
        return out.str();
    }
};


