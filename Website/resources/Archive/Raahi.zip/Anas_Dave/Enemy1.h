#pragma once
#include"Point.h"
#include"allegro.h"
#include <iostream>
#include "Player.h"

using namespace std;
/* Enemy1 is the enemy which moves back and forth and fires a bullet in a straight line if it sees a player.
*/
class Enemy1 : public Player
{
protected:
    int xLimit;
    int movementCounter;
    unsigned long int moveFrameCounter;
    Player* target;
    int fireCounter;
public:
    Enemy1(BITMAP*, Point, LinkedList*, Player*);
    Enemy1(BITMAP*, float, float,LinkedList*, Player*);
    ~Enemy1(){cout<<"Enemy1 destroyed"<<endl;}
    void SetMovementCounter(int);
    void Draw(BITMAP*,bool);
    void Move(float,float);
    void Update();
    void Fire();
    void Walk();
    string GetSaveState();
};

