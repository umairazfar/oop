#pragma once
#include "Player.h"
#include <sstream>

class Bullet:public Character{
private:
    long int deathCounter;
protected:

public:
    Bullet(BITMAP* image, float x, float y, bool rightleft) : Character (image,x,y)
    {
        this->image = image;
        this->rightleft = rightleft;
        this->type = 30;
        deathCounter = 0;
        //Bullet Bounding Boxes will be smaller than others.
        box = new BoundingBox(position.x-frameWidth/6,position.x+frameWidth/6,position.y-frameHeight/6,position.y+frameHeight/6);
    }
    Bullet(BITMAP* image, Point position, bool rightleft) : Character (image,position)
    {
        this->image = image;
        this->rightleft = rightleft;
        this->type = 30;
        deathCounter = 0;
        box = new BoundingBox(position.x-frameWidth/6,position.x+frameWidth/6,position.y-frameHeight/6,position.y+frameHeight/6);
    }
    ~Bullet(){}

    void Move(float x, float y)
    {
        this->position.x +=x;
        this->position.y+=y;
        box->Update(position.x-frameWidth/6,position.x+frameWidth/6,position.y-frameHeight/6,position.y+frameHeight/6);
    }
    void Update()
    {
        if (!rightleft)
        {
            Move(0.5,0);
        }
        else
            Move(-0.5,0);
        if (deathCounter> 5000)
            alive = false;
        else
            deathCounter++;
    }
    void Draw(BITMAP* buffer, bool debug)
    {
        masked_blit(image, buffer, 0,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
        box->Draw(buffer,debug);
    }

    string GetSaveState()
    {
        ostringstream out;
        out<< this->type<<endl;
        out<<this->position.x<<endl;
        out<<this->position.y<<endl;
        out<<rightleft<<endl;
        out<<"End\n";
        return out.str();
    }
};
