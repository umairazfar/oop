#pragma once
#include <allegro.h>
#include <iostream>
#include "Point.h"
#include "Character.h"
#include "Bullet.h"
#include "Object.h"
#include "LinkedList.h"

enum {STAND, WALK, JUMP,FIRE, DEAD};
enum {NONE, PISTOL, MACHINEGUN, GRENADE, ROCKETLAUNCHER, FLAMETHROWER};

class Player : public Character{
protected:
    int state;
    int weapon;
    int speed;
    long int frameCounter;
    LinkedList* linkedList;
    int lives;
    float vely;
    int score;
    bool flagTaken;
    Object* flag;
    bool won;
public:
    Player();
    Player(BITMAP*, Point,LinkedList*);
    Player(BITMAP*, float, float,LinkedList*);
    ~Player();
    //Position Functions
    void SetPosition(Point);
    void SetPosition(float,float);
    //State Functions
    void SetState(int);
    int GetState();
    //Weapon Functions
    void SetWeapon(int);
    int GetWeapon();
    //Speed Functions
    void SetSpeed(int);
    int GetSpeed();
    //Lives Functions
    void SetLives(int);
    void IncreaseLives(int lives){
        this->lives+=lives;
        }
    void DecreaseLives();
    int GetLives();
    //vely Functions
    void SetVely(float);
    float GetVely();
    //score functions
    void SetScore(int score)
    {
        this->score = score;
    }
    void InscreaseScore(int score)
    {
        this->score += score;
    }
    int GetScore()
    {
        return score;
    }
    bool GetFlagTaken(){
        return flagTaken;
    }
    void SetWon(bool won){
        this->won=won;
    }
    bool GetWon(){
        return won;
    }
    void SetFlagTaken(bool flagTaken, Object* flag){
        this->flagTaken = flagTaken;
        this->flag = flag;
    }
    //Object Inherited Functions
    virtual void Draw(BITMAP*,bool);
    virtual void Move(float,float);
    virtual void Update();
    //Special function for Player and Enemy
    virtual void Fire();
    string GetSaveState();

};
