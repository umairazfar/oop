//#pragma once
//#include <allegro.h>
//#include <iostream>
//#include "Point.h"
//
//class Car{
//protected:
//    int health;
//    int armour;
//    bool getOutJail;
//    Point position;
//    BITMAP* image;
//    int state;
//    int weapon;
//    int frameWidth  = 60;
//    int frameHeight = 70;
//    float angle;
//    bool car;
//    long int frameCounter=0;
//
//public:
//    Player();
//    Player(BITMAP*, Point);
//    Player(BITMAP*, int, int);
//
//    ~Player();
//
//    void SetHealth(int);
//    int GetHealth();
//    void SetArmour(int);
//    int GetArmour();
//    void SetJail(bool);
//    bool GetJail();
//    void SetPosition(Point);
//    void SetPosition(int, int);
//    Point GetPosition();
//    int GetX();
//    int GetY();
//    void SetState(int);
//    int GetState();
//    void SetWeapon(int);
//    int GetWeapon();
//    bool GetCar();
//    void SetCar(bool);
//    void ChangeAngle(float);
//    float GetAngle(float);
//    virtual void Draw(BITMAP*);
//    virtual void Move(float);
//    virtual void Move(int);
//
//    //virtual Object* Fire();
//
//
//};
