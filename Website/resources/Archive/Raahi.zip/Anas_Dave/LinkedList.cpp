#include <iostream>
#include <fstream>
#include "LinkedList.h"
//Implements non-circular, doubly linked list with FIFO property.. The tail grows.
#include"Object.h"
#include "Fire.h"
#include "Player.h"

LinkedList::LinkedList(BITMAP* image)
{
    head = NULL;
    tail = NULL;
    length = 0;
    collisionLeft = false;
    collisionRight = false;
    this->image = image;
}

LinkedList::~LinkedList()
{
    Node* temp;
    while(head != NULL)
    {
        temp = head;
        head = head->next;
        delete temp;
    }
}

void LinkedList::Append(Object* object)
{/* To ensure the most recent item is drawn last,
    items are inserted at the end.
    */
    //Case list is brand new
    if (head == NULL){
        head = new Node;
        head->object = object;
        head->next = NULL;
        head->prev = NULL;
        tail = head;
    }
    //General case
    else {
        Node* temp = new Node;
        temp->object = object;
        temp->next = NULL;
        temp->prev = tail;
        tail->next = temp;
        tail = temp;
        }
    length++;
}

int LinkedList::Length()
{
    return length;
}

Node* LinkedList::GetHead()
{
    return head;
}

void LinkedList::Draw(BITMAP* buffer,bool debug)
{
    Node* temp = head;
    while(temp!=NULL)
    {
        temp->object->Draw(buffer,debug);
        temp = temp->next;
    }
}

void LinkedList::Clean(){
    Node* temp = head;
    while(temp != NULL)
    {
        if(temp == head)
        {
            if(temp->object != NULL)
            {
                if(temp->object->Alive() == false)
                {
                    head = head->next;
                    if(head!=NULL)
                    {
                        head->prev = NULL;
                    }
                    delete temp;
                    temp = head;
                }
                else
                {
                    temp = temp->next;
                }
            }
            else
            {
                break;
            }
        }
        else if(temp == tail)
        {
            if(temp->object!=NULL)
            {
                if(temp->object->Alive() == false)
                {
                    tail = tail->prev;
                    tail->next = NULL;
                    delete temp;
                    temp = NULL;
                }
                else
                {
                    temp = temp->next;
                }
            }
        }
        else
        {
            if(temp->object->Alive() == false)
            {
                Node* keeper = temp;
                temp->prev->next = temp->next;
                temp->next->prev = temp->prev;
                temp = temp->next;
                delete keeper;
            }
            else
            {
                temp = temp->next;
            }
        }
    }
}

void LinkedList::MoveObjectsRight(float x)
{
    if (collisionLeft)
        return;

    Node* temp = head;
    while(temp!=NULL)
    {
        if (temp->object->GetType()!=20)
            temp->object->Move(x,0);
        temp = temp->next;
    }
}

void LinkedList::MoveObjectsLeft(float x)
{
    if (collisionRight)
        return;

    Node* temp = head;
    while(temp!=NULL)
    {
        if (temp->object->GetType()!=20)
            temp->object->Move(-x,0);
        temp = temp->next;
    }
}

bool isColliding(BoundingBox* box1, BoundingBox* box2)
{   //Box is within y range AND box is within x range.
        //y range in two conditions, x range in two conditions
    if (box1->bottom < box2->top)
        return false;
    if (box1->top > box2->bottom)
        return false;
    if (box1->right < box2->left)
        return false;
    if (box1->left > box2->right)
        return false;
    return true;
}
void LinkedList::CheckCollision(Object* object1, Object* object2)
{
    if(object1 == NULL || object2 == NULL)
        return;
    if (object1 == object2)
        return;
    //If Collision with enemy and static objects,
    if (object1->Alive() and object2->Alive())
    {
        BoundingBox* box1 = object1->GetBoundingBox();
        BoundingBox* box2 = object2->GetBoundingBox();

        if (isColliding(box1,box2))
        {
            //cout<<"Object1: "<<object1->GetType()<<endl;
            //cout<<"Object2: "<<object2->GetType()<<endl;
            if ((object1->GetType()==10) and (object2->GetType()>0 and object2->GetType()<4))
            {//Enemy must change directions
                object1->SetRightLeft(!object1->GetRightLeft());
                object1->SetMovementCounter(0);
            }
            if ((object1->GetType()==10) and (object2->GetType()==30))
            {
                object1->SetAlive(false);  //Maybe Death Animation like player
            }
        //Enemy player bullet
         /*TO IMPLEMENT*/


        //Collision between player
            //Brick
            if ((object1->GetType()==20) and (object2->GetType()==1))
            {       //cout<<"Collision with brick"<<endl;
                    //Collision with player's top and brick's bottom
                    if((box1->top <= box2->bottom) and box1->bottom >= box2->bottom and (box1->right >= box2->left) and box1->right <=box2->right)
                    {   //Player should stop moving up.
                        //cout<<"Player collided with brick at top"<<endl;
                        object1->SetVely(0);
                    }
                    if(box1->bottom >= box2->top)
                    { //player is on top of a brick
                        //Move player object back up (because gravity is implemented)
                        //cout<<"collision with top of brick"<<endl;
                        object1->Move(0,-object1->GetGravity()*0.04);
                    }
                    if(box1->right >= box2->left and box1->top <= box2->top and box1->bottom >= box2->top)
                    { //player is on the right of brick
                        //cout<<"Collision Right"<<endl;
                        collisionRight = true;
                    }
                    else
                        collisionRight = false;
                    if(box1->left <= box2->right and box1->top <= box2->top and box1->bottom >= box2->top)
                    { //player is on the left of brick
                    //    cout<<"Collision Left"<<endl;
                        collisionLeft = true;
                    }
                    else
                        collisionLeft = false;
            }

            if ((object1->GetType() == 20) and (object2->GetType()==2))
            {   //player collides with plant
                BoundingBox* box1 = object1->GetBoundingBox();
                BoundingBox* box2 = object2->GetBoundingBox();
                    //either player collides with right or left and player is in y range of tree
                if (((box1->right >= box2->left) or (box1->left <= box2->right))
                    and
                    ((box1->bottom >= box2->top) or (box1->top <= box2->bottom))
                    )
                {
                    //play_sample
                    object1->SetState(DEAD);
                }
            }
            if ((object1->GetType() == 20) and (object2->GetType()==3))
            {   //player collides with fire
                    //either player collides with right or left and player is in y range of fire
                if (((box1->right >= box2->left) or (box1->left <= box2->right))
                    and
                    ((box1->bottom >= box2->top) or (box1->top <= box2->bottom))
                    )
                {
                    object1->SetAlive(false);
                    Fire* fire = new Fire(image,object1->GetPosition(),true);
                    //play_sample
                    Append(fire);
                }
            }
            //Player and EnemyBullet Implementation comes here
            if ((object1->GetType() == 20) and (object2->GetType()==30))
            {
               //player collides with Enemy
                    //either player collides with right or left and player is in y range of tree
                if (((box1->right >= box2->left) or (box1->left <= box2->right))
                    and
                    ((box1->bottom >= box2->top) or (box1->top <= box2->bottom))
                    )
                {
                    object1->SetState(DEAD);
                }
            }
            if ((object1->GetType() == 20) and (object2->GetType()==6))
            {    //Player Flag
                object1->SetFlagTaken(true,object2);
                object2->SetTaken(true);
            }
            if ((object1->GetType() == 20) and (object2->GetType()==7))
            {    //Player Door
                object1->SetWon(true);
            }
            if ((object1->GetType() == 20) and (object2->GetType()==4))
            {    //Player PowerUP Life
                object1->IncreaseLives(1);
                object2->SetAlive(false);
            }
            if ((object1->GetType() == 20) and (object2->GetType()==5))
            {    //Player PowerUP Gun
                object1->SetWeapon(PISTOL);
                object2->SetAlive(false);
            }

            if ((object1->GetType() == 20) and (object2->GetType()==10))
            {
               //player collides with Enemy
                    //either player collides with right or left and player is in y range of tree
                if (((box1->right >= box2->left) or (box1->left <= box2->right))
                    and
                    ((box1->bottom >= box2->top) or (box1->top <= box2->bottom))
                    )
                {
                    object1->SetState(DEAD);
                }
            }
        }
    }
    return;
}
void LinkedList::Update(){
/*Logically updates the whole class. Also checks for collision */

    Node* temp = head;
    while (temp!=NULL)
    {
        temp->object->Update();
        temp=temp->next;
    }
    //Check Collisions
    Node* firstNode = head;
    while(firstNode!=NULL)
    {
        //cout<<"First Node"<<endl;
        Node* secondNode = head;
        while(secondNode!=NULL)
        {
            CheckCollision(firstNode->object, secondNode->object);
            secondNode = secondNode->next;
        }
        firstNode = firstNode->next;
    }
    Clean();
    //View();
}


void LinkedList::Save(ofstream& file){
/*Writes the contents of the linked list primitives on input File*/
    //Ensuring player is always saved first
    Node* temp = head;
//    while (temp!=NULL)
//    {
//        if (temp->object->GetType()==20)
//            file<<temp->object->GetSaveState();
//        temp=temp->next;
//    }
//

    temp = head;
    while (temp!=NULL)
    {
        if (temp->object->GetType()!=20)
        {
            cout<<temp->object->GetSaveState();
            file<<temp->object->GetSaveState();
            temp=temp->next;
        }
    }
}

