#pragma once
#include <allegro.h>
#include <string>
#include <fstream>
#include "LinkedList.h"
#include "Player.h"
#include "Brick.h"
#include "Plant.h"
#include "Enemy1.h"
#include "Fire.h"

using namespace std;
class Map{

private:
    Player* player;
    //ifstream inFile;

protected:

public:

    Map(BITMAP*,string,LinkedList*);
    ~Map();
    Player* GetPlayer(){
        return player;
    }
    void Draw(BITMAP*);
    //bool checkCollision(Object*);
   // bool isRoad();
};
