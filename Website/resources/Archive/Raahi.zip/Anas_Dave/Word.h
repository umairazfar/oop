#pragma once
#include"allegro.h"
#include"Point.h"
#include"Letter.h"
#include<string>
#include "Number.h"
class Word
{
private:
    Point position;
    Letter* character;
    Number* number;
    int length;
    int startx;
    int frame_width;
    int counter;
    int toDisplay;
public:
    Word();
    Word(std::string text, BITMAP* font_image, Point* position);
    void Initialize(std::string text, BITMAP* font_image, Point* position);
    void Initialize(int num,BITMAP* font_image,Point* position);
    ~Word();
    //void Initialize(std::string text, BITMAP* font_image, Point* position);
    void Draw(BITMAP* buffer, int animation, bool debug);
    void SetPosition(Point* position);
    int GetStringLength();
};

