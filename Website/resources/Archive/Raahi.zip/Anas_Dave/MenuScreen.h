#pragma once
#include "Word.h"
#include <string>
#include "Button.h"
#include "Point.h"
#include <cstdlib>

using namespace std;
enum {CONTINUE, NEWGAME,EXIT};
class MenuScreen
{
protected:
    int selection;
    BITMAP* image;
    Word continueWord;
    Word newGameWord;
    Word exitWord;
    Button continueButton;
    Button newGameButton;
    Button exitButton;
public:
    MenuScreen(BITMAP* image)
    {
        this->image = create_sub_bitmap(image,0,36*10,36*12,36*4);
        Point p1(SCREEN_W/2,SCREEN_H/3-50);
        Point p2(SCREEN_W/2,SCREEN_H*2/3-50);
        Point p3(SCREEN_W/2,SCREEN_H-50);
        continueWord.Initialize("continue",this->image,&p1);
        newGameWord.Initialize("new",this->image,&p2);
        exitWord.Initialize("exit",this->image,&p3);
        continueButton.Initialize("continue",this->image,&p1);
        newGameButton.Initialize("new",this->image,&p2);
        exitButton.Initialize("exit",this->image,&p3);
    }

    void IncrementSelection(){
        selection=(selection+1)%3;
    }
    void DecrementSelection(){
        selection = abs(selection-1)%3;
    }

    int GetSelection(){
        return selection;
    }

    void Draw(BITMAP* buffer,bool debug)
    {
        if (selection==CONTINUE)
        {
            continueButton.Draw(buffer,0,debug);
            newGameWord.Draw(buffer,0,debug);
            exitWord.Draw(buffer,0,debug);
        }
        else if (selection==NEWGAME)
        {
            continueWord.Draw(buffer,0,debug);
            newGameButton.Draw(buffer,0,debug);
            exitWord.Draw(buffer,0,debug);
        }
        else
        {
            continueWord.Draw(buffer,0,debug);
            newGameWord.Draw(buffer,0,debug);
            exitButton.Draw(buffer,0,debug);
        }
    }
};
