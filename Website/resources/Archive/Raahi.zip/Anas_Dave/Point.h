#pragma once

struct Point {
    float x;
    float y;

    Point (int x, int y)
    {
        this->x = x;
        this->y = y;
    }
    Point()
    {
    }
};
