#pragma once
#include <allegro.h>
#include "Object.h"
#include "Point.h"
//#include "BoundingBox.h"

class Gate : public Object {
protected:

private:

public:
    Gate(BITMAP* image, Point position) : Object(image,position)
    {
        this->image = create_sub_bitmap(image,11*36,13*36,frameWidth,frameHeight);
        this->type= 7;

    }
    Gate(BITMAP* image, float x, float y) : Object(image, x, y)
    {
        this->image = create_sub_bitmap(image,11*36,13*36,frameWidth,frameHeight);
        this->type= 7;
    }

    void Draw(BITMAP* buffer, bool debug){
        //Have to implement animation.
        masked_blit(image, buffer, 0,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
        masked_blit(image,buffer,0,0,position.x-frameWidth/2,position.y+frameWidth/2,frameWidth,frameHeight);
        box->Draw(buffer, debug);
    }
    void Move(float x, float y)
    {
        position.x += x;
        position.y += y;
        box->Update(position.x-frameWidth/2,position.x+frameWidth/2,position.y-frameHeight/2,position.y+3*frameHeight/2);
    }
    void Update(){
        box->Update(position.x-frameWidth/4,position.x+frameWidth/4,position.y-frameHeight/2,position.y+3*frameHeight/2);
    }
    string GetSaveState()
    {
        ostringstream out;
        out<< this->type<<"\n";
        out<<this->position.x<<endl;
        out<<this->position.y<<endl;
        out<<"End\n";
        return out.str();
    }

};



