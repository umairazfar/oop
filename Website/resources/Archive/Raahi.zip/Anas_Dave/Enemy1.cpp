#include "Enemy1.h"
#include <math.h>
#include "Player.h"
#include <sstream>
#include "Bullet.h"

Enemy1::Enemy1(BITMAP* image, Point position,LinkedList* linkedList,Player* target) : Player::Player(image, position,linkedList)
{
    health = 30;
    xLimit = 100;
    movementCounter = 0;
    moveFrameCounter = 0;
    fireCounter = 0;
    this->image = create_sub_bitmap(image,0,36*2,frameWidth*12,frameHeight*2);
    this->target = target;
    this->type = 10;
}

Enemy1::Enemy1(BITMAP* image, float x, float y,LinkedList* linkedList, Player* target) : Player::Player(image, x, y,linkedList)
{
    health = 30;
    xLimit = 100;
    fireCounter=0;
    movementCounter= 0;
    moveFrameCounter = 0;
    this->image = create_sub_bitmap(image,0,36*2,frameWidth*12,frameHeight*2);
    this->target = target;
    this->type = 10;
}

void Enemy1::SetMovementCounter(int movementCounter)
{
    this->movementCounter = movementCounter;
}

void Enemy1::Draw(BITMAP* buffer,bool debug){
    switch(state){
    case STAND:
        if (!rightleft)
            masked_blit(image, buffer, 0,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
        else
            masked_blit(image, buffer, 0,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
        box->Draw(buffer,debug);
        break;
    case WALK:
        if (frameCounter<60){
            if (!rightleft)
                masked_blit(image, buffer, 36*3,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            else
                masked_blit(image, buffer, 36*3,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
            break;
        }
        else if (frameCounter>=60 && frameCounter<120){
            if (!rightleft)
                masked_blit(image, buffer, 36*4,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            else
                masked_blit(image, buffer, 36*4,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
            break;
        }
        else if (frameCounter>=120 && frameCounter<180){
            if (!rightleft)
                masked_blit(image, buffer, 36*5,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            else
                masked_blit(image, buffer, 36*5,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
            break;
        }
        else if (frameCounter>=180 && frameCounter<240){
            if (!rightleft)
                masked_blit(image, buffer, 36*6,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            else
                masked_blit(image, buffer, 36*6,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
            break;
        }
        else if (frameCounter>=240 && frameCounter<300){
            if (!rightleft)
                masked_blit(image, buffer, 36*7,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            else
                masked_blit(image, buffer, 36*7,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
            break;
        }
        state = STAND;
        frameCounter=0;
        break;
    case FIRE:
        if (frameCounter<=180){
            if (!rightleft)
                masked_blit(image, buffer, 36,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            else
                masked_blit(image, buffer, 36,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);

            box->Draw(buffer,debug);
            frameCounter++;
            break;
        }
        frameCounter=0;
        break;
    case JUMP:
        if (!rightleft)
            masked_blit(image, buffer, 36*2,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
        else
            masked_blit(image, buffer, 36*2,36,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
        box->Draw(buffer,debug);
        break;


//            switch (weapon){
//                case PISTOL:
//                    std::cout<<"Firing"<<std::endl;
//              }
        }
}

void Enemy1::Move(float x, float y){
    position.x += x;
    position.y += y;
    box->Update(position.x-frameWidth/4,position.x+frameWidth/4,position.y-frameHeight/2,position.y+frameHeight/4);
}

void Enemy1::Update(){

    //Enemy fires when target is close to 200 pixels
    if (((sqrt((target->GetPosition().x - this->position.x)*(target->GetPosition().x - this->position.x)) <= 25.0)
         or (sqrt((target->GetPosition().y - this->position.y)*(target->GetPosition().y - this->position.y)) <= 25.0)
         )
        and (((this->rightleft) and  (target->GetPosition().x < this->position.x))
             or (!(this->rightleft) and (target->GetPosition().x > this->position.x))
            )
        )
        {
            if (fireCounter>300)
            {
                this->Fire();
                fireCounter = 0;
            }
            else{
                fireCounter++;
            }
        }
    else
        {
        this->Walk();
        }
        //for when collisions between enemy and botton brick detected
    //this->Move(0,gravity);
}

void Enemy1::Fire(){
    //this->Fire()
    this->SetState(FIRE);
    if (!rightleft)
    {
        Bullet* bullet = new Bullet(create_sub_bitmap(image,36*11,0,36,36),position.x+20,position.y,rightleft);
        linkedList->Append(bullet);
    }
    else
    {
        Bullet* bullet = new Bullet(create_sub_bitmap(image,36*11,0,36,36),position.x-20,position.y,rightleft);
        linkedList->Append(bullet);
    }
    //cout<<"Firing"<<endl;
}
void Enemy1::Walk(){
    if (!rightleft){
        if (moveFrameCounter %10 ==0){  //Controls when to move.
            if (movementCounter <= xLimit){
                this->Move(this->GetSpeed(),0);
                this->SetState(WALK);
                movementCounter++;
            }
            else{
                movementCounter = 0;
                this->SetState(STAND);
                rightleft = !rightleft;
            }
        }
    }
    else {
        if (moveFrameCounter %10 ==0){
            if (movementCounter <= xLimit){
                this->Move(-this->GetSpeed(),0);
                this->SetState(WALK);
                movementCounter++;
            }
            else{
                movementCounter = 0;
                rightleft = !rightleft;
                this->SetState(STAND);
            }
        }
    }
    moveFrameCounter ++;

}
//Object* Enemy1::Fire();
string Enemy1::GetSaveState()
{
    ostringstream out;
    out<<this->type<<endl;
    out<<this->position.x<<endl;
    out<<this->position.y<<endl;
        //xLimit is automatically set to 100 in constructor
    //out<<xLimit<<endl;
    out<<"End\n";
    return out.str();
}
