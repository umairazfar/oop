#pragma once
#include"allegro.h"
#include"Point.h"
#include"Word.h"
#include<string>
#include <iostream>

class Button
{

private:
    Point position;
    Word* word;
    BITMAP* image;
public:
    Button(){}
    ~Button();
    Button(std::string text, BITMAP* font_image, Point* position);
    void Initialize(std::string text, BITMAP* font_image, Point* position);
    void Draw(BITMAP* buffer, int animation, bool debug);
    void SetPosition(Point* position);
};
