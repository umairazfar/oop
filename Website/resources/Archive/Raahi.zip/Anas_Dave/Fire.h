#pragma once
#include <allegro.h>
#include "Object.h"
#include "Point.h"
#include <sstream>
//#include "BoundingBox.h"

class Fire : public Object {
protected:

private:
    long int frameCounter;
    long int deathCounter;
    bool temp;
public:
    Fire(BITMAP* image, Point position) : Object(image, position)
    {
        this->image = create_sub_bitmap(image,0*36,9*36,frameWidth*4,frameHeight);
        this->type=3;
        frameCounter = 0;
        temp = false;
    }
    Fire(BITMAP* image, Point position,bool temp) : Object(image, position)
    {
        this->image = create_sub_bitmap(image,0*36,9*36,frameWidth*4,frameHeight);
        this->type=3;
        frameCounter = 0;
        this->temp = temp;
        deathCounter = 0;
    }
    Fire(BITMAP* image, float x, float y) : Object(image, x, y)
    {
        this->image = create_sub_bitmap(image,0*36,9*36,frameWidth*4,frameHeight);
        this->type=3;
        frameCounter = 0;
        temp = false;
    }
    void Draw(BITMAP* buffer, bool debug)
    {
        if (frameCounter<60)
        {
            masked_blit(image, buffer, 0,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
        }
        else if (frameCounter>=60 && frameCounter<120)
        {
            masked_blit(image, buffer, 36,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
        }
        else if (frameCounter>=120 && frameCounter<180)
        {
            masked_blit(image, buffer, 36*2,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
        }
        else if (frameCounter>=180 && frameCounter<240)
        {
            masked_blit(image, buffer, 36*3,0,position.x-frameWidth/2,position.y-frameHeight/2,frameWidth,frameHeight);
            box->Draw(buffer,debug);
            frameCounter++;
        }
        else
        {
            frameCounter = 0;
        }

    }
    void Move(float x, float y)
    {
        position.x += x;
        position.y += y;
        box->Update(position.x-frameWidth/2,position.x+frameWidth/2,position.y-frameHeight/2,position.y+frameHeight/2);
    }
    void Update()
    {
        box->Update(position.x-frameWidth/2,position.x+frameWidth/2,position.y-frameHeight/2,position.y+frameHeight/2);
        deathCounter++;
        if (temp)
        {
            if (deathCounter>=1000)
                this->alive = false;
        }
    }
    string GetSaveState()
    {
        ostringstream out;
        out<< this->type<<endl;
        out<<this->position.x<<endl;
        out<<this->position.y<<endl;
        out<<"End\n";
        return out.str();
    }
};




