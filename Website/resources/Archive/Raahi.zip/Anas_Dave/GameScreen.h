#pragma once
#include <allegro.h>
#include "Score.h"
class GameScreen {
private:
//    volatile long speed_counter = 0; // A long integer which will store the value of the speed counter.
//    volatile long objectCounter = 0;
    int spaceDelay;
    int jumpDelay;
    LinkedList* objects;
    Player* player;
protected:
public:
    GameScreen (LinkedList* objects, Player* player)
    {
        jumpDelay = 0;
        spaceDelay = 0;
        this->objects = objects;
        this->player = player;
    }
    ~GameScreen (){}

    void PlayGame()
    {
        if(key[KEY_RIGHT])
        {
            objects->MoveObjectsLeft(player->GetSpeed());
            player->SetRightLeft(false);
            player->SetState(WALK);
        }
        if(key[KEY_LEFT]) // Ditto' - only for left key
        {
            objects->MoveObjectsRight(player->GetSpeed());
            player->SetRightLeft(true);
            player->SetState(WALK);
        }
        if(key[KEY_UP]) // If the user hits the up key, change the picture's Y coordinate
        {
            if (jumpDelay>20)
            {
                player->SetVely(-10);
                player->SetState(JUMP);
                jumpDelay = 0;
            }
        }
        if(key[KEY_DOWN]) // Ditto' - only for down
        {
            //Key would do nothing when gravity is implemented
//            player->Move(0,player->GetSpeed());
//            player->SetState(JUMP);
        }
        if(key[KEY_SPACE]) // press space to fire
        {  //Implement fire delay
            if(spaceDelay >= 20){
                player->Fire();
                spaceDelay=0;
            }
        }
//               if (spaceDe)
//                {
//                    player->SetState(STAND);
//                }

        spaceDelay++;
        jumpDelay++;
    }

    void SaveGame()
    {
        ofstream saveFile;
        saveFile.open("saveGame.txt");
        objects->Save(saveFile);
        saveFile.close();


    }
};

