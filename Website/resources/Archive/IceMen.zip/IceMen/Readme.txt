-The drawit program is used to create a map/level for the main game
the keys to use in drawmap are:
P to add enemy
R to add obstacle
Backspace to delete