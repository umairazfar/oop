#include"Enemy.h"

Enemy::Enemy()
{

}

Enemy::~Enemy()
{
    cout<<"Enemy Deallocated"<<endl;
}

Enemy::Enemy(LTexture* image, float x, float y):Unit(image, x, y)
{


}


void Enemy::Move()
{

}

void Enemy::Render(long int& frame, SDL_Renderer* gRenderer)
{

}
