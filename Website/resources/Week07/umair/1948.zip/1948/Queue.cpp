#include"Queue.h"
#include<iostream>

using namespace std;

Queue::Queue()
{

}

Queue::~Queue()
{

}

void Queue::Enqueue(Unit* unit)
{

}

void Queue::Clean()
{

}

void Queue::Render(long int& frame, SDL_Renderer* gRenderer)
{

}

void Queue::Move()
{

}
