#include <iostream>
#include "Circle.h"

using namespace std;

int main()
{
    Circle c;
    cout<<c.Area(10)<<endl;

    Point p;
    p.x = 10;
    p.y = 20;

    Circle circle(p, 20);
    cout<<circle.Area()<<endl;

    Circle b = c;
    cout<<b.Area()<<endl;

    Circle* temp = new Circle;
    cout<<temp->Area()<<endl;
    delete temp;    //Comment this to see what happens
    return 0;
}
