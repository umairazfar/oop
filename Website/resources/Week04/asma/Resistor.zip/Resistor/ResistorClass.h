#ifndef RESISTORCLASS_H
#define RESISTORCLASS_H
#include <string>
using namespace std;

class ResistorClass
{
    public:
        ResistorClass();
        ~ResistorClass();
         void DisplayResistor();
          void EnterResistance ();
           void AddSeries ( ResistorClass* Resistor2);
           ResistorClass(string Name, double nominalResistance, double Tolerance);

    protected:

    private:
        string resistorName;
        double resValue;
        double tolerance;
        double MinResistance;
        double MaxResistance;

};

#endif // RESISTORCLASS_H
