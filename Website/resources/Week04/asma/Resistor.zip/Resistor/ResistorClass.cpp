#include "ResistorClass.h"
#include <iostream>
using namespace std;
ResistorClass::ResistorClass()
{
   cout<<"Please enter name";
   cin>> resistorName;
   resValue= 1000;
   tolerance= 0.10;
   MinResistance=resValue;
   MaxResistance= resValue+tolerance;
}

ResistorClass::~ResistorClass()
{
    //dtor
}

ResistorClass::ResistorClass(string n, double r, double t)
{
    resistorName=n;
     resValue= r;
   tolerance= t;
   MinResistance=resValue;
   MaxResistance= resValue+tolerance;
}

void ResistorClass:: DisplayResistor()
{
    cout << "Name: " << resistorName << endl;
     cout << "Value " << resValue << endl;
     cout << "Tolerance " << tolerance << endl;
}

void ResistorClass :: EnterResistance()
{

}
void ResistorClass:: AddSeries(ResistorClass* r2)
{
  resValue= resValue+ r2->resValue;
  cout<< resValue;
}


