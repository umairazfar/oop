#include <iostream>
#include "Circle.h"

using namespace std;

int main()
{
    Circle c;
    cout<<c.Area(10)<<endl;

    Circle b = c;
    cout<<c.Area()<<endl;

    Circle* temp = new Circle;
    cout<<temp->Area()<<endl;
    delete temp;    //Comment this to see what happens
    return 0;
}
