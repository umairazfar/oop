#include"Tile.h"

Tile::Tile(SDL_Surface* image)
{
    this->image = image;
    position.x = 0;
    position.y = 0;

    srcrect.x = 0;
    srcrect.y = 0;
    srcrect.w = 64;
    srcrect.h = 64;

    dstrect.x = 0;
    dstrect.y = 0;
    dstrect.w = 64;
    dstrect.h = 64;
}

Tile::~Tile()
{

}

void Tile::SetPosition(int x, int y)
{
    dstrect.x = x - image->w/2;
    dstrect.y = y - image->h/2;
    dstrect.w = 64;
    dstrect.h = 64;
}

void Tile::Draw(SDL_Surface* gScreenSurface)
{
    SDL_BlitSurface(image, &srcrect, gScreenSurface, &dstrect);
}

void Tile::SetImage(SDL_Surface* image)
{
    this->image = image;
}
