#include <iostream>
#include"Queue.h"

using namespace std;

int main()
{
    Queue q;
    q.Enqueue(10);
    q.Enqueue(20);
    q.Enqueue(30);
    q.Enqueue(40);
    q.Enqueue(50);

    q.Display();
    //cout<<"Dequeued value: "<<q.Dequeue()<<endl;
    //cout<<"Dequeued value: "<<q.Dequeue()<<endl;
    //cout<<"Dequeued value: "<<q.Dequeue()<<endl;
    //cout<<"Dequeued value: "<<q.Dequeue()<<endl;
    //cout<<"Dequeued value: "<<q.Dequeue()<<endl;
    //cout<<"Dequeued value: "<<q.Dequeue()<<endl;
    return 0;
}
