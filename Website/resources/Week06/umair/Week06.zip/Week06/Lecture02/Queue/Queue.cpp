#include"Queue.h"
#include<iostream>

using namespace std;

Queue::Queue()
{
    head = NULL;
    tail = NULL;
}

Queue::~Queue()
{
    Node* temp = NULL;
    while(head != NULL)
    {
        temp = head;
        head = head->next;
        cout<<"Deallocating value: "<<temp->data<<endl;
        delete temp;
    }
}

void Queue::Enqueue(int value)
{
    if(head == NULL)
    {
        head = new Node;
        head->data = value;
        head->next = NULL;
        tail = head;
    }
    else
    {
        tail->next = new Node;
        tail->next->data = value;
        tail->next->next = NULL;
        tail = tail->next;
    }
}

int Queue::Dequeue()
{
    int value = -1;
    if(head != NULL)
    {
        value = head->data;
        Node* temp = head;
        head = head->next;
        delete temp;
    }
    return value;
}

void Queue::Display()
{
    Node* temp = head;
    while(temp!=NULL)
    {
        cout<<"Value: "<<temp->data<<endl;
        temp=temp->next;
    }
}
