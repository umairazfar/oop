#pragma once
#include"Node.h"

class Queue
{
private:
    Node* head;
    Node* tail;
public:
    Queue();
    ~Queue();
    void Enqueue(int);
    int Dequeue();
    int DequeueAt(int); //Make it work
    void Display();
};
