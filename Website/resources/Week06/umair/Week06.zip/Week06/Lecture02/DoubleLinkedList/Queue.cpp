#include"Queue.h"
#include<iostream>

using namespace std;

Queue::Queue()
{
    head = NULL;
    tail = NULL;
}

Queue::~Queue()
{
    while(head != NULL)
    {
        Node* temp = head;
        head = head->next;
        cout<<"Deallocating value: "<<temp->data<<endl;
        delete temp;
    }
}

void Queue::Enqueue(int value)
{
    if(head == NULL)
    {
        head = new Node;
        head->data = value;
        head->next = NULL;
        head->prev = NULL;
        tail = head;
    }
    else
    {
        tail->next = new Node;
        tail->next->data = value;
        tail->next->next = NULL;
        tail->next->prev = tail;
        tail = tail->next;
    }
}

int Queue::Dequeue()
{
    int value = -1;
    if(head != NULL)
    {
        Node* temp = head;
        value = head->data;
        head = head->next;
        if(head!=NULL)
        {
            head->prev = NULL;
        }
        delete temp;
    }
    return value;
}

void Queue::Display()
{
    Node* temp = head;
    while(temp!=NULL)
    {
        cout<<"Value: "<<temp->data<<endl;
        temp=temp->next;
    }
}
