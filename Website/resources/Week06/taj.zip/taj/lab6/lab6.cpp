/*

*/ 

/* 15 mins
Task 1:  Create a class Point to store cartesian coordinates (x,y).
- Make default ctor, overloaded ctor, and copy ctor for this class
- Add a function display() which shows the point as (x,y) on screen.


Make a function that takes two points as arguments, calculates, and
returns the distancce between them.
*/

/*   30 mins
Task 2: Make a class Rectangle. It should store the coordiantes of 
it's top-left and bottom-right vertices as Points.
- Make default ctor, overloaded ctor, and copy ctor for this class.
- Add function get_height() that returns the height of rectangle.
- Add function get_width() that returns the width of rectangle.
- Add a function area() of this class that should return the area
of the rectangle.

- Make a function intersecct() that takes two rectangles as arguments and 
returns true if they intersect, otherwise returns false.
*/

/* 105 mins
Task 3:
- let's make a stack of rectangles (lecture)
*/