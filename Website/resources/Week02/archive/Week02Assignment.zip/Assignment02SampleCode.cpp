#include <iostream>

using namespace std;

enum Items{ SWORD, DAGGER, THROWINGKNIFE, BOW, ARROW}; //enum automatically declares integers starting with value 0

int main()
{
    int item;
    cout << "Select an Item: ";
    cin>>item;
    cout<<endl;

    //Add more cases where necessary
    switch(item)
    {
    case SWORD: //If you enter 0, sword will be selected
        cout<<"Sword selected"<<endl;
        break;
    case DAGGER: //If you enter 1, dagger will be selected
        cout<<"Dagger selected"<<endl;
        break;
    }

    int enemies;
    cout<<"Enter the number of enemies";
    cin>>enemies;
    cout<<endl;

    int* ptr = new int[enemies]; //We are using a pointer to declare an array of variable length
                                 //Array is a collection of variables, one after the other

    for (int i = 0; i<enemies; i++)
    {
        ptr[i] = i; //Notice that we will not access the array index like this: *ptr[i]
    }

    cout<<"The type of enemies are:"<<endl;
    for (int i = 0; i<enemies; i++)
    {
        cout<<ptr[i]<<endl;
    }

    delete[] ptr; //we put [] after delete to specify that we are deleting an array

    return 0;
}
