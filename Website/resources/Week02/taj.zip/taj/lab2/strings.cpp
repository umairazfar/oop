#include <iostream>
#include <fstream>


using namespace std;


int main()
{

    /*
    *   Task 1
    *   * declare, display a character array
    */
    char c_array[5] = {'a','b','c','d','e'};


    /*
    *   In C/C++, at the very basically level, string is  an array of characters terminated by NULL-character i.e. '\0'.
    *   Task 2
    *   * declare, initialize, display a string
    */


    /*
    *   In C/C++, at the very basically level, string is  an array of characters terminated by NULL-character i.e. '\0'.
    *   Task 3
    *   * write a function that takes a string as input and returns its size, i.e.,  number of characters
    */
    // int size = size_of_string (my_string);


    /*
    *   In C/C++, at the very basically level, string is  an array of characters terminated by NULL-character i.e. '\0'.
    *   Task 4
    *   * write a function that takes two strings as input and returns true if  they are exactly same
    */
    // bool b = are_strings_equal (mystring1, mystring2);



    /*
    *   a palindrome is a string that reads the same backwards, i.e., madam, noon, civic, etc.
    *   Task 5
    *   * write a function that takes a string as input and returns true if it's a palindrome
    */
    // bool b = is_palindrome(mystring);


    cout << "Hello world!" << endl;
    return 0;
}


    /*
    *   In C/C++, at the very basically level, string is  an array of characters terminated by NULL-character i.e. '\0'.
    *   Task 3
    *   * write a function that takes a string as input and returns its size, i.e.,  number of characters
    */


    /*
    *   In C/C++, at the very basically level, string is  an array of characters terminated by NULL-character i.e. '\0'.
    *   Task 4
    *   * write a function that takes two strings as input and returns true if  they are exactly same
    */



    /*
    *   a palindrome is a string that reads the same backwards, i.e., madam, noon, civic, etc.
    *   Task 5
    *   * write a function that takes a string as input and returns true if it's a palindrome
    */
