#include <iostream>

using namespace std;


int main()
{

    /*
    *   Task 1
    *   * declare an array
    *   * initialize its members with values ranging from 1-10
    *   * display its values
    */


    /*
    *   Task 2
    *   * implement the function zero_array()
    */
    // zero_array(my_array)


    /*
    *   Task 3
    *   * implement the function display_array()
    */
    // display_array(my_array)

    cout << "Hello world!" << endl;
    return 0;
}


    /*
    *   Task 2
    *   * implement the function zero_array()
    */

    /*
    *   Task 3
    *   * implement the function display_array()
    */
