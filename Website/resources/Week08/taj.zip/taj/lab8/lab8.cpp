
#include <iostream>
#include <stdlib.h>
#include <math.h>

using namespace std;

 /*  Task 1: a. Define a class complex to store the real and imaginary parts of a complex number.
  *  b. Define a default constructor, overloaded constructor, copy constructor as well as a destructor.
  *  c. Add a display function what displays the number as a+bi on the screen
  */


 /*  Task 2: a. Over load the following operators +, -, * for this class by declaring non-member functions.
  *  b. Repeat Task 2a by creating member functions
  */

 /*  Task 3: a. Over load the preincrement (++a) as well as post increment (a++) operators.
  *  b. Overload  the assignment operator for your class complex.
  */

 /*  Task 4: a. Overload the << operators for your  type complex
  */


 /*  Task 5: a. Modify your class  complex so that instead of having two attributes of type integer to
  *             store the real and imaginary part, you should have a single attribute of type int * data
  *             which should point to a dynamically allocated array of two integers.
  *             Store the real and imaginary parts in the two elements  of that array.
  *             What other changes have to be done in your class as a result of this change ??
  */
