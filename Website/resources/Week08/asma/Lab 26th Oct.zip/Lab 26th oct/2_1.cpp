/* Lecture Code 2.1
 *
 * Basic use of the STL queue.
 */

#include <iostream>
#include <queue>
using namespace std;

const int NUM_INTS = 10;

int main()
{
	queue<int> myQueue;

	for(int i = 0; i < NUM_INTS; i++)
		myQueue.push(i);

	cout << "The size is " << myQueue.size() << endl;
	cout << "The first element is " << myQueue.front() << endl;

	while(!myQueue.empty())
	{
		cout << myQueue.front() << ' ';
		myQueue.pop();
	}

	cout << endl;

	return 0;
}
