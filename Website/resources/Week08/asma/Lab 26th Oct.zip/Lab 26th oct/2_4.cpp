
#include <iostream>
#include <vector>
#include <ctime>
using namespace std;

const int NUM_ELEMS = 100000;
const int NUM_TESTS = 500;

template <typename ContainerType>
	void RunTest()
{

	clock_t start = clock();
	ContainerType myContainer;

	for(int h = 0; h < NUM_TESTS; h++)
	{
		for(int i = 0; i < NUM_ELEMS; i++)
			myContainer.push_back(i);
		for(int h = 0; h < NUM_ELEMS; h++)
			myContainer.pop_back();
	}

	start = clock() - start;

	cout << "Test completed in ";
	cout << ((double)(start) / CLOCKS_PER_SEC);
	cout << " seconds." << endl;
}

int main()
{
	RunTest<vector<int> >();

	return 0;
}
