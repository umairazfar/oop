/* Lecture Code 3.0
 *
 * Basic STL set usage.
 */
#include <iostream>
#include <set>
using namespace std;

int main()
{
	set<int> mySet;

	for(int i = 0; i < 10; i++)
		mySet.insert(i);

	if(mySet.find(5) != mySet.end())
		cout << "The set contains five." << endl;

	mySet.erase(4);
	cout << "The set contains ";
	cout << mySet.size() << " elements." << endl;
    
	for(set<int>::iterator itr = mySet.begin(); itr != mySet.end(); ++itr)
		cout << *itr << ' ';
	cout << endl;

	return 0;
}