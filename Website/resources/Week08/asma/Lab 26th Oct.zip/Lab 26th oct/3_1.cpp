/* Lecture Code 3.1
 *
 * Basic STL map usage.
 */
#include <iostream>
#include <map>
#include <string>
using namespace std;

int main()
{
	map<string, int> myMap;

	myMap["STL"] = 137;
	myMap["AAAA"] = 222222;
	
	myMap.erase("AAAA");

	if(myMap.find("STL") != myMap.end())
		cout << "The map contains key STL." << endl;

	for(map<string, int>::iterator itr = myMap.begin(); itr != myMap.end(); ++itr)
		cout << itr->first << ' ' << itr->second << endl;

	return 0;
}