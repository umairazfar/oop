#pragma once
#include<iostream>

using namespace std;

struct Node
{
    int data;
    Node* next;
};

class Stack
{
private:
    Node* head;
public:
    Stack()
    {
        head = NULL;
    }
    void Push(int d)
    {
        Node* temp = new Node;
        temp->data = d;
        temp->next = head;
        head = temp;
    }
    int Pop()
    {
        int d = -1;
        if(head!=NULL)
        {
            Node* temp = head;
            head = head->next;
            d = temp->data;
            delete temp;
            temp = NULL;
        }
    }

    int operator[](int index)
    {
        int i = 0;
        Node* temp = head;
        while(i<index && temp->next!=NULL)
        {
            temp = temp->next;
            i++;
        }
        return temp->data;
    }
};
