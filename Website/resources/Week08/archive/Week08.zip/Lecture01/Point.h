#pragma once

#include<iostream>

struct Point
{
    int x;
    int y;

    Point()
    {
        x = y =0;
    }

    Point(int x, int y)
    {
        this->x = x;
        this->y = y;
    }

    Point(const Point& p)
    {
        x = p.x;
        y = p.y;
    }

    Point operator+(const Point& p)
    {
        Point newPoint;
        newPoint.x = this->x + p.x;
        newPoint.y = this->y + p.y;
        return newPoint;
    }

    Point operator++()
    {
        ++x;
        ++y;

        return Point(x, y);
    }

    Point operator++(int)
    {
        Point P(x, y);
        x++;
        y++;

        return P;
    }

    Point operator+=(Point& p1)
    {
        x = x + p1.x;
        y = y + p1.y;

        return Point(x, y);
    }

    bool operator==(const Point& p1)
    {
        bool result = false;

        if(x == p1.x && y == p1.y)
        {
            result = true;
        }

        return result;
    }

    void Show()
    {
        std::cout<<"Value of x is: "<<x<<std::endl;
        std::cout<<"Value of y is: "<<y<<std::endl;
    }
};
