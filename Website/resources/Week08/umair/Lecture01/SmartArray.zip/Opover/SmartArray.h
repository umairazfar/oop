#pragma once

class SmartArray
{
private:
    int* s_array;
    int length;
public:
    SmartArray(int);
    void operator+(int);
    void operator+(const SmartArray&);
    int& operator[](int);
    void Show();
};

