#include <iostream>
#include"SmartArray.h"

using namespace std;

int main()
{
    //cout << "Hello world!" << endl;
    SmartArray arr(3);
    cout<<arr[0]<<endl;
    arr + 9;
    arr.Show();
    (arr + 15) +78;
    arr.Show();

    SmartArray an_arr(2);
    an_arr + 60;

    arr + an_arr;
    arr.Show();
    return 0;
}
