#include"SmartArray.h"
#include<iostream>

using namespace std;

SmartArray::SmartArray(int length)
{
    this->length = length;
    s_array = new int[length];
    for(int i=0; i<length; i ++)
    {
        s_array[i] = 0;
    }
}

void SmartArray::operator+(int data)
{
    int* temp = new int[length+1];
    for(int i=0; i<length; i ++)
    {
        temp[i] = s_array[i];
    }
    temp[length] = data;
    delete s_array;
    s_array = temp;
    length++;
}

void SmartArray::operator+(const SmartArray& toappend)
{
    int* temp = new int[length+toappend.length];

    for(int i=0; i<length; i ++)
    {
        temp[i] = s_array[i];
    }
    for(int i=length; i<length+ toappend.length; i ++)
    {
        temp[i] = toappend.s_array[i-length];
    }
    delete s_array;
    s_array = temp;
    length +=toappend.length;
}

int& SmartArray::operator[](int loc)
{
    return s_array[loc];
}

void SmartArray::Show()
{
    for (int i=0; i<length; i++)
    {
        cout<<s_array[i]<<" ";
    }
    cout<<endl;
}
