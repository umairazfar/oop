#include"Shape.h"

class ShapeFactory
{
private:
    Shape* shape;
public:
    ShapeFactory()
    {
        shape = NULL;
    }

    Shape* getShape(int type)
    {
        if (type == 0)
        {
            shape = new Circle();
        }
        else if (type == 1)
        {
            shape = new Square();
        }
        else if (type == 2)
        {
            shape = new Rectangle();
        }
        return shape;
    }
};
