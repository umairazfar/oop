#include <iostream>
#include"ShapeFactory.h"

using namespace std;

int main()
{
    ShapeFactory factory;
    Shape* shape;
    shape = factory.getShape(2);
    shape->draw();
    delete shape;
    return 0;
}
