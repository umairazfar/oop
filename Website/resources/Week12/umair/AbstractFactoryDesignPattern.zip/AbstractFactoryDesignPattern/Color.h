#pragma once

#include<iostream>

using namespace std;

class Color
{
private:

public:
    virtual void draw() = 0;
};

class Red: public Color
{
public:
    void draw()
    {
        cout<<"Red Drawn"<<endl;
    }
};

class Green: public Color
{
public:
    void draw()
    {
        cout<<"Green Drawn"<<endl;
    }
};

class Blue: public Color
{
public:
    void draw()
    {
        cout<<"Blue Drawn"<<endl;
    }
};

