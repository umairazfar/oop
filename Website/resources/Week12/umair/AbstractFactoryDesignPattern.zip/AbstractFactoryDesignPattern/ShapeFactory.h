#include"AbstractFactory.h"

class ShapeFactory: public AbstractFactory
{
private:
    Shape* shape;
public:
    ShapeFactory()
    {
        shape = NULL;
    }

    Color* getColor(int type)
    {
        return NULL;
    }

    Shape* getShape(int type)
    {
        if (type == 0)
        {
            shape = new Circle();
        }
        else if (type == 1)
        {
            shape = new Square();
        }
        else if (type == 2)
        {
            shape = new Rectangle();
        }
        return shape;
    }
};
