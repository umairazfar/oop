#include <iostream>
#include"FactoryProducer.h"
#include"AbstractFactory.h"

using namespace std;

int main()
{
    Shape* shape=NULL;
    FactoryProducer factoryProducer;
    AbstractFactory* factory = factoryProducer.getFactory(0);
    shape = factory->getShape(0);
    shape->draw();
    delete shape;
    delete factory;

    return 0;
}
