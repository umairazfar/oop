#pragma once

#include<iostream>

using namespace std;

class Shape
{
private:

public:
    virtual void draw() = 0;
};

class Circle: public Shape
{
public:
    void draw()
    {
        cout<<"Circle Drawn"<<endl;
    }
};

class Rectangle: public Shape
{
public:
    void draw()
    {
        cout<<"Rectangle Drawn"<<endl;
    }
};

class Square: public Shape
{
public:
    void draw()
    {
        cout<<"Square Drawn"<<endl;
    }
};
