#pragma once
#include<iostream>
#include"Shape.h"
#include"Color.h"

using namespace std;

class AbstractFactory
{
private:

public:

    virtual Shape* getShape(int type) = 0;
    virtual Color* getColor(int type) = 0;
};

