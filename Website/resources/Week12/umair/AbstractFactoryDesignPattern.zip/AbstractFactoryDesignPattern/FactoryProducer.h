#pragma once
#include"AbstractFactory.h"
#include"ShapeFactory.h"
#include"ColorFactory.h"
#include<iostream>

using namespace std;

class FactoryProducer
{
public:

    AbstractFactory* getFactory(int type)
    {
        if (type == 0)
        {
            AbstractFactory* temp = new ShapeFactory();
            return temp;
        }
        else if (type == 1)
        {
            AbstractFactory* temp = new ColorFactory();
            return temp;
        }
    }
};
