#include"AbstractFactory.h"

class ColorFactory : public AbstractFactory
{
private:
    Color* color;
public:
    ColorFactory()
    {
        color = NULL;
    }

    Shape* getShape(int type)
    {
        return NULL;
    }

    Color* getColor(int type)
    {
        if (type == 0)
        {
            color = new Red();
        }
        else if (type == 1)
        {
            color = new Green();
        }
        else if (type == 2)
        {
            color = new Blue();
        }
        return color;
    }
};
