#include<iostream>

using namespace std;

class Singleton
{
private:
    int value;
    static Singleton* instance;
public:
    Singleton()
    {
        value = 0;
    }

    int GetValue()
    {
        return value;
    }

    void SetValue(int v)
    {
        value = v;
    }

    static Singleton* GetInstance()
    {
        if (instance == NULL)
            instance = new Singleton;
        return instance;
    }

};

Singleton *Singleton::instance = NULL;

void Function1(void);
void Function2(void);

int main()
{
    cout << "main: instance is " << Singleton::GetInstance()->GetValue() << '\n';
    Function1();
    Function2();
    return 0;
}

void Function1(void)
{
  Singleton::GetInstance()->SetValue(1);
  cout << "Function1: instance is " << Singleton::GetInstance()->GetValue() << '\n';
}

void Function2(void)
{
  Singleton::GetInstance()->SetValue(2);
  cout << "Function2: instance is " << Singleton::GetInstance()->GetValue() << '\n';
}
