#ifndef POLYNOMIAL_H
#define POLYNOMIAL_H


class Polynomial
{
    public:
        Polynomial();
        Polynomial(int,int*);
        int negate1();
        int add(Polynomial p1, Polynomial p2);
        void display();
    protected:

    private:
        int degree;
        int* coeff;
};

#endif // POLYNOMIAL_H
