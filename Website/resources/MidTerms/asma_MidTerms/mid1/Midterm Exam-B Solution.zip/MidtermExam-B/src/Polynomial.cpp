#include "Polynomial.h"
#include <iostream>
using namespace std;

Polynomial::Polynomial()
{
    degree=0;
    coeff= new int[degree];
}

Polynomial::Polynomial(int deg,int* c)
{
    degree=deg;
    coeff= new int[deg+1];

    for (int i=0;i<=deg;i++)
    {
      coeff[i]= c[i];
    }

}

void Polynomial::display()
{
  cout<< degree << endl;
  cout<< coeff[0]<< endl<< coeff[1]<< endl<< coeff[2]<< endl;
}

Polynomial::negate1()
{
    for (int i=0;i<=degree;i++)
        coeff[i]*=-1;
}
