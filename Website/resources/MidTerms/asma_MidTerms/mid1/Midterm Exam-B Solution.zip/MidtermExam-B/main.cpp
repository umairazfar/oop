#include <iostream>
#include "Polynomial.h"
using namespace std;

// Q3
void shift_right(float arr[],int left,int right,int distance,int len)
{
   // int size= right-left;
    float newarray[len+distance] ;

   if((left<=right)&&(distance>0)){
        for (int i=0;i<left;i++)
           newarray[i]= arr[i];
        for (int i=left;i<(left+distance);i++)
            newarray[i]=0;
        for(int i=(left+distance),j=left;i<=(right+distance);i++,j++)
            newarray[i]= arr[j];

    } // end of if

    // Display the new array
    for (int i=0;i<(len+distance);i++)
        cout << newarray[i] << endl;
}


// Q2

 int findMinMax(int score[])
{
  int minIndex=0;int maxIndex=0;
  int sum=0;
  for (int i=1;i<5;i++)
  {
    if (score[i]>score[maxIndex]) maxIndex=i;
    if (score[i]<score[minIndex]) minIndex=i;
  }
  for (int i=0;i<5;i++)
  {
    if (i!=minIndex && i!= maxIndex)
     sum+=score[i];
  }
  cout<< sum << endl;
  return sum;

}
void divingCompetition()
{
    int dives=3,judges=5,numberOfCompetitors = 0;
    cout << "Enter the number of competitors:" << endl;
    cin >> numberOfCompetitors;

    int diveScore [3];
    int score[5];
   // int diff= 0.1;

    int competScore[numberOfCompetitors];//= new int[numberOfCompetitors];

    // Initializing array
    for (int i=0;i<numberOfCompetitors;i++)
     competScore[i]=0;

    // Loop to get input
    for (int i = 0; i < numberOfCompetitors; i++)
    {
       for (int d = 0; d < dives; d++)
            {

            for (int j = 0; j < judges; j++)
            {
                cout << "Give a score to diver " << i+1 << "out of 10:" << "by the judge "<< j+1 <<endl;
                cin >>  score[j];
            }
            diveScore[d]=findMinMax(score);//*(diff+0.1);
            competScore[i]=competScore[i]+diveScore[d];

        }
}
  int maxi= competScore[0];
  for (int i=1;i<sizeof(competScore)/ sizeof(competScore[0]);i++)
    if (competScore[i]> maxi) maxi=competScore[i];


 cout<< "The winner score is"<< maxi<< endl;

}

int main()
{
    cout << "Hello world!" << endl;

    //Q1
    Polynomial p;
    int* arr= new int[3];
    arr[0]=6; arr[1]=6; arr[2]=6;
    Polynomial p1(2,arr);
    p1.display();
    p1.negate1();
    p1.display();

    // Q2
    divingCompetition();

    //Q3
    float fl[]= {1.5,2.5,3.5};
    int length= sizeof(fl)/sizeof(fl[0]);
    shift_right(fl,1,2,2,length);
    return 0;
}


