#ifndef RATIONAL_H
#define RATIONAL_H


class Rational
{
    public:
        Rational();
        Rational(int,int);
        void printRational();
        double toDouble();
        void reduce();

    protected:

    private:
        int numerator;
        int denominator;
};

#endif // RATIONAL_H
