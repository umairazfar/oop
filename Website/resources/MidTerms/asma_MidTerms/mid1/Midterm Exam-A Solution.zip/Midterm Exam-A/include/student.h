#ifndef STUDENT_H
#define STUDENT_H
#include <iostream>

using namespace std;


class student
{
    public:
        student();
        addCourse();
        dropCourse();
        string courseStudents[6][3];
        int studentMarks();

    protected:

    private:
        int numberOfStudents;
        string name;
        int course;
        int mid1Marks;
        int  mid2Marks;

};

#endif // STUDENT_H
