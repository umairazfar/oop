
#include "Rational.h"
#include <iostream>

Rational::Rational()
{
    numerator = 0;
    denominator = 1;
}

Rational::Rational(int num, int den)
{
    numerator = num;
    denominator = den;
}

void Rational::printRational()
{
    std::cout << numerator << " / " << denominator << '\n';
}


double Rational::toDouble()
{
    return (double) numerator / (double) denominator;

}

void Rational::reduce()
{
    int temp=0;
    int gcd = 1;

    if (numerator == denominator)
    {
        numerator = 1;
        denominator = 1;
    }
    else
    {  if (numerator> denominator)
          {
              temp= numerator;
          }
          else{
             temp= denominator;
          }

    for (int  i= 1; i < temp / 2; ++i)
    {
        if (numerator % i == 0 && denominator % i == 0)
        {
            gcd = i;
        }
    }
      numerator = numerator / gcd;
      denominator = denominator / gcd;

    }

}
