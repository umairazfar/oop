#include "student.h"

student::student()
{
    //ctor
}

student::addCourse()
{
    cout<<"Enter number of students: "; //assuming that the number of students will always be 3
    cin>>numberOfStudents;

    for (int i = 0 ; i<numberOfStudents; i++ )
    {
        cout<<"Enter name: ";
        cin>>name;

        cout<<"Enter course (0-5): ";
        cin>>course;

        courseStudents[course][i] = name;
    }
}

student::dropCourse()
{
    cout<<"Enter number of students: ";
    cin>>numberOfStudents;

    for (int i = 0 ; i<numberOfStudents; i++ )
    {
        cout<<"Enter name: ";
        cin>>name;

        cout<<"Enter course (0-5): ";
        cin>>course;

        for (int i = 0 ; i<numberOfStudents; i++ )
        {
            if (courseStudents[course][i] == name)
            {
                courseStudents[course][i] = "0"; //  means no student
            }
        }
    }
}

student::studentMarks()
{
    cout<<"Enter number of students: "; //assuming that the number of students will always be 3
    cin>>numberOfStudents;

    for (int i = 0 ; i<numberOfStudents; i++ )
    {
        cout<<"Enter name: ";
        cin>>name;

        cout<<"Enter midterm 1 marks: ";
        cin>>mid1Marks;

        cout<<"Enter midterm 2 marks: ";
        cin>>mid2Marks;

        cout<<"Your average marks: "<<(mid1Marks + mid2Marks)/2<<endl;
    }
}
