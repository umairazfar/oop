#include <iostream>
#include "Rational.h"
using namespace std;


// Q2 Just single possible solution
void enrollment(string *stdcourseA, int counter,string names[])
{
      stdcourseA= new string[counter];
      for (int i=0;i<counter;i++)
        stdcourseA[i]=names[i];

}



 //Q3 This can be done in numerous ways this is just one p
 // possible solution

 void rotate_right(float arr[],int num)
{

    float ar1[num];
    ar1[0]=arr[num-1];
    for (int i=1;i<num;i++)
    {
        ar1[i]=arr[i-1];
    }
    for (int i=0; i<num;i++)
    {
        arr[i]=ar1[i];
        cout<<"Element at index " << i <<" is  " << arr[i]<< endl;
    }
}

int main()
{
    //Q1

    Rational r1;
    std::cout << r1.toDouble() << '\n';
    Rational r2(2,6);
    r2.reduce();
    r2.printRational();

   //Q2
//   string stdERP[5]= {"101","102","103","104","105"};
   int numStd;

   string courses[6]={"A","B","C","D","E","F"};
   cout<< "Please enter the number of students" << endl;
   cin >> numStd;
   string studentsNames[numStd];
   int counter[6]={0,0,0,0,0,0};
   string *names;


   string *stdcourseA;
   string *stdcourseB;
   string *stdcourseC;
   string *stdcourseD;
   string *stdcourseE;
   string *stdcourseF;

   int press=0;
   string name;

   for (int i=0;i<numStd;i++)
   {
     cout<<"Please enter student name :" << endl;
     cin>> studentsNames[i];

     for (int j=0;j<6;j++)
     {
     cout<< "Hello Student " << studentsNames[i] <<"  If you want to enroll for course "<<courses[j]  <<"  Press 1:  if not then press 0 " << endl;
     cin >> press;
     if (press==1)
       {counter[j]++;}//names[i]= studentsNames[i];}
     }

   }
     stdcourseA= new string[counter[0]];
     stdcourseB= new string[counter[1]];
     stdcourseC= new string[counter[2]];
     stdcourseD= new string[counter[3]];
     stdcourseE= new string[counter[4]];
     stdcourseF= new string[counter[5]];

   // I am also uploading one more possible implementation
   // via making classes of course /student separately by
   // your batch mates for your reference


     //Q3
   float arr[4]={1.5,2.5,6,3.2};
   rotate_right(arr,4);

    return 0;
}
