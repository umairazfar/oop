#pragma once
class Point;

class Line
{
private:
    int x1,x2;
    int y1,y2;

public:
    void define(const Point& p1, const Point& p2);
    friend void Show(const Line& l);
};

class Point
{
private:
    int x;
    int y;
    friend class Line;

public:
    Point()
    {
        x=y=0;
    }
    Point(int x, int y)
    {
        this->x = x;
        this->y = y;
    }

    friend Point operator+(const Point& p1, const Point& p2);
    friend void Show(const Point& p);

};

void Line::define(const Point& p1, const Point& p2)
{
    x1 = p1.x;
    x2 = p2.x;
    y1 = p1.y;
    y2 = p2.y;
}
