#include <iostream>
#include"Friend.h"

using namespace std;


int main()
{
    Point p1(10,50);
    Point p2(100, 100);
    Point p3 = p1 + p2;
    Show(p3);

    Line line;
    line.define(p1, p2);
    Show(line);
    return 0;
}

Point operator+(const Point& p1, const Point& p2)   //Not a member of Point class
{
    return Point(p1.x + p2.x, p1.y + p2.y);
}

void Show(const Point& p)   //Not a member of Point class
{
    cout<<p.x<<endl;
    cout<<p.y<<endl;
}

void Show(const Line& l)   //Not a member of Point class
{
    cout<<l.x1<<endl;
    cout<<l.y1<<endl;
    cout<<l.x2<<endl;
    cout<<l.y2<<endl;
}

