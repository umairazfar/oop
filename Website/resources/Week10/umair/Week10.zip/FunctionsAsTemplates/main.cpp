#include <iostream>

using namespace std;

template<class Type>
Type Add(Type num1, Type num2)
{
    return num1 + num2;
}

struct Something
{
    int n;
    float f;

    Something()
    {
        n = 10;
        f = 3.5f;
    }

    friend ostream& operator<<(ostream& stream, const Something& s);

};

std::ostream& operator<<(ostream& stream, const Something& s)
{
    cout<<s.n<<endl;
    cout<<s.f<<endl;
}

int main()
{

    Something s;

    //void pointers
    void *ptr;
    ptr = &s.n; // valid
    cout<<"Value of integer through void pointer"<<endl;
    cout<<*static_cast<int*>(ptr)<<endl;

    ptr = &s.f; // valid
    cout<<"Value of float through void pointer"<<endl;
    cout<<*static_cast<float*>(ptr)<<endl;

    ptr = &s; // valid
    cout<<"Value of Structure through void pointer"<<endl;
    cout<<*static_cast<Something*>(ptr);

    Something* t = static_cast<Something*>(ptr);
    cout<<"Value of Structure through another pointer via a void pointer"<<endl;
    cout<<*t;

    cout <<"Adding for Integers "<< Add(5,10) << endl;
    cout <<"Adding for floats "<< Add(5.5,10.5) << endl;

    //Pointers to Pointers
    int value = 5;

    int *ptrV = &value;
    std::cout << *ptrV<<endl; // dereference pointer to int to get int value

    int **ptr2ptrV = &ptrV;
    std::cout << **ptr2ptrV<<endl; // first dereference to get pointer to int, second dereference to get int value

    //Pointer to a pointer used to create
    int **array = new int*[10]; // allocate an array of 10 int pointers

    array[0] = &value;
    cout<<*array[0];

    delete[] array;
    array = nullptr;
    return 0;
}
