#pragma once

template <class DATA>
struct Node
{
    DATA data;
    Node<DATA>* next;
};
