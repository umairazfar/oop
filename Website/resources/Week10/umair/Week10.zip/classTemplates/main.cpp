#include <iostream>
#include "Stack.h"

using namespace std;

int main()
{
    Stack<int> stk;
    stk.Push(8);
    cout<<stk.Pop();
    return 0;
}
