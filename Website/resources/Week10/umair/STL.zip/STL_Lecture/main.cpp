#include <iostream>
#include <vector>
#include <array>
using namespace std;

//Detailed reference here: http://www.cplusplus.com/reference/stl/

//Array usage

//Do not forget to activate -std=gnu++11 in compiler options

int main()
{
    std::array<int, 5> arr = { 2, 5, 7, 10, 19};
    int i;

    // display the original size of arr
    cout << "array size = " << arr.size() << endl;

    // display extended size of arr
    cout << "maximum array size = " << arr.max_size() << endl;

    // access 5 values from the array
    for(i = 0; i < 5; i++)
    {
        cout << "value of arr [" << i << "] = " << arr[i] << endl;
    }

    // use iterator to access the values
    for ( auto it = arr.begin(); it != arr.end(); ++it )
    std::cout << ' ' << *it;

    return 0;
}

//Vector usage
/*
int main()
{
   // create a vector to store int
   vector<int> vec;
   int i;

   // display the original size of vec
   cout << "vector size = " << vec.size() << endl;

   // push 5 values into the vector
   for(i = 0; i < 5; i++){
      vec.push_back(i);
   }

   // display extended size of vec
   cout << "extended vector size = " << vec.size() << endl;

   // access 5 values from the vector
   for(i = 0; i < 5; i++){
      cout << "value of vec [" << i << "] = " << vec[i] << endl;
   }

   // use iterator to access the values
   vector<int>::iterator v = vec.begin();
   while( v != vec.end()) {
      cout << "value of v = " << *v << endl;
      v++;
   }

   return 0;
}
*/
